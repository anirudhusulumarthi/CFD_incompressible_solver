from attrs import field
from src.init import extract_parameters
from src.parameter_gui import launch_parameter_gui, vof_editor 
from src.output import print_parameters
from src.grid import FieldSet
from src.solve import uvp_Transient_solve

####################################################
import time
import sys
import io

# --- Tee stream to send output both to file and (optionally) to the GUI log ----
class GuiLogTee(io.TextIOBase):
    def __init__(self, base_stream):
        super().__init__()
        self.base_stream = base_stream    # the underlying TextIOWrapper to file
        self.gui_log = None               # will be set to the GUI log(msg) function

    def write(self, s):
        # write to file
        self.base_stream.write(s)
        self.base_stream.flush()
        # also write to GUI if we have a log callback
        if self.gui_log is not None and s:
            self.gui_log(str(s))
        return len(s)

    def flush(self):
        self.base_stream.flush()

    @property
    def encoding(self):
        return self.base_stream.encoding


# Open file as before
log_file = open("output/output_log.txt", "wb", buffering=0)  # Unbuffered binary
file_stream = io.TextIOWrapper(log_file, encoding='utf-8', write_through=True)

# Wrap file_stream in a tee
tee_stream = GuiLogTee(file_stream)

# Route stdout and stderr through the tee
sys.stdout = tee_stream
sys.stderr = tee_stream
#####################################################################################
import numpy as np
from numba import njit
from src.output import writeVTI
#####################################################################################
#####################################################################################


@njit(cache=True)
def collocated_to_vof_stag(vf_col, vf_stag):
    
    # node-based VOF (as implied by your vof_cen averaging)
    nx_c, ny_c = vf_col.shape
    nx_s, ny_s = vf_stag.shape
    for i in range(1, min(nx_s-1, nx_c)):
        for j in range(1, min(ny_s-1, ny_c)):
            vf_stag[i, j] = 0.25 * (
                vf_col[i-1, j-1] + vf_col[i, j-1] + vf_col[i-1, j] + vf_col[i, j]
            )
    # zero-gradient ghosts
    vf_stag[0, :]  = vf_stag[1, :]
    vf_stag[-1, :] = vf_stag[-2, :]
    vf_stag[:, 0]  = vf_stag[:, 1]
    vf_stag[:, -1] = vf_stag[:, -2]


def run_full_simulation(param_path, gui_log):
    """
    This is called from the GUI 'Next Step' button, in a background thread.

    param_path : path to the .par file (from the GUI)
    gui_log    : function that enqueues text for the GUI Run Output tab
    """
    # Tell the tee stream to also send all print() output to the GUI (via queue)
    tee_stream.gui_log = gui_log

    print("=== IWW-2D-WSI SOLVER ===")
    print(f"[INFO] Parameter file path from GUI: {param_path}")

    # Step 2: Load the parameter file created by the GUI
    params = extract_parameters()
    print(f"[INFO] Loaded parameters for problem: {params.problem_name}")
    print_parameters(params)

    # Step 3: Create fields based on grid
    field = FieldSet(params)
    print(f"[INFO] Created field set with shapes: {field.shapes}")

    # Step 4: VOF
    #field.vof[:] = 1.0
    print(f"[INFO] Initialized VOF field.")
    
    #########################################################################################################
    #init_vof_square(field, field.dx, field.dy, x0=0.0, x1=3.0, y0=0.0, y1=3.0)
    #init_velocity_u(field, field.dx, field.dy, xc=0.5, yc=0.5, omega=1)
    #init_velocity_v(field, field.dx, field.dy, xc=0.5, yc=0.5, omega=1)

    
    #for j in range(0, int(params.ymax/2)+1):
    #    for i in range(0, int(params.xmax/4)+1):
    #        field.vof_col[i, j] = 0.7
    
        
    #for j in range(0, int(params.ymax/2)):
    #    for i in range(0, int(params.xmax/4)):
    #        field.vof_col[i, j] = 1.0
    print("[INFO] Opening VOF editor...")
    vof_editor(field.vof_col)  
    print("[INFO] VOF field set by user.")
    field.u_cen[:] = 0.0 # field.u_col.copy()
    field.v_cen[:] = 0.0 #field.v_col.copy()
    field.p_cen[:] = 0.0
    field.vof_cen[:] = field.vof_col.copy()

    fname = f"output/sim_{00000:05}.vti"
    writeVTI(field, fname, time=0)

    field.u_cen[:] = 0.0
    field.v_cen[:] = 0.0
    field.vof_cen[:] = 0.0

    #collocated_to_u_stag(field.u_col, field.u_stag)
    #collocated_to_v_stag(field.v_col, field.v_stag)
    collocated_to_vof_stag(field.vof_col, field.vof_stag)

    #field.u = field.u_stag.copy()
    #field.v = field.v_stag.copy()
    field.vof = field.vof_stag.copy()

    #########################################################################################################    
    # Computing Time
    t_start = time.time()
    # Step 5: Solve the transient NS equations

    uvp_Transient_solve(field, params)

    t_total = time.time() - t_start
    print(f"[INFO] Total computation time: {t_total:.2f} seconds")


def main():
    # Step 1: Launch GUI.
    # When the user clicks "Next Step", the GUI will call run_full_simulation(...)
    launch_parameter_gui(next_step_callback=run_full_simulation)


if __name__ == "__main__":
    main()
