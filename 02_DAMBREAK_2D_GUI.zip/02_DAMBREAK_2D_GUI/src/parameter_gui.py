import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
import configparser
import os
import threading
import queue

# Optional: nicer logo scaling if Pillow is installed
try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

DEFAULT_OUTPUT_PATH = "input/parameter_file.par"

# Adjust this path if needed
LOGO_PATH = r"S:\04_Two_Phase_flow_solver\02_DAMBREAK_2D_GUI\src\PROJECT_LOGO.png"

walls_left = ["top", "right"]
walls_right = ["bottom", "left"]
fields = ["u", "v", "p"]

# Defaults for boundary fields
default_init = {
    "u": ("none", "0.0"),
    "v": ("none", "0.0"),
    "p": ("none", "0.0"),
}

default_bc = {
    "u": ("no_slip", "0.0"),
    "v": ("no_slip", "0.0"),
    "p": ("zero_grad", "0.0"),
}


def kill_application():
    """
    Hard kill switch: stops solver + GUI by terminating the entire process.
    """
    if messagebox.askyesno(
        "Confirm Kill",
        "This will stop the current run and close the program immediately.\n\n"
        "Do you want to continue?",
    ):
        # Hard exit: kills all threads and the GUI
        os._exit(0)


def launch_parameter_gui(output_path=DEFAULT_OUTPUT_PATH, next_step_callback=None):
    """
    Launch the parameter GUI.

    next_step_callback:
        Optional function(param_path, log_func) that will be called when the user
        clicks 'Next Step'. 'log_func' is a callable that writes strings into
        the 'Run Output' tab (indirectly, via a queue so it's thread-safe).
    """
    window = tk.Tk()
    window.title("IWW-2D-WSI SOLVER – GUI")

    # Fixed size (tweak if you like)
    window.geometry("1100x700")
    window.minsize(1100, 700)

    window.option_add("*Font", "Arial 10")

    # StringVar to remember where we saved the file
    output_path_var = tk.StringVar(value="")

    entries = {}

    # -------------------- NOTEBOOK / TABS --------------------
    notebook = ttk.Notebook(window)
    notebook.pack(fill="both", expand=True)

    tab_home = ttk.Frame(notebook)
    tab_setup = ttk.Frame(notebook)      # problem / solver / time / fluid
    tab_bc = ttk.Frame(notebook)         # boundary / corner / structure

    notebook.add(tab_home, text="Home")
    notebook.add(tab_setup, text="Case Setup")
    notebook.add(tab_bc, text="Boundary & Structure")

    # -------------------- TAB 1: HOME (LOGO + TITLE) --------------------
    home_bg = "#f5f5f5"
    style = ttk.Style()
    style.configure("Home.TFrame", background=home_bg)
    tab_home.configure(style="Home.TFrame")

    center_frame = tk.Frame(tab_home, bg=home_bg)
    center_frame.place(relx=0.5, rely=0.5, anchor="center")

    # Logo (centered & scaled if Pillow available)
    logo_label = None
    try:
        if PIL_AVAILABLE:
            img = Image.open(LOGO_PATH)
            # scale to fit nicely in the tab
            max_size = 250
            w, h = img.size
            scale = min(max_size / float(w), max_size / float(h))
            new_size = (int(w * scale), int(h * scale))
            img = img.resize(new_size, Image.LANCZOS)
            logo_img = ImageTk.PhotoImage(img)
        else:
            logo_img = tk.PhotoImage(file=LOGO_PATH)

        logo_label = tk.Label(center_frame, image=logo_img, bg=home_bg)
        logo_label.image = logo_img  # keep reference
        logo_label.pack(pady=15)
    except Exception:
        logo_label = tk.Label(
            center_frame,
            text="[PROJECT LOGO]",
            bg=home_bg,
            font=("Arial", 16, "bold"),
        )
        logo_label.pack(pady=15)

    title_label = tk.Label(
        center_frame,
        text="IWW-2D-WSI SOLVER",
        font=("Arial", 22, "bold"),
        bg=home_bg,
        fg="#003366",
    )
    title_label.pack(pady=5)

    subtitle_label = tk.Label(
        center_frame,
        text=(
            "Two-Phase Flow & Wave–Structure Interaction Solver\n\n"
            "1. Use the Case Setup and Boundary & Structure tabs to define your case.\n"
            "2. Click \"Save Parameter File\".\n"
            "3. Click \"Next Step\" to run the next stage and view output here."
        ),
        font=("Arial", 11),
        bg=home_bg,
        justify="center",
    )
    subtitle_label.pack(pady=10, padx=20)

    # -------------------- TAB 2: PROBLEM / SOLVER / TIME / FLUID --------------------
    problem_frame = ttk.LabelFrame(tab_setup, text="Problem Settings")
    solver_frame = ttk.LabelFrame(tab_setup, text="Solver Settings")
    time_frame = ttk.LabelFrame(tab_setup, text="Time Settings")
    fluid_frame = ttk.LabelFrame(tab_setup, text="Fluid Properties")

    problem_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nw")
    solver_frame.grid(row=0, column=1, padx=10, pady=10, sticky="ne")
    time_frame.grid(row=1, column=0, padx=10, pady=10, sticky="sw")
    fluid_frame.grid(row=1, column=1, padx=10, pady=10, sticky="se")

    problem_labels = ["Problem Name", "xlength", "ylength", "xmax", "ymax"]
    solver_labels = [
        "re",
        "alpha_uv",
        "alpha_p1",
        "alpha_p2",
        "error_thresh",
        "maximum_solver_itterations",
        "maximum_pressure_loop_itterations",
    ]

    problem_defaults = ["dam_break", "1.0", "1.0", "51", "51"]
    solver_defaults = ["100", "1.0", "1.0", "1.0", "1e-7", "120000", "1"]

    problem_vars = []
    solver_vars = []

    # Problem section
    for i, label in enumerate(problem_labels):
        var = tk.StringVar(value=problem_defaults[i])
        tk.Label(problem_frame, text=label).grid(row=i, column=0, sticky="w", padx=5, pady=2)
        tk.Entry(problem_frame, textvariable=var, width=18).grid(row=i, column=1, padx=5, pady=2)
        problem_vars.append(var)

    # Solver section
    for i, label in enumerate(solver_labels):
        var = tk.StringVar(value=solver_defaults[i])
        tk.Label(solver_frame, text=label).grid(row=i, column=0, sticky="w", padx=5, pady=2)
        tk.Entry(solver_frame, textvariable=var, width=20).grid(row=i, column=1, padx=5, pady=2)
        solver_vars.append(var)

    # Time settings
    time_labels = [
        "unsteady",
        "start_time",
        "end_time",
        "dt",
        "cfl_target",
        "alpha_cfl_target",
        "max_dt",
        "sample",
    ]
    time_defaults = ["true", "0.0", "1.0", "0.0001", "0.25", "0.10", "2e-4", "0.02"]

    time_vars = []
    for i, label in enumerate(time_labels):
        var = tk.StringVar(value=time_defaults[i])
        tk.Label(time_frame, text=label).grid(row=i, column=0, sticky="w", padx=5, pady=2)
        tk.Entry(time_frame, textvariable=var, width=18).grid(row=i, column=1, padx=5, pady=2)
        time_vars.append(var)

    # Fluid properties
    fluid1_labels = ["rho (fluid 1)", "mu (fluid 1)"]
    fluid2_labels = ["rho (fluid 2)", "mu (fluid 2)"]
    fluid1_defaults = ["997.0", "855e-6"]
    fluid2_defaults = ["1.0", "1e-5"]

    fluid1_vars = []
    fluid2_vars = []

    for i, label in enumerate(fluid1_labels):
        var1 = tk.StringVar(value=fluid1_defaults[i])
        var2 = tk.StringVar(value=fluid2_defaults[i])
        tk.Label(fluid_frame, text=label).grid(row=i, column=0, sticky="w", padx=5, pady=2)
        tk.Entry(fluid_frame, textvariable=var1, width=12).grid(row=i, column=1, padx=5, pady=2)
        tk.Label(fluid_frame, text=fluid2_labels[i]).grid(row=i, column=2, sticky="w", padx=5, pady=2)
        tk.Entry(fluid_frame, textvariable=var2, width=12).grid(row=i, column=3, padx=5, pady=2)
        fluid1_vars.append(var1)
        fluid2_vars.append(var2)

    # -------------------- TAB 3: BOUNDARY / CORNER / STRUCTURE --------------------
    bc_frame = ttk.LabelFrame(tab_bc, text="Boundary Conditions")
    corner_frame = ttk.LabelFrame(tab_bc, text="Corner Conditions")
    structure_frame = ttk.LabelFrame(tab_bc, text="Structure")

    bc_frame.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="nwe")
    corner_frame.grid(row=1, column=0, padx=10, pady=10, sticky="w")
    structure_frame.grid(row=1, column=1, padx=10, pady=10, sticky="e")

    # Boundary Conditions – two side blocks
    def make_bc_block(parent, start_col, start_row, selected_walls):
        row = start_row
        tk.Label(parent, text="Wall").grid(row=row, column=start_col)
        tk.Label(parent, text="Field").grid(row=row, column=start_col + 1)
        tk.Label(parent, text="Init (type, value)").grid(row=row, column=start_col + 2)
        tk.Label(parent, text="BC (type, value)").grid(row=row, column=start_col + 3)
        row += 1

        for wall in selected_walls:
            for field in fields:
                init_var = tk.StringVar(value=f"{default_init[field][0]}, {default_init[field][1]}")
                bc_var = tk.StringVar(value=f"{default_bc[field][0]}, {default_bc[field][1]}")
                tk.Label(parent, text=wall.upper()).grid(row=row, column=start_col, padx=2, pady=1)
                tk.Label(parent, text=field).grid(row=row, column=start_col + 1, padx=2, pady=1)
                tk.Entry(parent, textvariable=init_var, width=18).grid(row=row, column=start_col + 2, padx=2, pady=1)
                tk.Entry(parent, textvariable=bc_var, width=18).grid(row=row, column=start_col + 3, padx=2, pady=1)
                entries[(wall, field)] = {"init": init_var, "bc": bc_var}
                row += 1
        return row

    make_bc_block(bc_frame, 0, 0, walls_left)
    make_bc_block(bc_frame, 5, 0, walls_right)

    # Corner conditions
    corners = ["bottom_left", "bottom_right", "top_left", "top_right"]
    corner_defaults = ["left", "right", "left", "right"]
    corner_vars = {}

    row = 0
    for name, default in zip(corners, corner_defaults):
        var = tk.StringVar(value=default)
        tk.Label(corner_frame, text=name).grid(row=row, column=0, sticky="w", padx=5, pady=2)
        tk.Entry(corner_frame, textvariable=var, width=12).grid(row=row, column=1, padx=5, pady=2)
        corner_vars[name] = var
        row += 1

    # Structure
    struct_labels = ["object", "object_name", "side_length", "object_location"]
    struct_defaults = ["false", "square", "0.2", "(0.6,0.1)"]
    struct_vars = []

    for i, label in enumerate(struct_labels):
        var = tk.StringVar(value=struct_defaults[i])
        tk.Label(structure_frame, text=label).grid(row=i, column=0, sticky="w", padx=5, pady=2)
        tk.Entry(structure_frame, textvariable=var, width=18).grid(row=i, column=1, padx=5, pady=2)
        struct_vars.append(var)

    # -------------------- SAVE & NEXT STEP BUTTONS --------------------
    btn_frame = tk.Frame(window)
    btn_frame.pack(pady=8)

    save_btn = tk.Button(
        btn_frame,
        text="Save Parameter File",
        bg="lightgreen",
        command=lambda: save_config(
            problem_vars,
            solver_vars,
            time_vars,
            fluid1_vars,
            fluid2_vars,
            entries,
            corner_vars,
            struct_vars,
            output_path_var,
        ),
    )
    save_btn.grid(row=0, column=0, padx=10)

    next_btn = tk.Button(
        btn_frame,
        text="Solver Start",
        bg="#ffd966",
        command=lambda: run_next_step(output_path_var, notebook, next_step_callback),
    )
    next_btn.grid(row=0, column=1, padx=10)

    # NEW: Kill switch button
    kill_btn = tk.Button(
        btn_frame,
        text="Kill Run",
        bg="#ff6b6b",
        command=kill_application,
    )
    kill_btn.grid(row=0, column=2, padx=10)

    window.mainloop()


def save_config(problem_vars, solver_vars, time_vars, fluid1_vars, fluid2_vars,
                entries, corner_vars, struct_vars, output_path_var):
    """Save the .par file but keep GUI open."""
    config = configparser.ConfigParser()

    problem_name = problem_vars[0].get().strip()
    if not problem_name:
        messagebox.showerror("Error", "Problem name cannot be empty.")
        return

    # [problem]
    config["problem"] = dict(
        zip(
            ["name", "xlength", "ylength", "xmax", "ymax"],
            [v.get() for v in problem_vars],
        )
    )

    # [solver]
    config["solver"] = dict(
        zip(
            [
                "re",
                "alpha_uv",
                "alpha_p1",
                "alpha_p2",
                "error_thresh",
                "maximum_solver_itterations",
                "maximum_pressure_loop_itterations",
            ],
            [v.get() for v in solver_vars],
        )
    )

    # [time]
    config["time"] = dict(
        zip(
            [
                "unsteady",
                "start_time",
                "end_time",
                "dt",
                "cfl_target",
                "alpha_cfl_target",
                "max_dt",
                "sample",
            ],
            [v.get() for v in time_vars],
        )
    )

    # [fluid.1] and [fluid.2]
    config["fluid.1"] = dict(zip(["rho", "mu"], [v.get() for v in fluid1_vars]))
    config["fluid.2"] = dict(zip(["rho", "mu"], [v.get() for v in fluid2_vars]))

    # [boundary.*.*]
    for (wall, field), vars_dict in entries.items():
        section = f"boundary.{wall}.{field}"
        config[section] = {
            "init": vars_dict["init"].get(),
            "bc": vars_dict["bc"].get(),
        }

    # [CORNER_CONDITIONS]
    config["CORNER_CONDITIONS"] = {
        "bottom_left": corner_vars["bottom_left"].get(),
        "bottom_right": corner_vars["bottom_right"].get(),
        "top_left": corner_vars["top_left"].get(),
        "top_right": corner_vars["top_right"].get(),
    }

    # [structure]
    config["structure"] = dict(
        zip(
            ["object", "object_name", "side_length", "object_location"],
            [v.get() for v in struct_vars],
        )
    )

    # Output path based on problem name
    output_path = os.path.join("input", f"{problem_name}.par")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w") as configfile:
        config.write(configfile)

    output_path_var.set(output_path)
    messagebox.showinfo("Success", f"Parameter file saved to:\n{output_path}")


# ---------- NEW: Performance tab with live plots ----------

def create_performance_tab(notebook, csv_path="output/performance_maps.csv", update_ms=1000):
    import os
    import numpy as np
    import pandas as pd
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.ticker import ScalarFormatter

    perf_tab = ttk.Frame(notebook)
    notebook.add(perf_tab, text="Performance")

    fig = Figure(figsize=(5, 4), dpi=100)
    ax_cfl = fig.add_subplot(211)
    ax_err = fig.add_subplot(212, sharex=ax_cfl)

    ax_cfl.set_ylabel("CFL")
    ax_cfl.grid(True, linestyle="--", linewidth=0.5)

    ax_err.set_xlabel("Time")
    ax_err.set_ylabel("Error")
    ax_err.grid(True, linestyle="--", linewidth=0.5)

    # >>> New formatting: scientific notation, no offset <<<
    for ax in (ax_cfl, ax_err):
        fmt = ScalarFormatter(useMathText=True)
        fmt.set_powerlimits((-3, 3))
        fmt.set_useOffset(False)
        ax.yaxis.set_major_formatter(fmt)
    # <<< end new formatting >>>

    (line_cfl,) = ax_cfl.plot([], [], "-", lw=1.5)
    (line_err,) = ax_err.plot([], [], "-", lw=1.5)

    fig.suptitle("Performance Maps")

    canvas = FigureCanvasTkAgg(fig, master=perf_tab)
    canvas_widget = canvas.get_tk_widget()
    canvas_widget.pack(fill="both", expand=True)

    def update_plots():
        if os.path.isfile(csv_path):
            try:
                df = pd.read_csv(csv_path)
                if df.shape[1] >= 3:
                    t   = df.iloc[:, 0].values
                    cfl = df.iloc[:, 1].values
                    err = df.iloc[:, 2].values

                    if t.size > 0:
                        line_cfl.set_data(t, cfl)
                        line_err.set_data(t, err)

                        ax_cfl.relim()
                        ax_cfl.autoscale_view()

                        ax_err.relim()
                        ax_err.autoscale_view()

                        canvas.draw_idle()
            except Exception:
                pass

        perf_tab.after(update_ms, update_plots)

    update_plots()
    return perf_tab


# ----------------------------------------------------------


def run_next_step(output_path_var, notebook, next_step_callback=None):
    """Create the 4th tab and show 'terminal' output of the next step."""
    param_path = output_path_var.get()
    if not param_path or not os.path.isfile(param_path):
        messagebox.showerror("Error", "Please save the parameter file first.")
        return

    # Create new tab for run output
    run_tab = ttk.Frame(notebook)
    notebook.add(run_tab, text="Run Output")
    notebook.select(run_tab)

    # Text widget to capture output
    text = tk.Text(run_tab, wrap="word")
    text.pack(fill="both", expand=True)

    # Queue for thread-safe logging
    log_queue = queue.Queue()

    def log_to_queue(msg):
        """This function is safe to call from any thread."""
        log_queue.put(msg)

    def poll_log_queue():
        """Move messages from the queue into the Text widget (GUI thread only)."""
        try:
            while True:
                msg = log_queue.get_nowait()
                text.insert("end", msg)
                text.see("end")
        except queue.Empty:
            pass
        # Schedule next poll
        text.after(50, poll_log_queue)

    # Start polling for log messages
    poll_log_queue()

    # NEW: create the Performance tab (live time–CFL & time–error plots)
    create_performance_tab(notebook, csv_path="output/performance_maps.csv")

    # Start the heavy computation in a background thread
    if next_step_callback is not None:
        worker = threading.Thread(
            target=next_step_callback,
            args=(param_path, log_to_queue),
            daemon=True,
        )
        worker.start()
    else:
        # Fallback: run the placeholder in a background thread as well
        worker = threading.Thread(
            target=process_parameter_file,
            args=(param_path, log_to_queue),
            daemon=True,
        )
        worker.start()


def process_parameter_file(param_path, log):
    """
    Placeholder for your later processing / solver.
    'log' is a function that enqueues strings for the Run Output tab.
    Runs in a background thread.
    """
    log("=== IWW-2D-WSI SOLVER ===\n")
    log(f"Reading parameter file: {param_path}\n\n")

    config = configparser.ConfigParser()
    config.read(param_path)

    if "problem" in config:
        prob = config["problem"]
        log(f"Problem name : {prob.get('name', '')}\n")
        log(f"Domain       : {prob.get('xlength', '')} x {prob.get('ylength', '')}\n")
        log(f"Grid         : {prob.get('xmax', '')} x {prob.get('ymax', '')}\n\n")

    if "solver" in config:
        solv = config["solver"]
        log("Solver settings:\n")
        log(f"  Re     = {solv.get('re', '')}\n")
        log(f"  alpha_uv  = {solv.get('alpha_uv', '')}\n")
        log(f"  alpha_p1  = {solv.get('alpha_p1', '')}\n")
        log(f"  alpha_p2  = {solv.get('alpha_p2', '')}\n")
        log(f"  error_thresh = {solv.get('error_thresh', '')}\n\n")

    log("... further processing / simulation would go here ...\n")
    log("Done.\n")


def vof_editor(vof_array, cell_size=15):
    """
    Interactive VOF editor.

    Parameters
    ----------
    vof_array : 2D numpy array
        field.vof_col array with shape (nx, ny), where
        index [i, j] corresponds to cell (x = i, y = j) in the SOLVER.
        The editor inverts the vertical (j) index so that the bottom row
        in the GUI corresponds to j=0 in vof_array.

    cell_size : int
        Size of each cell in pixels in the editor window.

    Returns
    -------
    vof_array : 2D numpy array
        The same array, modified in-place based on user interactions.
    """
    editor = tk.Toplevel()
    editor.title("VOF Editor")

    # Top controls (action + mode)
    control_frame = tk.Frame(editor)
    control_frame.pack(side="top", fill="x", padx=5, pady=5)

    nx, ny = vof_array.shape  # vof_array[i, j_array]

    action_var = tk.StringVar(value="paint")  # 'paint' (1.0) or 'erase' (0.0)
    mode_var = tk.StringVar(value="brush")    # 'brush' or 'rect'

    tk.Label(control_frame, text="Action:").grid(row=0, column=0, padx=2, sticky="w")
    tk.Radiobutton(
        control_frame, text="Paint 1.0", variable=action_var, value="paint"
    ).grid(row=0, column=1, padx=2, sticky="w")
    tk.Radiobutton(
        control_frame, text="Erase 0.0", variable=action_var, value="erase"
    ).grid(row=0, column=2, padx=2, sticky="w")

    tk.Label(control_frame, text="Mode:").grid(row=0, column=3, padx=10, sticky="w")
    tk.Radiobutton(
        control_frame, text="Brush", variable=mode_var, value="brush"
    ).grid(row=0, column=4, padx=2, sticky="w")
    tk.Radiobutton(
        control_frame, text="Rectangle", variable=mode_var, value="rect"
    ).grid(row=0, column=5, padx=2, sticky="w")

    # Canvas with scrollbars
    canvas_frame = tk.Frame(editor)
    canvas_frame.pack(fill="both", expand=True)

    canvas = tk.Canvas(canvas_frame, highlightthickness=0)
    canvas.pack(side="left", fill="both", expand=True)

    scrollbar_y = tk.Scrollbar(canvas_frame, orient="vertical", command=canvas.yview)
    scrollbar_y.pack(side="right", fill="y")
    scrollbar_x = tk.Scrollbar(editor, orient="horizontal", command=canvas.xview)
    scrollbar_x.pack(side="bottom", fill="x")

    canvas.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)

    total_width = nx * cell_size
    total_height = ny * cell_size
    canvas.configure(scrollregion=(0, 0, total_width, total_height))

    def cell_color(value):
        return "#1f77b4" if value >= 0.5 else "white"

    # We work with "GUI indices" (ig, jg): jg increases downward.
    # Map them to solver indices: j_array = ny - 1 - jg
    rect_ids = {}       # rect_id -> (ig, jg)
    cell_to_rect = {}   # (ig, jg) -> rect_id

    # Draw grid (GUI coordinates)
    for ig in range(nx):
        x0 = ig * cell_size
        x1 = x0 + cell_size
        for jg in range(ny):
            j_array = ny - 1 - jg
            y0 = jg * cell_size
            y1 = y0 + cell_size
            val = vof_array[ig, j_array]
            rid = canvas.create_rectangle(
                x0, y0, x1, y1,
                fill=cell_color(val),
                outline="#cccccc",
            )
            rect_ids[rid] = (ig, jg)
            cell_to_rect[(ig, jg)] = rid

    # Helpers for mapping and painting
    def target_value():
        return 1.0 if action_var.get() == "paint" else 0.0

    def set_cell(ig, jg, value):
        if 0 <= ig < nx and 0 <= jg < ny:
            j_array = ny - 1 - jg  # flip vertically for solver storage
            vof_array[ig, j_array] = value
            rid = cell_to_rect.get((ig, jg))
            if rid is not None:
                canvas.itemconfig(rid, fill=cell_color(value))

    def canvas_to_indices(event):
        x = canvas.canvasx(event.x)
        y = canvas.canvasy(event.y)
        ig = int(x // cell_size)
        jg = int(y // cell_size)
        return ig, jg

    # Brush mode: click or drag
    def brush_apply(event):
        ig, jg = canvas_to_indices(event)
        val = target_value()
        set_cell(ig, jg, val)

    # Rectangle mode: two clicks
    rect_start = {"ig": None, "jg": None, "outline": None}

    def rect_click(event):
        ig, jg = canvas_to_indices(event)
        val = target_value()

        if rect_start["ig"] is None:
            # First corner
            rect_start["ig"] = ig
            rect_start["jg"] = jg

            x0 = ig * cell_size
            y0 = jg * cell_size
            x1 = x0 + cell_size
            y1 = y0 + cell_size
            outline_id = canvas.create_rectangle(
                x0, y0, x1, y1,
                outline="#ff0000",
                width=2,
            )
            rect_start["outline"] = outline_id
        else:
            # Second corner -> fill rectangle
            ig0 = rect_start["ig"]
            jg0 = rect_start["jg"]
            ig1 = ig
            jg1 = jg
            if ig0 > ig1:
                ig0, ig1 = ig1, ig0
            if jg0 > jg1:
                jg0, jg1 = jg1, jg0

            for ii in range(ig0, ig1 + 1):
                for jj in range(jg0, jg1 + 1):
                    set_cell(ii, jj, val)

            if rect_start["outline"] is not None:
                canvas.delete(rect_start["outline"])

            rect_start["ig"] = None
            rect_start["jg"] = None
            rect_start["outline"] = None

    # Event dispatchers
    def on_click(event):
        if mode_var.get() == "brush":
            brush_apply(event)
        else:
            rect_click(event)

    def on_drag(event):
        if mode_var.get() == "brush":
            brush_apply(event)
        # Rectangle mode only uses clicks, not drag

    canvas.bind("<Button-1>", on_click)
    canvas.bind("<B1-Motion>", on_drag)

    # Bottom buttons: Clear, Fill, Done
    btn_frame = tk.Frame(editor)
    btn_frame.pack(side="bottom", pady=5)

    def clear_all():
        for ig in range(nx):
            for jg in range(ny):
                set_cell(ig, jg, 0.0)

    def fill_all():
        for ig in range(nx):
            for jg in range(ny):
                set_cell(ig, jg, 1.0)

    clear_btn = tk.Button(btn_frame, text="Clear (all 0.0)", command=clear_all)
    clear_btn.grid(row=0, column=0, padx=5)

    fill_btn = tk.Button(btn_frame, text="Fill (all 1.0)", command=fill_all)
    fill_btn.grid(row=0, column=1, padx=5)

    done_var = tk.BooleanVar(value=False)

    def on_done():
        done_var.set(True)
        editor.destroy()

    done_btn = tk.Button(btn_frame, text="Done", bg="#d9ead3", command=on_done)
    done_btn.grid(row=0, column=2, padx=5)

    # Make this window modal-ish: user must close it before continuing
    editor.grab_set()
    editor.wait_variable(done_var)

    return vof_array


if __name__ == "__main__":
    launch_parameter_gui()
