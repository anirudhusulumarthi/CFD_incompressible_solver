import pyvista as pv
import numpy as np



def print_parameters(params):
    print("\n===== CFD Simulation Parameters =====\n")

    print(f"📘 Problem Name:         {params.problem_name}")
    print(f"📏 Domain Size:          xlength = {params.xlength}, ylength = {params.ylength}")
    print(f"🧮 Grid Size:            xmax = {params.xmax}, ymax = {params.ymax}")
    print(f"🔁 Reynolds Number:      Re = {params.Re}")
    print(f"⚙️  Solver Parameters:")
    print(f"    alpha_uv           = {params.alpha_uv}")
    print(f"    alpha_p1 (during)  = {params.alpha_p1}")
    print(f"    alpha_p2 (post)    = {params.alpha_p2}")
    print(f"    error_threshold    = {params.error_thresh}")

    print(f"⚙️  Solver Parameters:")
    print(f"    alpha_uv           = {params.alpha_uv}")
    print(f"    alpha_p1 (during)  = {params.alpha_p1}")
    print(f"    alpha_p2 (post)    = {params.alpha_p2}")
    print(f"    error_threshold    = {params.error_thresh}")
    print(f"    max_solve_ittr     = {params.max_solve_ittr}")
    print(f"    max_p_ittr/loop    = {params.max_p_ittr_prloop}")

    print(f"\n⏱️ Time Integration:")
    print(f"    start_time        = {params.start_time}")
    print(f"    end_time          = {params.end_time}")
    print(f"    dt                = {params.dt}")
    print(f"    cfl_target        = {params.cfl_target}")
    print(f"    alpha_cfl_target  = {params.alpha_cfl_target}")
    print(f"    max_dt            = {params.max_dt}")
    print(f"    sample            = {params.sample}")

    print(f"\n💧 Fluid Properties:")
    print(f"    Fluid 1: rho = {params.rho_primary}, mu = {params.mu_primary}")
    print(f"    Fluid 2: rho = {params.rho_secondary}, mu = {params.mu_secondary}")

    print("\n===== Boundary Conditions & Initialization =====")
    for wall in ['top', 'right', 'bottom', 'left']:
        print(f"\n🔲 {wall.upper()} WALL")
        for field in ['u', 'v', 'p']:
            init_type, init_val = params.boundary[wall][field]['init']
            bc_type, bc_val = params.boundary[wall][field]['bc']
            print(f"  Init {field.upper()}: {init_type.name.lower():<15} value = {init_val}")
            print(f"  BC   {field.upper()}: {bc_type.name.lower():<15} value = {bc_val}")

    print("\n✅ All parameters successfully loaded and parsed.\n")





##############################################################################################################################################################################################
# VTK Output Function
##############################################################################################################################################################################################


#######################
# PVDWriter
######################

class PVDWriter:
    """Index .vti files with physical time for ParaView."""
    def __init__(self, pvd_path):
        self.pvd_path = pvd_path
        self._records = []  # (relpath, time)
        d = os.path.dirname(pvd_path)
        if d: os.makedirs(d, exist_ok=True)
        self._flush()

    def add(self, file_path, time_value):
        base = os.path.dirname(self.pvd_path) or "."
        rel  = os.path.relpath(file_path, base)
        self._records.append((rel, float(time_value)))
        self._records.sort(key=lambda r: r[1])  # by time
        self._flush()

    def _flush(self):
        with open(self.pvd_path, "w", encoding="utf-8") as f:
            f.write('<?xml version="1.0"?>\n')
            f.write('<VTKFile type="Collection" version="0.1" byte_order="LittleEndian">\n')
            f.write('  <Collection>\n')
            for rel, t in self._records:
                f.write(f'    <DataSet timestep="{t:.16e}" group="" part="0" file="{rel}"/>\n')
            f.write('  </Collection>\n')
            f.write('</VTKFile>\n')


#######################
# VTI
######################

import os, numpy as np

# ---------- utils ----------
def _ensure_dir(path):
    d = os.path.dirname(path)
    if d: os.makedirs(d, exist_ok=True)

def _as_f32(a):  # consistent portable ASCII
    return np.asarray(a, dtype=np.float32, order="C")

def _write_da_ascii(fh, name, arr, ncomp=1):
    fh.write(f'        <DataArray type="Float32" Name="{name}"')
    if ncomp != 1:
        fh.write(f' NumberOfComponents="{ncomp}"')
    fh.write(' format="ascii">\n')
    nx, ny = arr.shape[:2]
    if ncomp == 1:
        for j in range(ny):  # y outer, x inner (x fastest)
            fh.write("          " + " ".join(f"{arr[i, j]:.7e}" for i in range(nx)) + "\n")
    else:
        for j in range(ny):
            row = []
            for i in range(nx):
                vx, vy = arr[i, j, 0], arr[i, j, 1]
                row.append(f"{vx:.7e} {vy:.7e} 0.0")
            fh.write("          " + " ".join(row) + "\n")
    fh.write("        </DataArray>\n")

# ---------- main writer ----------
def writeVTI(grid, filename, *, time=None, origin=(0.0,0.0,0.0), spacing=None):
    """
    Write a 2D ImageData (.vti) with CELL_DATA for a collocated (cell-centered) scheme.

    Expects on `grid`:
      u_cen, v_cen, p_cen, vof_cen : (nx, ny) arrays (cell-centered)
      dx, dy : spacings (used for Spacing=)
    """
    if spacing is None:
        spacing = (float(getattr(grid, "dx", 1.0)),
                   float(getattr(grid, "dy", 1.0)), 1.0)

    u = _as_f32(grid.u_cen); v = _as_f32(grid.v_cen)
    p = _as_f32(grid.p_cen); vof = _as_f32(grid.vof_cen)
    if not (u.shape == v.shape == p.shape == vof.shape):
        raise ValueError("u_cen, v_cen, p_cen, vof_cen must have identical shapes.")
    nx, ny = u.shape  # number of CELLS in x,y

    # ImageData is point-indexed; for cell data, point lattice = (nx+1, ny+1, 1)
    px, py, pz = nx + 1, ny + 1, 1
    extent = (0, px-1, 0, py-1, 0, 0)  # inclusive
    ox, oy, oz = origin
    sx, sy, sz = spacing

    _ensure_dir(filename)
    with open(filename, "w", encoding="utf-8") as fh:
        fh.write('<?xml version="1.0"?>\n')
        fh.write('<VTKFile type="ImageData" version="0.1" byte_order="LittleEndian">\n')
        fh.write(f'  <ImageData WholeExtent="{extent[0]} {extent[1]} {extent[2]} {extent[3]} {extent[4]} {extent[5]}" '
                 f'Origin="{ox:.7e} {oy:.7e} {oz:.7e}" Spacing="{sx:.7e} {sy:.7e} {sz:.7e}">\n')

        # Optional: put TIME in FieldData (handy when opening a single .vti)
        fh.write('    <FieldData>\n')
        if time is not None:
            fh.write('      <DataArray type="Float64" Name="TIME" NumberOfTuples="1" format="ascii">\n')
            fh.write(f'        {float(time):.16e}\n')
            fh.write('      </DataArray>\n')
        fh.write('    </FieldData>\n')

        fh.write(f'    <Piece Extent="{extent[0]} {extent[1]} {extent[2]} {extent[3]} {extent[4]} {extent[5]}">\n')
        fh.write('      <PointData/>\n')  # no point data for collocated scheme

        fh.write('      <CellData Scalars="pressure" Vectors="velocity">\n')
        _write_da_ascii(fh, "pressure", p, ncomp=1)
        vel = np.empty((nx, ny, 2), dtype=np.float32); vel[...,0]=u; vel[...,1]=v
        _write_da_ascii(fh, "velocity", vel, ncomp=3)
        _write_da_ascii(fh, "VOF", vof, ncomp=1)
        fh.write('      </CellData>\n')

        fh.write('    </Piece>\n')
        fh.write('  </ImageData>\n')
        fh.write('</VTKFile>\n')
    return filename
