# ==============================
# File: crux.py
# ==============================

import math

from numba import njit, prange
from numba import set_num_threads, get_num_threads
set_num_threads(12)  # can be overridden externally before import if needed

########################################################################################################################################################################
# X MOMENTUM SOLVER
########################################################################################################################################################################


@njit(parallel=True, fastmath=True, cache=True)
def compute_u(u, v, p, uM1, uM2, rho, rhoM1, rhoM2, mu, dx, dy, dt, alpha_uv, d_ratio_x_1, u_s1, aw, ae, as_, an, ap):
    """
    D = Eta * ( A/di )
    F = Rho * A * u
    (Formulas identical to original.)
    """
    nx, ny = u.shape

    for j in prange(1, ny - 1):
        for i in range(2, nx - 1):
            # Define coefficients to be computed
            eta_w =  mu[i - 1, j]
            eta_e =  mu[i, j]
            eta_s = 0.25 * ( mu[i - 1, j] +  mu[i - 1, j - 1] +  mu[i, j - 1] +  mu[i, j] )
            eta_n = 0.25 * ( mu[i - 1, j] +  mu[i - 1, j + 1] +  mu[i, j + 1 ] +  mu[i, j])
            # //============================================================
            # // Compute convective flux terms (Fi = rho * u * deltaA)
            Fw = (0.5 * ((( rho[i, j] +  rho[i - 1, j]) * 0.5 *  u[i][j]) +
                            (( rho[i - 1, j] +  rho[i - 2, j]) * 0.5 *  u[i - 1][j]))) *  dy
            
            Fe = (0.5 * ((( rho[i, j] +  rho[i - 1, j]) * 0.5 *  u[i][j]) +
                            (( rho[i, j] +  rho[i + 1, j]) * 0.5 *  u[i + 1, j]))) *  dy
            
            Fs = (0.5 * ((( rho[i - 1, j] +  rho[i - 1, j - 1]) * 0.5 *  v[i - 1, j]) +
                            (( rho[i, j] +  rho[i, j - 1]) * 0.5 *  v[i][j]) )) *  dx
            
            Fn = (0.5 * ((( rho[i - 1, j] +  rho[i - 1, j + 1]) * 0.5 *  v[i - 1, j + 1]) +
                            (( rho[i, j] +  rho[i, j + 1]) * 0.5 *  v[i, j + 1]))) *  dx
            # //============================================================
            Dw = eta_w * ( dy /  dx)
            De = eta_e * ( dy /  dx)
            Dn = eta_n * ( dx /  dy)
            Ds = eta_s * ( dx /  dy)

            # // Compute coefficients
            aw[i, j] =  (Dw + max(Fw, 0.0))
            ae[i, j] =  (De + max(-Fe, 0.0))
            as_[i, j] = (Ds + max(Fs, 0.0))
            an[i, j] =  (Dn + max(-Fn, 0.0))

            aw_ij = aw[i, j]
            ae_ij = ae[i, j]
            as_ij = as_[i, j]
            an_ij = an[i, j]

            ap[i, j] = aw_ij + ae_ij + as_ij + an_ij + (Fe - Fw) + (Fn - Fs)
            # //=============================================================
            # // TVD
            # //=============================================================
            Sx, Sy = compute_sources(u, nx, ny, i, j, Fw, Fe, Fs, Fn)
            # //=============================================================
            # // TEMPORAL TERMS
            # //=============================================================
            rho_pc = 0.5 * (rho[i, j] + rho[i - 1, j])
            rho_pM1 = 0.5 * (rhoM1[i, j] + rhoM1[i - 1, j])
            rho_pM2 =  0.5 * (rhoM2[i, j] + rhoM2[i - 1, j])
            St_a     =   2.0 * (rho_pM1 * uM1[i, j] * dx * dy) / (dt)
            St_b     = - 0.5 * (rho_pM2 * uM2[i, j] * dx * dy) / (dt)
            a_ip     =   1.5 * (rho_pc * (dx * dy ))/ (dt)
            ap[i, j] += a_ip
            d_ratio_x_1[i, j] =  dy/ ap[i, j]

            neighbour = ((aw[i, j] *  u[i - 1, j]) + (ae[i, j] *  u[i + 1, j]) +
                            (as_[i, j] *  u[i, j - 1]) + (an[i, j] *  u[i, j + 1])  + (St_a + St_b) + Sx + Sy)/ ap[i, j]
            pressure  = ( p[i - 1, j] -  p[i, j]) *  d_ratio_x_1[i, j]
            u_s1[i, j] = neighbour + pressure
            u_s1[i, j] = ( alpha_uv *  u_s1[i, j])  + ((1- alpha_uv ) *  u[i, j])

    for i in range (1, nx):
        aw[i,0] = aw[i,1]
        aw[i,ny-1] = aw[i,ny-2]
        ae[i,0] = ae[i,1]
        ae[i,ny-1] = ae[i,ny-2]
        as_[i,0] = as_[i,1]
        as_[i,ny-1] = as_[i,ny-2]
        an[i,0] = an[i,1]
        an[i,ny-1] = an[i,ny-2]
        ap[i,0] = ap[i,1]
        ap[i,ny-1] = ap[i,ny-2]

    for j in range (1, ny-1):
        aw[1,j] =  aw[2,j]
        aw[nx-1,j] =  aw[nx-2,j]
        ae[1,j] =  ae[2,j]
        ae[nx-1,j] =  ae[nx-2,j]
        as_[1,j] =  as_[2,j]
        as_[nx-1,j] =  as_[nx-2,j]
        an[1,j] =  an[2,j]
        an[nx-1,j] =  an[nx-2,j]
        ap[1,j] =  ap[2,j]
        ap[nx-1,j] =  ap[nx-2,j]

########################################################################################################################################################################
# Y MOMENTUM SOLVER
########################################################################################################################################################################


@njit(parallel=True, fastmath=True, cache=True)
def compute_v(u, v, p, vM1, vM2, rho, rhoM1, rhoM2, mu, dx, dy, dt, alpha_uv, d_ratio_y_1, v_s1, aw, ae, as_, an, ap):
    """
    Computes predicted v velocity field using momentum equation.
    (Formulas identical to original.)
    """
    nx, ny = v.shape

    for j in prange(2, ny -1):
        for i in range(1, nx - 1):
            eta_w = 0.25*(mu[i, j] + mu[i - 1, j] + mu[i - 1, j -1] + mu[i, j - 1])
            eta_e = 0.25*(mu[i, j] + mu[i + 1, j] + mu[i, j - 1] + mu[i + 1, j - 1])
            eta_s = mu[i, j - 1]
            eta_n = mu[i, j]

            Fw = 0.5 * ((0.5 * (rho[i, j] + rho[i - 1, j]) * u[i, j]) +
                                (0.5 * (rho[i, j - 1] + rho[i - 1, j - 1]) * u[i, j - 1]) ) * dy
            
            Fe = 0.5 * ((0.5 * (rho[i, j] + rho[i + 1, j]) * u[i + 1, j]) +
                        (0.5 * (rho[i, j - 1] + rho[i + 1, j - 1]) * u[i + 1, j - 1]) ) * dy
            
            Fs = 0.5 * ((0.5 * (rho[i, j] + rho[i, j - 1]) * v[i, j]) +
                                (0.5 * (rho[i, j - 1] + rho[i, j - 2]) * v[i, j - 1]) ) * dx
            
            Fn = 0.5 * ((0.5 * (rho[i, j] + rho[i, j - 1]) * v[i, j]) +
                                (0.5 * (rho[i, j] + rho[i, j + 1]) * v[i, j + 1]) ) * dx

            Dw = eta_w * (dy / dx)
            De = eta_e * (dy / dx)
            Dn = eta_n * (dx / dy)
            Ds = eta_s * (dx / dy)

            aw[i, j] = Dw +  max(Fw, 0.0)
            ae[i, j] = De + max(-Fe, 0.0)
            as_[i, j] = Ds + max(Fs, 0.0)
            an[i, j] = Dn + max(-Fn, 0.0)

            aw_ij = aw[i, j]
            ae_ij = ae[i, j]
            as_ij = as_[i, j]
            an_ij = an[i, j]

            ap[i, j] = aw_ij + ae_ij + as_ij + an_ij + (Fe - Fw) + (Fn - Fs)
            # //=============================================================
            # // TVD
            # //=============================================================
            Sx, Sy = compute_sources(u, nx, ny, i, j, Fw, Fe, Fs, Fn)

            rho_pc = 0.5 * (rho[i, j] + rho[i, j - 1])
            rho_pM1 = 0.5 * (rhoM1[i, j] + rhoM1[i, j - 1])
            rho_pM2 =  0.5 * (rhoM2[i, j] + rhoM2[i, j - 1])
            St_a     =   2.0 * (rho_pM1 * vM1[i, j] * dx * dy) / (dt)
            St_b     = - 0.5 * (rho_pM2 * vM2[i, j] * dx * dy) / (dt)
            a_ip     =   1.5 * (rho_pc * (dx * dy ))/ (dt)
            ap[i, j] += a_ip

            d_ratio_y_1[i, j] = dx / ap[i, j]
            rho_avg = 0.5 * (rho[i, j] + rho[i, j-1])
            gravity = rho_avg * d_ratio_y_1[i, j] * dy * (-9.81)

            neighbour = (((aw[i, j] * v[i - 1, j]) +  (ae[i, j] * v[i + 1, j]) +
                            (as_[i, j] * v[i, j - 1]) + (an[i, j] * v[i, j + 1])) + (St_a + St_b) + Sx + Sy) / ap[i, j]

            pressure =  d_ratio_y_1[i, j] * (p[i, j - 1] - p[i, j])
            v_s1[i, j] =  neighbour + pressure + gravity
            v_s1[i, j] = (alpha_uv * v_s1[i, j]) + (1 - alpha_uv) * v[i, j]

    for i in range (0, nx):
        aw[i,1] = aw[i,2]
        aw[i,ny-1] = aw[i,ny-2]
        ae[i,1] = ae[i,2]
        ae[i,ny-1] = ae[i,ny-2]
        as_[i,1] = as_[i,2]
        as_[i,ny-1] = as_[i,ny-2]
        an[i,1] = an[i,2]
        an[i,ny-1] = an[i,ny-2]
        ap[i,1] = ap[i,2]
        ap[i,ny-1] = ap[i,ny-2]

    for j in range (1, ny-1):
        aw[1,j] =  aw[2,j]
        aw[nx-1,j] =  aw[nx-2,j]
        ae[1,j] =  ae[2,j]
        ae[nx-1,j] =  ae[nx-2,j]
        as_[1,j] =  as_[2,j]
        as_[nx-1,j] =  as_[nx-2,j]
        an[1,j] =  an[2,j]
        an[nx-1,j] =  an[nx-2,j]
        ap[1,j] =  ap[2,j]
        ap[nx-1,j] =  ap[nx-2,j]

########################################################################################################################################################################
# PRESSURE MATRIX BUILDING (first)
########################################################################################################################################################################


@njit(parallel=True, fastmath=True, cache=True)
def compute_p_1(u_s1, v_s1, p_s1, b, rho, rhoM1, rhoM2, dx, dy, dt, drx, dry):
    pnx, pny =  p_s1.shape

    for j in prange(1, pny -1):
        for i in range(1, pnx - 1):

            aw = (  drx[i, j] *  dx)
            ae = (  drx[i + 1, j] *  dx)
            as_ = ( dry[i, j] *  dy)
            an = (  dry[i, j + 1] *  dy)
            ap = (aw + ae + as_ + an)

            temporal_numerator = (3 * rho[i, j]) - 4 * rhoM1[i, j] + rhoM2[i, j]
            Temporal_rho =  (temporal_numerator  * (dx * dy)) / (2 * rho[i, j] * dt)

            b[i, j] = ((( u_s1[i, j]-  u_s1[i + 1, j])* dy) + \
                      (( v_s1[i, j] -  v_s1[i, j + 1]) * dx))

            neighbour = ((aw *  p_s1[i - 1, j]) + (ae *  p_s1[i + 1, j]) + \
                        (as_ *  p_s1[i, j - 1]) + (an *  p_s1[i, j + 1]))
            
            p_s1[i, j] = ( neighbour + (b[i, j]) - (Temporal_rho)) / (ap)


########################################################################################################################################################################
# PRESSURE 2 MATRIX BUILDING
########################################################################################################################################################################


@njit(parallel=True, fastmath=True, cache=True)
def compute_p_2(u_s2, v_s2, u_s3, v_s3, p_s3, b2, b3, rho, rhoM1, rhoM2, dx, dy, dt, drx, dry, uaw, uae, uas_, uan, uap, vaw, vae, vas_, van, vap):
    pnx, pny =  p_s3.shape

    for j in prange(1, pny -1):
        for i in range(1, pnx - 1):
            

            aw = (  drx[i, j] *  dx)
            ae = (  drx[i + 1, j] *  dx)
            as_ = ( dry[i, j] *  dy)
            an = (  dry[i, j + 1] *  dy)
            ap = (aw + ae + as_ + an)

            temporal_numerator = (3 * rho[i, j]) - 4 * rhoM1[i, j] + rhoM2[i, j]
            Temporal_rho =  (temporal_numerator  * (dx * dy)) / (2 * rho[i, j] * dt)

            b2[i, j] = (((  u_s3[i, j] -   u_s3[i + 1, j])* dy) + \
                                ((   v_s3[i, j] -   v_s3[i, j + 1]) *  dx))

            step_west = (
                            uaw[i, j] * (u_s3[i - 1, j] - u_s2[i - 1, j]) / uap[i, j]
                        ) + (
                            uae[i, j] * (u_s3[i + 1, j] - u_s2[i + 1, j]) / uap[i, j]
                        ) + (
                            uan[i, j] * (u_s3[i, j + 1] - u_s2[i, j + 1]) / uap[i, j]
                        ) + (
                            uas_[i, j] * (u_s3[i, j - 1] - u_s2[i, j - 1]) / uap[i, j]
                        )
            
            step_east = (
                            uaw[i + 1, j] * (u_s3[i, j] - u_s2[i, j]) / uap[i + 1, j]
                        ) + (
                            uae[i + 1, j] * (u_s3[i + 2, j] - u_s2[i + 2, j]) / uap[i + 1, j]
                        ) + (
                            uan[i + 1, j] * (u_s3[i + 1, j + 1] - u_s2[i + 1, j + 1]) / uap[i + 1, j]
                        ) + (
                            uas_[i + 1, j] * (u_s3[i + 1, j - 1] - u_s2[i + 1, j - 1]) / uap[i + 1, j]
                        )

            step_south = (
                            vaw[i, j] * (v_s3[i - 1, j] - v_s2[i - 1, j]) / vap[i, j]
                        ) + (
                            vae[i, j] * (v_s3[i + 1, j] - v_s2[i + 1, j]) / vap[i, j]
                        ) + (
                            vas_[i, j] * (v_s3[i, j - 1] - v_s2[i, j - 1]) / vap[i, j]
                        ) + (
                            van[i, j] * (v_s3[i, j + 1] - v_s2[i, j + 1]) / vap[i, j]
                        )

            step_north = (
                            vaw[i, j + 1] * (v_s3[i - 1, j + 1] - v_s2[i - 1, j + 1]) / vap[i, j + 1]
                        ) + (
                            vae[i, j + 1] * (v_s3[i + 1, j + 1] - v_s2[i + 1, j + 1]) / vap[i, j + 1]
                        ) + (
                            vas_[i, j + 1] * (v_s3[i, j] - v_s2[i, j]) / vap[i, j + 1]
                        ) + (
                            van[i, j + 1] * (v_s3[i, j + 2] - v_s2[i, j + 2]) / vap[i, j + 1]
                        )

            b3[i, j] = ( step_west -  step_east ) * dy + ( step_south -  step_north)  * dx 

            neighbour = ((aw *  p_s3[i - 1, j]) + (ae *  p_s3[i + 1, j]) + \
                        (as_ *  p_s3[i, j - 1]) + (an *  p_s3[i, j + 1]))
            
            p_s3[i, j] = ( neighbour + b2[i, j] + b3[i, j] - Temporal_rho ) / (ap)



########################################################################################################################################################################
# NEW: CORRECTION KERNELS (formula-preserving)
########################################################################################################################################################################


@njit(parallel=True, fastmath=True, cache=True)
def corr_u_s2(u_s1, p_s1, d_ratio_x_1, u_s2):
    nx, ny = u_s1.shape
    for j in prange(1, ny - 1):
        for i in range(2, nx - 1):
            u_s2[i, j] = u_s1[i, j] + (d_ratio_x_1[i, j] * (p_s1[i - 1, j] - p_s1[i, j]))


@njit(parallel=True, fastmath=True, cache=True)
def corr_v_s2(v_s1, p_s1, d_ratio_y_1, v_s2):
    nx, ny = v_s1.shape
    for j in prange(2, ny - 1):
        for i in range(1, nx - 1):
            v_s2[i, j] = v_s1[i, j] + (d_ratio_y_1[i, j] * (p_s1[i, j - 1] - p_s1[i, j]))


@njit(parallel=True, fastmath=True, cache=True)
def corr_u_final(u_s2, u_s3, p_s3, d_ratio_x_2, aw_u2, ae_u2, as_u2, an_u2, ap_u2, u_final):
    unx, uny = u_s2.shape
    for j in prange(1, uny - 1):
        for i in range(2, unx - 1):
            subt_vel = (
                aw_u2[i, j] * (u_s3[i - 1, j] - u_s2[i - 1, j]) / ap_u2[i, j]
            ) + (
                ae_u2[i, j] * (u_s3[i + 1, j] - u_s2[i + 1, j]) / ap_u2[i, j]
            ) + (
                an_u2[i, j] * (u_s3[i, j + 1] - u_s2[i, j + 1]) / ap_u2[i, j]
            ) + (
                as_u2[i, j] * (u_s3[i, j - 1] - u_s2[i, j - 1]) / ap_u2[i, j]
            )
            u_final[i, j] = u_s3[i, j] + subt_vel + (d_ratio_x_2[i, j] * (p_s3[i - 1, j] - p_s3[i, j]))


@njit(parallel=True, fastmath=True, cache=True)
def corr_v_final(v_s2, v_s3, p_s3, d_ratio_y_2, aw_v2, ae_v2, as_v2, an_v2, ap_v2, v_final):
    vnx, vny = v_s2.shape
    for j in prange(2, vny - 1):
        for i in range(1, vnx - 1):
            subt_vel = (
                aw_v2[i, j] * (v_s3[i - 1, j] - v_s2[i - 1, j]) / ap_v2[i, j]
            ) + (
                ae_v2[i, j] * (v_s3[i + 1, j] - v_s2[i + 1, j]) / ap_v2[i, j]
            ) + (
                as_v2[i, j] * (v_s3[i, j - 1] - v_s2[i, j - 1]) / ap_v2[i, j]
            ) + (
                an_v2[i, j] * (v_s3[i, j + 1] - v_s2[i, j + 1]) / ap_v2[i, j]
            )
            v_final[i, j] = v_s3[i, j] + subt_vel + (d_ratio_y_2[i, j] * (p_s3[i, j - 1] - p_s3[i, j]))

########################################################################################################################################################################
# REDUCTION & UTILITIES
########################################################################################################################################################################


@njit(parallel=True, fastmath=True, cache=True)
def reduce_abs_sum_interior(arr):
    nx, ny = arr.shape
    acc = 0.0
    for j in prange(1, ny - 1):
        s = 0.0
        for i in range(1, nx - 1):
            s += abs(arr[i, j])
        acc += s
    return acc

@njit(parallel=True, fastmath=True, cache=True)
def update_central_fields_njit(u_cen, v_cen, p_cen, vof_cen, u_final, v_final, p_final, vof):
    cnx, cny = u_cen.shape
    for j in prange(cny):
        for i in range(cnx):
            u_cen[i, j] = 0.5 * (u_final[i + 1, j + 1] +  u_final[i + 1, j])
            v_cen[i, j] = 0.5 * (v_final[i, j + 1] +  v_final[i + 1, j + 1])
            p_cen[i, j] = 0.25 * (p_final[i, j] +  p_final[i, j + 1] +  p_final[i + 1, j + 1] +  p_final[i + 1, j])
            vof_cen[i, j] = 0.25 * (vof[i, j] +  vof[i, j + 1] +  vof[i + 1, j + 1] +  vof[i + 1, j])


@njit(parallel=False, fastmath=True, cache=True)
def clear_fields_njit(u_s1, v_s1, p_s1, u_s2, v_s2, p_s2, u_s3, v_s3, p_s3, coNum, alpha_coNum):
    u_s1[:] = 0.0
    v_s1[:] = 0.0
    p_s1[:] = 0.0
    u_s2[:] = 0.0
    v_s2[:] = 0.0
    p_s2[:] = 0.0
    u_s3[:] = 0.0
    v_s3[:] = 0.0
    p_s3[:] = 0.0
    coNum[:] = 0.0
    alpha_coNum[:] = 0.0

########################################################################################################################################################################
# VOF Updates 
########################################################################################################################################################################
from numba import njit, prange
import numpy as np

@njit(inline='always')
def mc_limiter(r):
    if r <= 0.0: 
        return 0.0
    a = 2.0*r
    b = 0.5*(1.0 + r)
    return 2.0 if 2.0 < a and 2.0 < b else (a if a < b else b)

@njit(inline='always')
def face_alpha(alpha, i, j, F, dt, V, dirx, nx, ny, eps=1e-14):
    # MUSCL at a face; fall back to donor-cell if the 2nd-upwind index would be OOB.
    if F == 0.0:
        return alpha[i, j]
    if dirx:  # x-face
        if F > 0.0:
            if i-1 < 0:                 # no 2nd-upwind available
                return alpha[i, j]      # donor
            up2 = alpha[i-1, j]; up = alpha[i, j]; dn = alpha[i+1, j]
        else:
            if i+2 >= nx:               # no 2nd-upwind available
                return alpha[i+1, j]    # donor
            up2 = alpha[i+2, j]; up = alpha[i+1, j]; dn = alpha[i, j]
    else:    # y-face
        if F > 0.0:
            if j-1 < 0:
                return alpha[i, j]
            up2 = alpha[i, j-1]; up = alpha[i, j]; dn = alpha[i, j+1]
        else:
            if j+2 >= ny:
                return alpha[i, j+1]
            up2 = alpha[i, j+2]; up = alpha[i, j+1]; dn = alpha[i, j]
    du = up - up2
    dd = dn - up
    r  = du / (dd + np.copysign(eps, dd))
    phi = mc_limiter(r)
    Cface = abs(F) * dt / V
    if Cface > 1.0:  # be safe
        Cface = 1.0
    return up + 0.5 * phi * (1.0 - Cface) * dd

@njit(parallel=True, cache=True)
def compute_vof(vof, u, v, vofM1, vofM2, dx, dy, dt, mask, use_tvd=True):
    nx, ny = vof.shape
    V = dx*dy
    # freeze α^n with one ghost layer
    a = vofM1.copy()
    a[0,:]=a[1,:]; a[-1,:]=a[-2,:]; a[:,0]=a[:,1]; a[:,-1]=a[:,-2]

    for j in prange(1, ny-1):
        for i in range(1, nx-1):
            if mask[i, j] == 1:
                continue
            Fw = u[i,   j]*dy; Fe = u[i+1, j]*dy
            Fs = v[i,   j]*dx; Fn = v[i,   j+1]*dx

            if use_tvd:
                aw = face_alpha(a, i-1, j, Fw, dt, V, True,  nx, ny)
                ae = face_alpha(a, i,   j, Fe, dt, V, True,  nx, ny)
                as_ = face_alpha(a, i, j-1, Fs, dt, V, False, nx, ny)
                an  = face_alpha(a, i,   j, Fn, dt, V, False, nx, ny)
            else:
                aw = a[i-1,j] if Fw>0 else a[i,  j]
                ae = a[i,  j] if Fe>0 else a[i+1,j]
                as_ = a[i, j-1] if Fs>0 else a[i,  j]
                an  = a[i,  j] if Fn>0 else a[i,  j+1]

            netC = Fe*ae - Fw*aw + Fn*an - Fs*as_
            Div  = (Fe - Fw) + (Fn - Fs)

            a_n   = vofM1[i,j]
            a_nm1 = vofM2[i,j]
            # constant-preserving BDF2
            a_np1 = ((4.0*a_n - a_nm1) - (2.0*dt/V)*(netC - a_n*Div)) / 3.0

            if   a_np1 < 0.0: a_np1 = 0.0
            elif a_np1 > 1.0: a_np1 = 1.0
            vof[i,j] = a_np1

    vof[0,:]=vof[1,:]; vof[-1,:]=vof[-2,:]; vof[:,0]=vof[:,1]; vof[:,-1]=vof[:,-2]

##################################################################
########################################################################################################################################################################
@njit(parallel=True, fastmath=True, cache=True)
def update_scalars(vof, rho, mu, rho_primary, mu_primary, rho_secondary, mu_secondary):

    nx, ny = vof.shape

    for j in prange(1, ny - 1):
        for i in range(1, nx - 1):
            rho[i, j] = vof[i, j] * rho_primary + (1 - vof[i, j]) * rho_secondary
            mu[i, j] = vof[i, j] * mu_primary + (1 - vof[i, j]) * mu_secondary

########################################################################################################################################################################
# TVD
########################################################################################################################################################################

@njit(fastmath=True, cache=True)
def compute_sources(phi, nx, ny, i, j, fw, fe, fs, fn):
    """
    Computes the sources for the TVD flux limiter at (i, j).
    Requires a two-cell interior because the stencil uses i±2, j±2.
    """
    # Helper: clamp indices to valid range [0, nx-1] / [0, ny-1]
    def ix(k):  # x-index clamp
        return 0 if k < 0 else (nx - 1 if k > nx - 1 else k)
    def iy(k):  # y-index clamp
        return 0 if k < 0 else (ny - 1 if k > ny - 1 else k)

    # Pre-clamped neighbor indices so we can run safely near boundaries
    im2, im1, ip1, ip2 = ix(i - 2), ix(i - 1), ix(i + 1), ix(i + 2)
    jm2, jm1, jp1, jp2 = iy(j - 2), iy(j - 1), iy(j + 1), iy(j + 2)

    Source_x = 0.0
    Source_y = 0.0

    # Upwinding switches
    alfaw = 1.0 if fw > 0.0 else 0.0   # depends on fw (west face)
    alfae = 1.0 if fe > 0.0 else 0.0   # depends on fe (east face)
    alfas = 1.0 if fs > 0.0 else 0.0   # south
    alfan = 1.0 if fn > 0.0 else 0.0   # north

    # ---- X-direction ----
    delta_lw = 0.0
    delta_le = 0.0
    delta_rw = 0.0
    delta_re = 0.0

    # fw > 0
    if fw > 0.0:
        denom = (phi[i, j] - phi[im1, j])
        if denom != 0.0:
            t = (phi[im1, j] - phi[im2, j]) * denom
            if t <= denom * denom:
                rw_plus = (phi[im1, j] - phi[im2, j]) / denom
                delta_lw = 0.5 * (rw_plus + abs(rw_plus)) * (0.25 * rw_plus * rw_plus - 1.25 * rw_plus + 2.0)
            else:
                rw_plus = (phi[im1, j] - phi[im2, j]) / denom
                delta_lw = (3.0 * rw_plus + 1.0) / (2.0 * rw_plus + 2.0)

    # fe > 0
    if fe > 0.0:
        denom = (phi[ip1, j] - phi[i, j])
        if denom != 0.0:
            t = (phi[i, j] - phi[im1, j]) * denom
            if t <= denom * denom:
                re_plus = (phi[i, j] - phi[im1, j]) / denom
                delta_le = 0.5 * (re_plus + abs(re_plus)) * (0.25 * re_plus * re_plus - 1.25 * re_plus + 2.0)
            else:
                re_plus = (phi[i, j] - phi[im1, j]) / denom
                delta_le = (3.0 * re_plus + 1.0) / (2.0 * re_plus + 2.0)

    # fw < 0
    if fw < 0.0:
        denom = (phi[i, j] - phi[im1, j])
        if denom != 0.0:
            t = (phi[ip1, j] - phi[i, j]) * (phi[i, j] - phi[im1, j])
            if t <= denom * denom:
                rw_mines = (phi[ip1, j] - phi[i, j]) / denom
                delta_rw = 0.5 * (rw_mines + abs(rw_mines)) * (0.25 * rw_mines * rw_mines - 1.25 * rw_mines + 2.0)
            else:
                rw_mines = (phi[ip1, j] - phi[i, j]) / denom
                delta_rw = (3.0 * rw_mines + 1.0) / (2.0 * rw_mines + 2.0)

    # fe < 0
    if fe < 0.0:
        denom = (phi[ip1, j] - phi[i, j])
        if denom != 0.0:
            t = (phi[ip2, j] - phi[ip1, j]) * (phi[ip1, j] - phi[i, j])
            if t <= denom * denom:
                re_mines = (phi[ip2, j] - phi[ip1, j]) / (phi[ip1, j] - phi[i, j])
                delta_re = 0.5 * (re_mines + abs(re_mines)) * (0.25 * re_mines * re_mines - 1.25 * re_mines + 2.0)
            else:
                re_mines = (phi[ip2, j] - phi[ip1, j]) / (phi[ip1, j] - phi[i, j])
                delta_re = (3.0 * re_mines + 1.0) / (2.0 * re_mines + 2.0)

    Source_x = (
        0.5 * fe * (phi[ip1, j] - phi[i, j]) * ((1.0 - alfae) * delta_re - alfae * delta_le)
        + 0.5 * fw * (phi[i, j] - phi[im1, j]) * (alfaw * delta_lw - (1.0 - alfaw) * delta_rw)
    )

    # ---- Y-direction ----
    delta_ls = 0.0
    delta_ln = 0.0
    delta_rs = 0.0
    delta_rn = 0.0

    # fs > 0
    if fs > 0.0:
        denom = (phi[i, j] - phi[i, jm1])
        if denom != 0.0:
            t = (phi[i, jm1] - phi[i, jm2]) * denom
            if t <= denom * denom:
                rs_plus = (phi[i, jm1] - phi[i, jm2]) / denom
                delta_ls = 0.5 * (rs_plus + abs(rs_plus)) * (0.25 * rs_plus * rs_plus - 1.25 * rs_plus + 2.0)
            else:
                rs_plus = (phi[i, jm1] - phi[i, jm2]) / denom
                delta_ls = (3.0 * rs_plus + 1.0) / (2.0 * rs_plus + 2.0)

    # fn > 0
    if fn > 0.0:
        denom = (phi[i, jp1] - phi[i, j])
        if denom != 0.0:
            t = (phi[i, j] - phi[i, jm1]) * denom
            if t <= denom * denom:
                rn_plus = (phi[i, j] - phi[i, jm1]) / denom
                delta_ln = 0.5 * (rn_plus + abs(rn_plus)) * (0.25 * rn_plus * rn_plus - 1.25 * rn_plus + 2.0)
            else:
                rn_plus = (phi[i, j] - phi[i, jm1]) / denom
                delta_ln = (3.0 * rn_plus + 1.0) / (2.0 * rn_plus + 2.0)

    # fs < 0
    if fs < 0.0:
        denom = (phi[i, j] - phi[i, jm1])
        if denom != 0.0:
            t = (phi[i, jp1] - phi[i, j]) * (phi[i, j] - phi[i, jm1])
            if t <= denom * denom:
                rs_mines = (phi[i, jp1] - phi[i, j]) / denom
                delta_rs = 0.5 * (rs_mines + abs(rs_mines)) * (0.25 * rs_mines * rs_mines - 1.25 * rs_mines + 2.0)
            else:
                rs_mines = (phi[i, jp1] - phi[i, j]) / denom
                delta_rs = (3.0 * rs_mines + 1.0) / (2.0 * rs_mines + 2.0)

    # fn < 0
    if fn < 0.0:
        denom = (phi[i, jp1] - phi[i, j])
        if denom != 0.0:
            t = (phi[i, jp2] - phi[i, jp1]) * (phi[i, jp1] - phi[i, j])
            if t <= denom * denom:
                rn_mines = (phi[i, jp2] - phi[i, jp1]) / (phi[i, jp1] - phi[i, j])
                delta_rn = 0.5 * (rn_mines + abs(rn_mines)) * (0.25 * rn_mines * rn_mines - 1.25 * rn_mines + 2.0)
            else:
                rn_mines = (phi[i, jp2] - phi[i, jp1]) / (phi[i, jp1] - phi[i, j])
                delta_rn = (3.0 * rn_mines + 1.0) / (2.0 * rn_mines + 2.0)

    Source_y = (
        0.5 * fn * (phi[i, jp1] - phi[i, j]) * ((1.0 - alfan) * delta_rn - alfan * delta_ln)
        + 0.5 * fs * (phi[i, j] - phi[i, jm1]) * (alfas * delta_ls - (1.0 - alfas) * delta_rs)
    )

    return Source_x, Source_y

