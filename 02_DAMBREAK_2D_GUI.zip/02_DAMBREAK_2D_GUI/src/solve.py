
# ==============================
# File: solve.py
# ==============================
import numpy as np
from src.boundary import apply_initialization, setup_bc_functions
from src.crux import (
    compute_u,
    compute_v,
    compute_p_1,
    compute_p_2,
    corr_u_s2,
    corr_v_s2,
    corr_u_final,
    corr_v_final,
    reduce_abs_sum_interior,
    update_central_fields_njit,
    clear_fields_njit,
    update_scalars,
    compute_vof
)
from src.output import writeVTI,PVDWriter 
from src.structure import object_points, setup_fsi_zeroing_functions
########################################################################
from numba import njit, prange
from numba import set_num_threads
set_num_threads(12)
########################################################################
def uvp_Transient_solve(field, params):
    """
    Transient NS equations solver (PISO-like), formula-preserving.
    Performance improvements:
      - JIT kernels for inner Python loops (corrections, error reductions, field utilities)
      - Optional lower VTK frequency via params.vtk_every (default=10)
      - Minor housekeeping (remove redundant increments, tiny fixes)
    """
    print("[INFO] Starting transient NS equations solver.")
    print(f"[INFO] Using dx={field.dx}, dy={field.dy}, dt={field.dt}")
    print(f"[INFO] Total columns in a grid: (xmax)={field.xmax}, Total rows in a grid: (ymax)={field.ymax}")
    print(f"[INFO] Using xmax={params.xlength}, ymax={params.ylength}")
    print(f"[INFO] Using alpha_uv={params.alpha_uv}, alpha_p={params.alpha_p1}")
    print(f"[INFO] Using error_threshold={params.error_thresh}")
    print(f"[INFO] The Dt: {field.dt}")
    total_time = params.end_time - params.start_time
    Time_steps = int((total_time) / field.dt)

    current_time = 0
    # // ===============================================================
    stall_window = 400
    stall_rtol = 0.9
    eps = 1e-15

    # //================================================================
    # // INITIALIZATION OF FIELDS and BOUNDARY CONDITIONS
    # //================================================================
    initilize_fields(field, params)
    bc_funcs = setup_bc_functions(field, params)
    pts = object_points(params)
    fsi_funcs = setup_fsi_zeroing_functions(field, pts, params)
    mask = build_solid_mask(params, pts)
    pvd = PVDWriter("output/simulation.pvd")
    print("[INFO] Fields initialized and boundary conditions set.")
    output_interval = params.sample
    next_output_time = params.start_time
    eps = 1e-12

    # //================================================================

    # Prepare frequent BC bindings (single lookup per name)
    def bind_bc(name):
        return (
            bc_funcs[("right", name)],
            bc_funcs[("left", name)],
            bc_funcs[("top", name)],
            bc_funcs[("top_left", name, params.top_left)],
            bc_funcs[("top_right", name, params.top_right)],
            bc_funcs[("bottom", name)],
            bc_funcs[("bottom_left", name, params.bottom_left)],
            bc_funcs[("bottom_right", name, params.bottom_right)],
        )

    # Bind once per field kind
    bc_u_s1 = bind_bc("u_s1")
    bc_v_s1 = bind_bc("v_s1")
    bc_p_s1 = bind_bc("p_s1")
    bc_u_s2 = bind_bc("u_s2")
    bc_v_s2 = bind_bc("v_s2")
    bc_u_s3 = bind_bc("u_s3")  # NEW: correct BC set for u_s3
    bc_v_s3 = bind_bc("v_s3")  # NEW: correct BC set for v_s3
    bc_p_s3 = bind_bc("p_s3")
    bc_u_fin = bind_bc("u_final")
    bc_v_fin = bind_bc("v_final")

    # FSI bindings
    fsi_u_s1 = fsi_funcs[("u_s1",)]
    fsi_v_s1 = fsi_funcs[("v_s1",)]
    fsi_u_s3 = fsi_funcs[("u_s3",)]
    fsi_v_s3 = fsi_funcs[("v_s3",)]
    fsi_u_fin = fsi_funcs[("u_final",)]
    fsi_v_fin = fsi_funcs[("v_final",)]
    
    # //===========================
    # Time-history buffers (match original order exactly)
    field.u_M2[:] = field.u[:]
    field.v_M2[:] = field.v[:]
    field.p_M2[:] = field.p[:]
    field.rho_M2[:] = field.rho[:]
    field.vof_M2[:] = field.vof[:]

    field.u_M1[:] = field.u[:]
    field.v_M1[:] = field.v[:]
    field.p_M1[:] = field.p[:]
    field.rho_M1[:] = field.rho[:]
    field.vof_M1[:] = field.vof[:]
    time_step = 0

    while current_time < params.end_time:
        Time_steps = int(params.end_time / field.dt)
        nans, stalled, error_post_PISOR = solver(field, current_time, 
                stall_window, stall_rtol,
                time_step, Time_steps, params,
                bc_u_s1, bc_v_s1, bc_p_s1,
                bc_u_s2, bc_v_s2,
                bc_u_s3, bc_v_s3,  
                bc_p_s3, bc_u_fin, bc_v_fin,
                fsi_u_s1, fsi_v_s1, fsi_u_s3, fsi_v_s3, fsi_u_fin, fsi_v_fin)
        if nans:
            break      
        # //==============================
        compute_vof(field.vof, field.u_final, field.v_final, field.vof_M1, field.vof_M2, field.dx, field.dy, field.dt, mask, use_tvd=True)
        update_scalars(field.vof, field.rho, field.mu, params.rho_primary, params.mu_primary, params.rho_secondary, params.mu_secondary)
        # //==============================
        update_central_fields_njit(field.u_cen, field.v_cen, field.p_cen, field.vof_cen, field.u_final, field.v_final, field.p_final, field.vof)
        # //=============================
        while current_time + eps >= next_output_time:
            fname = f"output/sim_{time_step:05}.vti"
            writeVTI(field, fname, time=next_output_time)
            pvd.add(fname, next_output_time)
            next_output_time += output_interval
            
        field.u_M2[:] = field.u_M1[:]
        field.v_M2[:] = field.v_M1[:]
        field.p_M2[:] = field.p_M1[:]
        field.rho_M2[:] = field.rho_M1[:]
        field.vof_M2[:] = field.vof_M1[:]

        field.u_M1[:] = field.u_final[:]
        field.v_M1[:] = field.v_final[:]
        field.p_M1[:] = field.p_final[:]
        field.rho_M1[:] = field.rho[:]
        field.vof_M1[:] = field.vof[:]
        # //==============================
        field.u[:] = field.u_final[:]
        field.v[:] = field.v_final[:]
        field.p[:] = field.p_final[:]
        # //==============================
        cfl_current, alpha_cfl_current = compute_cfl(field.coNum, field.alpha_coNum, field.u_final, field.v_final, field.vof, field.dt, field.dx, field.dy)
        if np.isnan(cfl_current) or np.isnan(alpha_cfl_current):
            print("[ERROR] NaN encountered in CFL computation, aborting.")
            break
        open("output/performance_maps.csv", "a").write(f"{current_time:04},{cfl_current}, {error_post_PISOR}\n")
        # //==============================
        clear_fields_njit(field.u_s1, field.v_s1, field.p_s1,
                          field.u_s2, field.v_s2, field.p_s2,
                          field.u_s3, field.v_s3, field.p_s3,
                          field.coNum, field.alpha_coNum)
        # //==============================
        current_time += field.dt
        time_step += 1
        # //==============================
        field.dt = update_dt(cfl_current, alpha_cfl_current, params.cfl_target, params.alpha_cfl_target, field.dt, params.max_dt)
        # //==============================
        


########################################################################################################################################################################
# SOLVER
########################################################################################################################################################################

def _call_bc(bc_tuple):
    r, l, t, tl, tr, b, bl, br = bc_tuple
    r(); l(); t(); tl(); tr(); b(); bl(); br()


def solver(field, current_time, 
           stall_window, stall_rtol,
           time_step, time_steps, params,
           bc_u_s1, bc_v_s1, bc_p_s1,
           bc_u_s2, bc_v_s2,
           bc_u_s3, bc_v_s3,
           bc_p_s3, bc_u_fin, bc_v_fin,
           fsi_u_s1, fsi_v_s1, fsi_u_s3, fsi_v_s3, fsi_u_fin, fsi_v_fin):
    # //================================================================
    step = 0
    error = 1.0
    err_hist = []
    nans = False
    stalled = False

    # //================================================================
    while error > params.error_thresh and step < params.max_solve_ittr:
        # //============================================================
        # // X- Momentum Equation
        # //============================================================
        compute_u(field.u, field.v, field.p, field.u_M1, field.u_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dt,
                  params.alpha_uv, field.d_ratio_x_1, field.u_s1,
                  field.aw_u1, field.ae_u1, field.as_u1, field.an_u1, field.ap_u1)

        # //============================================================
        # // BOUNDARY CONDITIONS FOR U
        # //============================================================
        _call_bc(bc_u_s1)

        # //============================================================
        # // Y- Momentum Equation
        # //============================================================
        compute_v(field.u, field.v, field.p, field.v_M1, field.v_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dt,
                  params.alpha_uv, field.d_ratio_y_1, field.v_s1,
                  field.aw_v1, field.ae_v1, field.as_v1, field.an_v1, field.ap_v1)

        # //============================================================
        # // BOUNDARY CONDITIONS FOR V
        # //============================================================
        _call_bc(bc_v_s1)

        # //============================================================
        # // Pressure Correction Equation (first)
        # //============================================================
        fsi_u_s1(); fsi_v_s1()
        field.p_s1[:] = 0.0  # initiate pressure prime to zero
        for _ in range(params.max_p_ittr_prloop):
            compute_p_1(field.u_s1, field.v_s1, field.p_s1, field.b, field.rho,
                        field.rho_M1, field.rho_M2, field.dx, field.dy, field.dt,
                        field.d_ratio_x_1, field.d_ratio_y_1)

        # //============================================================
        # // BOUNDARY CONDITIONS FOR P (p_s1)
        # //============================================================
        _call_bc(bc_p_s1)

        # //============================================================
        # // X-Velocity Correction using P_s1  (JIT kernel)
        # //============================================================
        corr_u_s2(field.u_s1, field.p_s1, field.d_ratio_x_1, field.u_s2)
        _call_bc(bc_u_s2)

        # //============================================================
        # // Y-Velocity Correction using P_s1  (JIT kernel)
        # //============================================================
        corr_v_s2(field.v_s1, field.p_s1, field.d_ratio_y_1, field.v_s2)
        _call_bc(bc_v_s2)

        # //============================================================
        field.p_s2[:] = field.p[:] + (params.alpha_p1 * field.p_s1[:])

        # //============================================================
        # // SECOND: X- Momentum Equation
        # //============================================================
        field.u_s3[:] = 0.0
        compute_u(field.u_s2, field.v_s2, field.p_s2, field.u_M1, field.u_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dt,
                  params.alpha_uv, field.d_ratio_x_2, field.u_s3,
                  field.aw_u2, field.ae_u2, field.as_u2, field.an_u2, field.ap_u2)

        # //===========================
        # // BOUNDARY CONDITIONS FOR U (u_s3)
        # //===========================
        _call_bc(bc_u_s3)

        # //============================================================
        # // SECOND: Y- Momentum Equation
        # //============================================================
        field.v_s3[:] = 0.0
        compute_v(field.u_s2, field.v_s2, field.p_s2, field.v_M1, field.v_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dt,
                  params.alpha_uv, field.d_ratio_y_2, field.v_s3,
                  field.aw_v2, field.ae_v2, field.as_v2, field.an_v2, field.ap_v2)

        # //==========================
        # // BOUNDARY CONDITIONS FOR V (v_s3)
        # //==========================
        _call_bc(bc_v_s3)

        # //============================================================
        # // SECOND: Pressure Correction Equation
        # //============================================================
        fsi_u_s3(); fsi_v_s3()
        field.p_s3[:] = 0.0
        compute_p_2(field.u_s2, field.v_s2, field.u_s3,
                    field.v_s3, field.p_s3, field.b_2, field.b_3, field.rho,
                    field.rho_M1, field.rho_M2, field.dx, field.dy, field.dt,
                    field.d_ratio_x_2, field.d_ratio_y_2,
                    field.aw_u2, field.ae_u2, field.as_u2, field.an_u2, field.ap_u2,
                    field.aw_v2, field.ae_v2, field.as_v2, field.an_v2, field.ap_v2)

        # //===========================
        # // BOUNDARY CONDITIONS FOR P (p_s3)
        # //===========================
        _call_bc(bc_p_s3)

        # //============================================================
        # // X-Velocity Final Correction using P_s3  (JIT kernel)
        # //============================================================
        corr_u_final(field.u_s2, field.u_s3, field.p_s3, field.d_ratio_x_2,
                     field.aw_u2, field.ae_u2, field.as_u2, field.an_u2, field.ap_u2,
                     field.u_final)
        _call_bc(bc_u_fin)

        # //============================================================
        # // Y-Velocity Final Correction using P_s3  (JIT kernel)
        # //============================================================
        corr_v_final(field.v_s2, field.v_s3, field.p_s3, field.d_ratio_y_2,
                     field.aw_v2, field.ae_v2, field.as_v2, field.an_v2, field.ap_v2,
                     field.v_final)
        _call_bc(bc_v_fin)

        # //============================================================
        # // ERROR (post second PCE)
        # //============================================================
        
        denom = (field.xmax-2)*(field.ymax-2)
        error = reduce_abs_sum_interior(field.b_2) / denom

        if np.isnan(error):
            nans = True
            print(f"[ERROR] NaN encountered in solver at step {step}, aborting.")
            break

        # === Stall detection (rolling average over last `stall_window` iters) ===
        err_hist.append(error)
        if len(err_hist) >= stall_window:
            avg_last = sum(err_hist[-stall_window:]) / stall_window
            if error >= stall_rtol * max(avg_last, 1e-300):
                stalled = True
                break
        if ((params.max_solve_ittr > 1000) and (step % 100 == 0)):
            print(f"residue step {step}, of Time step {time_step}/{time_steps}, Residual Error: {error}")
        # //============================================================
        field.p_final[:] = field.p_s2[:] + (params.alpha_p2 * field.p_s3[:])
        # //============================================================
        fsi_u_fin(); fsi_v_fin()
        # //============================================================
        field.u[:] = field.u_final[:]
        field.v[:] = field.v_final[:]
        field.p[:] = field.p_final[:]
        # //============================================================
        step += 1
    print(f"Time step {time_step}/{time_steps}, Final Error: {error}. Current time: {current_time:06} out of End time: {params.end_time}.")
    final_error = error
    return nans, stalled, final_error
   

#########################################################################
#########################################################################

def initilize_fields(field, params):
    """
    Used for initializing the fields for the transient NS equations.
    """
    # //===================================================
    # // INITIALIZATION OF GHOST CELLS
    # //===================================================
    # //====================
    # // U Velocity
    # //====================
    apply_initialization(field.u, 'top',    'u', params)
    apply_initialization(field.u, 'right',  'u', params)
    apply_initialization(field.u, 'bottom', 'u', params)
    apply_initialization(field.u, 'left',   'u', params)
    # //====================
    # // V Velocity
    # //====================
    apply_initialization(field.v, 'top',    'v', params)
    apply_initialization(field.v, 'right',  'v', params)
    apply_initialization(field.v, 'bottom', 'v', params)
    apply_initialization(field.v, 'left',   'v', params)
    # //====================
    # // P Velocity
    # //====================
    apply_initialization(field.p, 'top',     'p', params)
    apply_initialization(field.p, 'right',   'p', params)
    apply_initialization(field.p, 'bottom',  'p', params)
    apply_initialization(field.p, 'left',    'p', params)

    # //=================================================================
    # // INITIALIZATION OF INNER CELLS
    # //=================================================================
    field.u[1:field.xmax-1, 1:field.ymax-1] = 0.0
    field.v[1:field.xmax-1, 1:field.ymax-1] = 0.0
    field.p[1:field.xmax-1, 1:field.ymax-1] = 0.0
    
    # //=================================================================
    # // INITIALIZATION OF VOLUME FRACTION, RHO AND MU
    # //=================================================================
    field.mu[:] = field.vof[:] * params.mu_primary + (1 - field.vof[:]) * params.mu_secondary
    field.rho[:] = field.vof[:] * params.rho_primary + (1 - field.vof[:]) * params.rho_secondary
    # //==================================================================

#########################################################################
# TEMPORAL CONTROL (CFL and Dt update)
#########################################################################

@njit(parallel=True, fastmath=True, cache=True)
def compute_cfl(coNum, alpha_coNum, u, v, alpha, dt, dx, dy):
    cnx, cny =  coNum.shape
    vol = dx * dy
    mask = np.zeros_like(alpha)

    for j in prange(1, cny -1):
        for i in range(1, cnx - 1):
            aW = dy
            aE = dy
            aS = dx
            aN = dx
            sum_faces_mod_phi = (aW * abs(u[i, j]) + aE * abs(u[i + 1, j]) + aS * abs(v[i, j]) + aN * abs(v[i, j + 1])) / vol
            coNum[i, j] = dt * sum_faces_mod_phi * 0.5
    
    for j in prange(1, cny -1):
        for i in range(1, cnx - 1):
            mask[i,j] = 1 if alpha[i,j] > 0.0 and alpha[i,j] < 1.0 else 0
            if mask[i,j] == 1:
                aW = dy
                aE = dy
                aS = dx
                aN = dx
                sum_faces_mod_phi = (aW * abs(u[i, j]) + aE * abs(u[i + 1, j]) + aS * abs(v[i, j]) + aN * abs(v[i, j + 1])) / vol
                alpha_coNum[i, j] = dt * sum_faces_mod_phi * 0.5
            else:
                alpha_coNum[i, j] = 0.0

    return np.max(coNum[1:cnx-1, 1:cny-1]), np.max(alpha_coNum[1:cnx-1, 1:cny-1])


def update_dt(CoNum_current, alpha_coNum_current, CoNum_target, alpha_coNum_target, dt_current, max_DT):
    """
    Update the time step based on the current and target CFL numbers.
    """
    DT_ratio = min((CoNum_target / (CoNum_current + np.finfo(float).eps)), (alpha_coNum_target / (alpha_coNum_current + np.finfo(float).eps)))
    DT_fact = min(min(DT_ratio, 1.0 + 0.1*DT_ratio), 1.2)
    dt_new = DT_fact * dt_current

    return min(dt_new, max_DT)

    
###############################################################################################################################################################
####################################################### OBJECT MASK ###########################################################################################
def build_solid_mask(params, indices):
    nx, ny = params.xmax, params.ymax
    mask = np.zeros((nx, ny), dtype=np.uint8)

    # normalize the string flag
    obj_flag = params.object.strip().lower() in ("true", "True","1", "yes", "y", "on")

    if not obj_flag:
        return mask  # no object → empty mask
    for (i, j) in indices:
        mask[i, j] = 1
    return mask
