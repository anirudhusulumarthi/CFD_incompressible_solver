#include <iostream>
#include <fstream>
#include <vector>
#include <string>

int main() {
    // Input binary file and output .vtk file
    const std::string binary_file = "simulation_results.bin";
    const std::string vtk_file = "simulation_results.vtk";

    // Open the binary file for reading
    std::ifstream fin(binary_file, std::ios::binary);
    if (!fin.is_open()) {
        std::cerr << "Error: Could not open binary file " << binary_file << " for reading." << std::endl;
        return 1;
    }

    // Read metadata
    int grid;
    double dx, dy;
    fin.read(reinterpret_cast<char*>(&grid), sizeof(grid));
    fin.read(reinterpret_cast<char*>(&dx), sizeof(dx));
    fin.read(reinterpret_cast<char*>(&dy), sizeof(dy));

    // Initialize arrays for staggered and central values
    std::vector<std::vector<double>> u(grid, std::vector<double>(grid + 1, 0.0));
    std::vector<std::vector<double>> v(grid + 1, std::vector<double>(grid, 0.0));
    std::vector<std::vector<double>> p(grid + 1, std::vector<double>(grid + 1, 0.0));
    std::vector<std::vector<double>> uc(grid, std::vector<double>(grid, 0.0));
    std::vector<std::vector<double>> vc(grid, std::vector<double>(grid, 0.0));
    std::vector<std::vector<double>> pc(grid, std::vector<double>(grid, 0.0));

    // Read staggered and central values
    for (auto& row : u) fin.read(reinterpret_cast<char*>(row.data()), row.size() * sizeof(double));
    for (auto& row : v) fin.read(reinterpret_cast<char*>(row.data()), row.size() * sizeof(double));
    for (auto& row : p) fin.read(reinterpret_cast<char*>(row.data()), row.size() * sizeof(double));
    for (auto& row : uc) fin.read(reinterpret_cast<char*>(row.data()), row.size() * sizeof(double));
    for (auto& row : vc) fin.read(reinterpret_cast<char*>(row.data()), row.size() * sizeof(double));
    for (auto& row : pc) fin.read(reinterpret_cast<char*>(row.data()), row.size() * sizeof(double));

    fin.close();

    // Open the .vtk file for writing
    std::ofstream fout(vtk_file);
    if (!fout.is_open()) {
        std::cerr << "Error: Could not open VTK file " << vtk_file << " for writing." << std::endl;
        return 1;
    }

    // Write VTK header
    fout << "# vtk DataFile Version 3.0\n";
    fout << "CFD Simulation Results\n";
    fout << "ASCII\n";
    fout << "DATASET STRUCTURED_GRID\n";
    fout << "DIMENSIONS " << grid << " " << grid << " 1\n";

    // Write points (grid geometry)
    fout << "POINTS " << grid * grid << " float\n";
    for (int j = 0; j < grid; ++j) {
        for (int i = 0; i < grid; ++i) {
            fout << i * dx << " " << j * dy << " 0.0\n";
        }
    }

    // Write point data (central values: uc, vc, pc)
    fout << "POINT_DATA " << grid * grid << "\n";

    fout << "SCALARS Pressure_Central float 1\n";
    fout << "LOOKUP_TABLE default\n";
    for (int j = 0; j < grid; ++j) {
        for (int i = 0; i < grid; ++i) {
            fout << pc[i][j] << "\n";
        }
    }

    fout << "VECTORS Velocity_Central float\n";
    for (int j = 0; j < grid; ++j) {
        for (int i = 0; i < grid; ++i) {
            fout << uc[i][j] << " " << vc[i][j] << " 0.0\n";
        }
    }

    // Write cell data (staggered values: u, v, p)
    fout << "CELL_DATA " << (grid - 1) * (grid - 1) << "\n";

    fout << "SCALARS Pressure_Staggered float 1\n";
    fout << "LOOKUP_TABLE default\n";
    for (int j = 0; j < grid - 1; ++j) {
        for (int i = 0; i < grid - 1; ++i) {
            fout << p[i][j] << "\n";
        }
    }

    fout << "VECTORS Velocity_Staggered float\n";
    for (int j = 0; j < grid - 1; ++j) {
        for (int i = 0; i < grid - 1; ++i) {
            fout << u[i][j] << " " << v[i][j] << " 0.0\n";
        }
    }

    fout.close();
    std::cout << "VTK file generated: " << vtk_file << std::endl;

    return 0;
}
