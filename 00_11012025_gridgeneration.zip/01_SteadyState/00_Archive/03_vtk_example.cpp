#include <iostream>
#include <fstream>
#include <vector>
#include <string>

void writeVTK(const std::string &filename, int grid, double dx, double dy,
              const std::vector<std::vector<double>> &u,
              const std::vector<std::vector<double>> &v,
              const std::vector<std::vector<double>> &p) {
    std::ofstream outfile(filename);
    if (!outfile.is_open()) {
        std::cerr << "Error opening output file." << std::endl;
        return;
    }

    // Header
    outfile << "# vtk DataFile Version 3.0\n";
    outfile << "CFD simulation results\n";
    outfile << "ASCII\n";
    outfile << "DATASET STRUCTURED_GRID\n";
    outfile << "DIMENSIONS " << grid << " " << grid << " 1\n";

    // Grid Points
    outfile << "POINTS " << (grid * grid) << " float\n";
    for (int j = 0; j < grid; j++) {
        for (int i = 0; i < grid; i++) {
            double xpos = i * dx;
            double ypos = j * dy;
            outfile << xpos << " " << ypos << " 0\n";  // z = 0 for 2D
        }
    }

    // Point Data
    outfile << "POINT_DATA " << (grid * grid) << "\n";

    // U velocity
    outfile << "SCALARS U float 1\n";
    outfile << "LOOKUP_TABLE default\n";
    for (int j = 0; j < grid; j++) {
        for (int i = 0; i < grid; i++) {
            outfile << u[i][j] << "\n";
        }
    }

    // V velocity
    outfile << "SCALARS V float 1\n";
    outfile << "LOOKUP_TABLE default\n";
    for (int j = 0; j < grid; j++) {
        for (int i = 0; i < grid; i++) {
            outfile << v[i][j] << "\n";
        }
    }

    // Pressure
    outfile << "SCALARS P float 1\n";
    outfile << "LOOKUP_TABLE default\n";
    for (int j = 0; j < grid; j++) {
        for (int i = 0; i < grid; i++) {
            outfile << p[i][j] << "\n";
        }
    }

    outfile.close();
    std::cout << "VTK file written to: " << filename << std::endl;
}

int main() {
    int grid = 7;  // Example grid size
    double dx = 1.0 / (grid - 1);
    double dy = 1.0 / (grid - 1);

    // Example data (replace with your actual simulation data)
    std::vector<std::vector<double>> u(grid, std::vector<double>(grid, 1.0));
    std::vector<std::vector<double>> v(grid, std::vector<double>(grid, 0.0));
    std::vector<std::vector<double>> p(grid, std::vector<double>(grid, 1.0));

    // Call the function to write .vtk
    writeVTK("output.vtk", grid, dx, dy, u, v, p);

    return 0;
}
