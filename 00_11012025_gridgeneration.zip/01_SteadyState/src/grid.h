#ifndef GRID_H
#define GRID_H

#include <vector>
#include "init.h" // For the Parameters struct

// Structure to hold grid data
struct Grid {
    std::vector<std::vector<double>> u_velocity;     // Horizontal velocity grid
    std::vector<std::vector<double>> u_new_velocity; // New horizontal velocity grid
    std::vector<std::vector<double>> u_cen_velocity; // Central horizontal velocity grid

    std::vector<std::vector<double>> v_velocity;     // Vertical velocity grid
    std::vector<std::vector<double>> v_new_velocity; // New vertical velocity grid
    std::vector<std::vector<double>> v_cen_velocity; // Central vertical velocity grid

    std::vector<std::vector<double>> p_pressure;     // Pressure grid
    std::vector<std::vector<double>> p_new_pressure; // New pressure grid
    std::vector<std::vector<double>> p_cen_pressure; // Central pressure grid

    double dx; // Grid spacing in x-direction
    double dy; // Grid spacing in y-direction
    int xmax;  // Number of internal grid points in x-direction
    int ymax;  // Number of internal grid points in y-direction
};

// Function declaration for grid generation
Grid grid_generator(double xlength, double ylength, int xmax, int ymax);

#endif // GRID_H

