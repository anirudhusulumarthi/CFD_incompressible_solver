#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "init.h"
#include "grid.h"
#include "output.h"

int main(int argc, char* argv[]) {
    // Default parameter file name
    const std::string default_parameter_file = "parameter_file.par";
    std::string parameter_file;

    // Determine the parameter file to use
    if (argc == 2) {
        parameter_file = argv[1];
    } else {
        std::cout << "No parameter file provided. Using default: " << default_parameter_file << std::endl;
        parameter_file = default_parameter_file;
    }

    // Read and display the parameter file
    if (!READ_PARAMETER(parameter_file)) {
        std::cerr << "Failed to read parameter file." << std::endl;
        return 1;
    }
    // Extraction of parameters

    std::cout << "\nExtraction of parameters\n" << std::endl;
    // Extract parameters
    Parameters params = EXTRACT_PARAMETERS(parameter_file);

    // Verify if parameters were loaded correctly by printing them
    std::cout << "\nPrinting the extracted parameters:" << std::endl;
    PRINT_PARAMETERS(params);
    
    // Generation of grid

    std::cout << "\nGeneration of grid\n" << std::endl;
    // Generate the grid
    Grid grid = grid_generator(params.xlength, params.ylength, params.xmax, params.ymax);

    // Verify if grid were generated correctly by printing them
    std::cout << "\nPrinting the generated grid:" << std::endl;

    // Print grid values for verification
    PRINT_GRID(grid);

    // END PROGRAM
    std::cout << "\nEnd of the program\n" << std::endl;

    return 0;
}
