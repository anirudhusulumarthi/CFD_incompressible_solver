#include <iostream>
#include "output.h"

// Function to print the parameters for verification
void PRINT_PARAMETERS(const Parameters& params) {
    std::cout << "Problem Name: " << params.problem_name << std::endl;
    std::cout << "xlength: " << params.xlength << std::endl;
    std::cout << "ylength: " << params.ylength << std::endl;
    std::cout << "xmax: " << params.xmax << std::endl;
    std::cout << "ymax: " << params.ymax << std::endl;
    std::cout << "del_t: " << params.del_t << std::endl;
    std::cout << "Re: " << params.Re << std::endl;
    std::cout << "Delta Artificial: " << params.delta_artificial << std::endl;
}

// Function to print grid values for verification
void PRINT_GRID(const Grid& grid) {
    std::cout << "\nGrid Information:" << std::endl;
    std::cout << "Grid dx: " << grid.dx << ", dy: " << grid.dy << std::endl;

    // Print U Velocity
    std::cout << "\nU Velocity:" << std::endl;
    for (const auto& row : grid.u_velocity) {
        for (double val : row) std::cout << val << " ";
        std::cout << "\n";
    }

    // Print V Velocity
    std::cout << "\nV Velocity:" << std::endl;
    for (const auto& row : grid.v_velocity) {
        for (double val : row) std::cout << val << " ";
        std::cout << "\n";
    }

    // Print P Pressure
    std::cout << "\nPressure:" << std::endl;
    for (const auto& row : grid.p_pressure) {
        for (double val : row) std::cout << val << " ";
        std::cout << "\n";
    }

    // Print U New Velocity
    std::cout << "\nU New Velocity:" << std::endl;
    for (const auto& row : grid.u_new_velocity) {
        for (double val : row) std::cout << val << " ";
        std::cout << "\n";
    }

    // Print V New Velocity
    std::cout << "\nV New Velocity:" << std::endl;
    for (const auto& row : grid.v_new_velocity) {
        for (double val : row) std::cout << val << " ";
        std::cout << "\n";
    }

    // Print P New Pressure
    std::cout << "\nP New Pressure:" << std::endl;
    for (const auto& row : grid.p_new_pressure) {
        for (double val : row) std::cout << val << " ";
        std::cout << "\n";
    }

    // Print U Central Velocity
    std::cout << "\nU Central Velocity:" << std::endl;
    for (const auto& row : grid.u_cen_velocity) {
        for (double val : row) std::cout << val << " ";
        std::cout << "\n";
    }

    // Print V Central Velocity
    std::cout << "\nV Central Velocity:" << std::endl;
    for (const auto& row : grid.v_cen_velocity) {
        for (double val : row) std::cout << val << " ";
        std::cout << "\n";
    }

    // Print P Central Pressure
    std::cout << "\nP Central Pressure:" << std::endl;
    for (const auto& row : grid.p_cen_pressure) {
        for (double val : row) std::cout << val << " ";
        std::cout << "\n";
    }
}
