#ifndef INIT_H
#define INIT_H

#include <string>

// Struct to hold parameters
struct Parameters {
    double xlength = 0.0;
    double ylength = 0.0;
    int xmax = 0;
    int ymax = 0;
    double del_t = 0.0;
    int Re = 0;
    double delta_artificial = 0.0;
    std::string problem_name = "not_exist"; // Default value
};

// Function declarations
bool READ_PARAMETER(const std::string& filename); // Existing function
Parameters EXTRACT_PARAMETERS(const std::string& filename); // New function to extract parameters and return the struct

#endif // INIT_H
