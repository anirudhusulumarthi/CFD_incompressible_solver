#ifndef OUTPUT_H
#define OUTPUT_H

#include "init.h"
#include "grid.h"

// Function to print the parameters for verification
void PRINT_PARAMETERS(const Parameters& params);

// Function to print grid values for verification
void PRINT_GRID(const Grid& grid);

#endif // OUTPUT_H
