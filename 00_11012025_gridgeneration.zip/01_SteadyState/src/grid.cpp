#include "grid.h"

Grid grid_generator(double xlength, double ylength, int xmax, int ymax) {
    // Calculate grid spacing
    double dx = xlength / xmax;
    double dy = ylength / ymax;

    // Initialize the grid structure
    Grid grid;
    grid.xmax = xmax;
    grid.ymax = ymax;
    grid.dx = dx;
    grid.dy = dy;

    // Resize and initialize velocity grids
    grid.u_velocity.resize(xmax + 2, std::vector<double>(ymax+1, 0.0));
    grid.u_new_velocity.resize(xmax + 2, std::vector<double>(ymax+1, 0.0));
    grid.u_cen_velocity.resize(xmax+1, std::vector<double>(ymax+1, 0.0));

    grid.v_velocity.resize(xmax+1, std::vector<double>(ymax + 2, 0.0));
    grid.v_new_velocity.resize(xmax+1, std::vector<double>(ymax + 2, 0.0));
    grid.v_cen_velocity.resize(xmax+1, std::vector<double>(ymax+1, 0.0));

    // Resize and initialize pressure grids
    grid.p_pressure.resize(xmax + 2, std::vector<double>(ymax + 2, 1.0));
    grid.p_new_pressure.resize(xmax + 2, std::vector<double>(ymax + 2, 1.0));
    grid.p_cen_pressure.resize(xmax, std::vector<double>(ymax, 1.0));

    // Return the fully initialized grid
    return grid;
}
