#include "init.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#define _CRT_SECURE_NO_WARNINGS


// Function to read and display the parameter file (existing functionality)
bool READ_PARAMETER(const std::string& filename) {
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "Error: Unable to open parameter file: " << filename << std::endl;
        return false;
    }

    std::cout << "Reading parameter file: " << filename << std::endl;

    std::string line;
    while (std::getline(file, line)) {
        std::cout << line << std::endl;
    }

    file.close();
    return true;
}

// Function to extract parameters and return a populated struct

Parameters EXTRACT_PARAMETERS(const std::string& filename) {
    Parameters params; // Struct to store extracted parameters
    params.problem_name = "not_exist"; // Default value for problem_name

    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Could not open parameter file: " << filename << std::endl;
        return params; // Return default parameters
    }

    std::string line;

    // Read the file line by line
    while (std::getline(file, line)) {
        if (line.find("problem_name") != std::string::npos) {
            std::istringstream iss(line); // Create a string stream
            iss >> params.problem_name; // Extract the first token into problem_name
        } else if (line.find("xlength") != std::string::npos) {
            double value;
            std::istringstream(line) >> value;
            params.xlength = value;
        } else if (line.find("ylength") != std::string::npos) {
            double value;
            std::istringstream(line) >> value;
            params.ylength = value;
        } else if (line.find("xmax") != std::string::npos) {
            int value;
            std::istringstream(line) >> value;
            params.xmax = value;
        } else if (line.find("ymax") != std::string::npos) {
            int value;
            std::istringstream(line) >> value;
            params.ymax = value;
        } else if (line.find("del_t") != std::string::npos) {
            double value;
            std::istringstream(line) >> value;
            params.del_t = value;
        } else if (line.find("Re") != std::string::npos) {
            int value;
            std::istringstream(line) >> value;
            params.Re = value;
        } else if (line.find("delta_artificial") != std::string::npos) {
            double value;
            std::istringstream(line) >> value;
            params.delta_artificial = value;
        }
    }

    file.close();
    return params; // Return the filled struct
}