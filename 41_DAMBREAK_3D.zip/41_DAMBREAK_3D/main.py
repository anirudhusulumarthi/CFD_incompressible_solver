from src.init import extract_parameters
from src.parameter_gui import launch_parameter_gui
from src.output import print_parameters
from src.grid import FieldSet
from src.solve import uvp_Transient_solve

####################################################
import time
import sys, io

log_file = open("output/output_log.txt", "wb", buffering=0)  # Unbuffered binary
sys.stdout = io.TextIOWrapper(log_file, encoding='utf-8', write_through=True)
sys.stderr = sys.stdout
#####################################################################################
import numpy as np
from numba import njit, prange
from src.output import writeVTK
#####################################################################################
#####################################################################################
@njit(parallel=True, fastmath=True, cache=True)
def collocated_to_vof_stag(vf_col, vf_stag):
    """
    Convert collocated (cell-centered) VOF field to staggered (face-centered) VOF field in 3D.
    vf_col: 3D numpy array at cell centers
    vf_stag: 3D numpy array at staggered positions (output)
    """

    nx_c, ny_c, nz_c = vf_col.shape
    nx_s, ny_s, nz_s = vf_stag.shape

    for i in prange(1, min(nx_s-1, nx_c)):
        for j in range(1, min(ny_s-1, ny_c)):
            for k in range(1, min(nz_s-1, nz_c)):
                vf_stag[i, j, k] = 0.125 * (
                    vf_col[i-1, j-1, k-1] + vf_col[i, j-1, k-1] +
                    vf_col[i-1, j,   k-1] + vf_col[i, j,   k-1] +
                    vf_col[i-1, j-1, k  ] + vf_col[i, j-1, k  ] +
                    vf_col[i-1, j,   k  ] + vf_col[i, j,   k  ]
                )

    # zero-gradient ghost boundaries
    vf_stag[0, :, :]  = vf_stag[1, :, :]
    vf_stag[-1, :, :] = vf_stag[-2, :, :]
    vf_stag[:, 0, :]  = vf_stag[:, 1, :]
    vf_stag[:, -1, :] = vf_stag[:, -2, :]
    vf_stag[:, :, 0]  = vf_stag[:, :, 1]
    vf_stag[:, :, -1] = vf_stag[:, :, -2]


    #zero-gradient ghosts 
    vf_stag[0, :] = vf_stag[1, :] 
    vf_stag[-1, :] = vf_stag[-2, :] 
    vf_stag[:, 0] = vf_stag[:, 1] 
    vf_stag[:, -1] = vf_stag[:, -2]

#####################################################################################
def main():
    # Step 1: Launch GUI and create parameter file
    #launch_parameter_gui()  # blocks until user completes the form and closes GUI

    # Step 2: Load the parameter file created by the GUI
    params = extract_parameters()
    print(f"[INFO] Loaded parameters for problem: {params.problem_name}")
    print_parameters(params)

    # Step 3: Create fields based on grid
    field = FieldSet(params)
    print(f"[INFO] Created field set with shapes: {field.shapes}")

    # Step 4: VOF
    t_start = time.time()
    #field.vof[:] = 1.0
    print(f"[INFO] Initialized VOF field.")
    
    for k in prange(0, int(params.zmax/2)+1):
        for j in prange(0, int(params.ymax/2)+1):
            for i in range(0, int(params.xmax/2)+1):
                field.vof_col[i, j, k] = 0.5
    
        
    for k in prange(0, int(params.zmax/2)):
        for j in prange(0, int(params.ymax/2)):
            for i in range(0, int(params.xmax/2)):
                field.vof_col[i, j, k] = 1.0
    

    field.u_cen[:] = 0.0 # field.u_col.copy()
    field.v_cen[:] = 0.0 #field.v_col.copy()
    field.p_cen[:] = 0.0
    field.vof_cen[:] = field.vof_col.copy()

    writeVTK(field, "output/output.vtk", params)

    field.u_cen[:] = 0.0
    field.v_cen[:] = 0.0
    field.vof_cen[:] = 0.0


    collocated_to_vof_stag(field.vof_col, field.vof_stag)
    field.vof = field.vof_stag.copy()

    #########################################################################################################    
    
    # Computing Time
    
    # Step 5: Solve the transient NS equations

    uvp_Transient_solve(field, params)

    t_total = time.time() - t_start
    print(f"[INFO] Total computation time: {t_total:.4f} seconds")
    
if __name__ == "__main__":
    main()
