
# ==============================
# File: solve.py
# ==============================
import numpy as np
import copy
from src.boundary import apply_initialization, setup_bc_functions
from src.crux import (
    compute_u,
    compute_v,
    compute_w,
    compute_p_1,
    corr_u_s2,
    corr_v_s2,
    corr_w_s2,
    reduce_abs_sum_interior,
    update_central_fields_njit,
    clear_fields_njit,
    update_scalars,
    compute_vof,
    update_dt
)
from src.output import writeVTK
from src.structure import object_points, setup_fsi_zeroing_functions
########################################################################
########################################################################
def uvp_Transient_solve(field, params):
    """
    Transient NS equations solver (PISO-like), formula-preserving.
    Performance improvements:
      - JIT kernels for inner Python loops (corrections, error reductions, field utilities)
      - Optional lower VTK frequency via params.vtk_every (default=10)
      - Minor housekeeping (remove redundant increments, tiny fixes)
    """
    print("[INFO] Starting transient NS equations solver.")
    print(f"[INFO] Using dx={field.dx}, dy={field.dy}, dt={field.dt}")
    print(f"[INFO] Total columns in a grid: (xmax)={field.xmax}, Total rows in a grid: (ymax)={field.ymax}")
    print(f"[INFO] Using xmax={params.xlength}, ymax={params.ylength}")
    print(f"[INFO] Using alpha_uv={params.alpha_uvw}, alpha_p={params.alpha_p1}")
    print(f"[INFO] Using error_threshold={params.error_thresh}")
    print(f"[INFO] The Dt: {field.dt}")
    total_time = params.end_time - params.start_time
    Time_steps = int((total_time) / field.dt)

    current_time = 0
    # // ===============================================================
    stall_window = 400
    stall_rtol = 0.9
    eps = 1e-15

    # //================================================================
    # // INITIALIZATION OF FIELDS and BOUNDARY CONDITIONS
    # //================================================================
    initilize_fields(field, params)
   
    pts = object_points(params)
    
    print("[INFO] Fields initialized and boundary conditions set.")
    # //================================================================
    # //===========================
    # Time-history buffers (match original order exactly)
    field.u_M2[:] = field.u[:]
    field.v_M2[:] = field.v[:]
    field.w_M2[:] = field.w[:]
    field.p_M2[:] = field.p[:]
    field.rho_M2[:] = field.rho[:]
    field.vof_M2[:] = field.vof[:]

    field.u_M1[:] = field.u[:]
    field.v_M1[:] = field.v[:]
    field.w_M1[:] = field.w[:]
    field.p_M1[:] = field.p[:]
    field.rho_M1[:] = field.rho[:]
    field.vof_M1[:] = field.vof[:]
    time_step = 0
    input_cfl = params.cfl

    while current_time < params.end_time:
        Time_steps = int(params.end_time / field.dt)
        saved_field = copy.deepcopy(field)
        nans, stalled = solver(field, current_time, 
                stall_window, stall_rtol,
                time_step, Time_steps, params,
               )
        if nans:
            break      
        # //==============================
        compute_vof(field.vof, field.u_final, field.v_final, field.w_final, field.vof_M1, field.vof_M2, field.dx, field.dy, field.dz, field.dt, use_tvd=True)
        update_scalars(field.vof, field.rho, field.mu, params.rho_primary, params.mu_primary, params.rho_secondary, params.mu_secondary)
        # //==============================
        update_central_fields_njit(field.u_cen, field.v_cen, field.w_cen, field.p_cen, field.vof_cen, field.u_final, field.v_final, field.w_final, field.p_final, field.vof)
        # //=============================
        last_printed = 0.0
        if(time_step % 2 ==0):
            writeVTK(field, f"output/simulation_output_{time_step:05}.vtk", params)
            
        field.u_M2[:] = field.u_M1[:]
        field.v_M2[:] = field.v_M1[:]
        field.w_M2[:] = field.w_M1[:]
        field.p_M2[:] = field.p_M1[:]
        field.rho_M2[:] = field.rho_M1[:]
        field.vof_M2[:] = field.vof_M1[:]

        field.u_M1[:] = field.u_final[:]
        field.v_M1[:] = field.v_final[:]
        field.w_M1[:] = field.w_final[:]
        field.p_M1[:] = field.p_final[:]
        field.rho_M1[:] = field.rho[:]
        field.vof_M1[:] = field.vof[:]
        # //==============================
        field.u[:] = field.u_final[:]
        field.v[:] = field.v_final[:]
        field.p[:] = field.p_final[:]

        clear_fields_njit(field.u_s1, field.v_s1, field.w_s1, field.p_s1,
                          field.u_s2, field.v_s2, field.w_s2, field.p_s2,
                          field.u_s3, field.v_s3, field.w_s3, field.p_s3)

        current_time += field.dt
        time_step += 1
########################################################################################################################################################################
# SOLVER
########################################################################################################################################################################

def _call_bc(bc_tuple):
    r, l, t, tl, tr, b, bl, br = bc_tuple
    r(); l(); t(); tl(); tr(); b(); bl(); br()


def solver(field, current_time, 
           stall_window, stall_rtol,
           time_step, time_steps, params,
):
    # //================================================================
    step = 0
    error = 1.0
    error_2 = 1.0
    err_hist = []
    nans = False
    stalled = False

    # //================================================================
    while error_2 > params.error_thresh and step < params.max_solve_ittr:
        # //============================================================
        # // X- Momentum Equation # 3D VERIFIED
        # //============================================================
        compute_u(field.u, field.v, field.w, field.p, field.u_M1, field.u_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dz, field.dt,
                  params.alpha_uvw, field.d_ratio_x_1, field.u_s1,
                  field.aw_u1, field.ae_u1, field.as_u1, field.an_u1, field.ab_u1, field.at_u1, field.ap_u1)

        # //============================================================
        # // BOUNDARY CONDITIONS FOR U
        # //============================================================
        # no slip ghost boundaries
        field.u_s1[1, :, :]  = - field.u_s1[2, :, :]
        field.u_s1[-1, :, :] = - field.u_s1[-2, :, :]
        field.u_s1[:, 0, :]  = - field.u_s1[:, 1, :]
        field.u_s1[:, -1, :] = - field.u_s1[:, -2, :]
        field.u_s1[:, :, 0]  = - field.u_s1[:, :, 1]
        field.u_s1[:, :, -1] = - field.u_s1[:, :, -2]

        # //============================================================
        # // Y- Momentum Equation
        # //============================================================
        compute_v(field.u, field.v, field.w, field.p, field.v_M1, field.v_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dz,field.dt,
                  params.alpha_uvw, field.d_ratio_y_1, field.v_s1,
                  field.aw_v1, field.ae_v1, field.as_v1, field.an_v1, field.ab_v1, field.at_v1, field.ap_v1)

        # //============================================================
        # // BOUNDARY CONDITIONS FOR V
        # //============================================================
        # no slip ghost boundaries
        field.v_s1[0, :, :]  = - field.v_s1[1, :, :]
        field.v_s1[-1, :, :] = - field.v_s1[-2, :, :]
        field.v_s1[:, 1, :]  = - field.v_s1[:, 2, :]
        field.v_s1[:, -1, :] = - field.v_s1[:, -2, :]
        field.v_s1[:, :, 0]  = - field.v_s1[:, :, 1]
        field.v_s1[:, :, -1] = - field.v_s1[:, :, -2]
        # //============================================================
        # // Z- Momentum Equation
        # //============================================================
        compute_w(field.u, field.v, field.w, field.p, field.w_M1, field.w_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dz,field.dt,
                  params.alpha_uvw, field.d_ratio_z_1, field.w_s1,
                  field.aw_w1, field.ae_w1, field.as_w1, field.an_w1, field.ab_w1, field.at_w1, field.ap_w1)
        # //============================================================
        # // BOUNDARY CONDITIONS FOR W
        # //============================================================
        # no slip ghost boundaries
        field.w[0, :, :]  = - field.w[1, :, :]
        field.w[-1, :, :] = - field.w[-2, :, :]
        field.w[:, 0, :]  = - field.w[:, 1, :]
        field.w[:, -1, :] = - field.w[:, -2, :]
        field.w[:, :, 1]  = - field.w[:, :, 2]
        field.w[:, :, -1] = - field.w[:, :, -2]
        # //============================================================
        # // Pressure Correction Equation (first)
        # //============================================================

        field.p_s1[:] = 0.0  # initiate pressure prime to zero
        for _ in range(params.max_p_ittr_prloop):
            compute_p_1(field.u_s1, field.v_s1, field.w_s1, field.p_s1, field.b, field.rho,
                        field.rho_M1, field.rho_M2, field.dx, field.dy, field.dz, field.dt,
                        field.d_ratio_x_1, field.d_ratio_y_1, field.d_ratio_z_1)

        # //============================================================
        # // BOUNDARY CONDITIONS FOR P (p_s1)
        # //============================================================
        # zero-gradient ghost boundaries
        field.p_s1[0, :, :]  = field.p_s1[1, :, :]
        field.p_s1[-1, :, :] = field.p_s1[-2, :, :]
        field.p_s1[:, 0, :]  = field.p_s1[:, 1, :]
        field.p_s1[:, -1, :] = field.p_s1[:, -2, :]
        field.p_s1[:, :, 0]  = field.p_s1[:, :, 1]
        field.p_s1[:, :, -1] = field.p_s1[:, :, -2]

        # //============================================================
        # // X-Velocity Correction using P_s1  (JIT kernel)
        # //============================================================
        corr_u_s2(field.u_s1, field.p_s1, field.d_ratio_x_1, field.u_s2)
        # no slip ghost boundaries
        field.u_s2[1, :, :]  = - field.u_s2[2, :, :]
        field.u_s2[-1, :, :] = - field.u_s2[-2, :, :]
        field.u_s2[:, 0, :]  = - field.u_s2[:, 1, :]
        field.u_s2[:, -1, :] = - field.u_s2[:, -2, :]
        field.u_s2[:, :, 0]  = - field.u_s2[:, :, 1]
        field.u_s2[:, :, -1] = - field.u_s2[:, :, -2]

        # //============================================================
        # // Y-Velocity Correction using P_s1  (JIT kernel)
        # //============================================================
        corr_v_s2(field.v_s1, field.p_s1, field.d_ratio_y_1, field.v_s2)
        # no slip ghost boundaries
        field.v_s2[0, :, :]  = - field.v_s2[1, :, :]
        field.v_s2[-1, :, :] = - field.v_s2[-2, :, :]
        field.v_s2[:, 1, :]  = - field.v_s2[:, 2, :]
        field.v_s2[:, -1, :] = - field.v_s2[:, -2, :]
        field.v_s2[:, :, 0]  = - field.v_s2[:, :, 1]
        field.v_s2[:, :, -1] = - field.v_s2[:, :, -2]
        # //============================================================
        # // Z-Velocity Correction using P_s1  (JIT kernel)
        # //============================================================
        corr_w_s2(field.w_s1, field.p_s1, field.d_ratio_z_1, field.w_s2)
        # no slip ghost boundaries
        field.w_s2[0, :, :]  = - field.w_s2[1, :, :]
        field.w_s2[-1, :, :] = - field.w_s2[-2, :, :]
        field.w_s2[:, 0, :]  = - field.w_s2[:, 1, :]
        field.w_s2[:, -1, :] = - field.w_s2[:, -2, :]
        field.w_s2[:, :, 1]  = - field.w_s2[:, :, 2]
        field.w_s2[:, :, -1] = - field.w_s2[:, :, -2]

        # //============================================================
        # // ERROR (post first PCE)
        # //============================================================
        error = reduce_abs_sum_interior(field.b)

        # //============================================================
        field.p_s2[:] = field.p[:] + (params.alpha_p1 * field.p_s1[:])

        # //============================================================
        # // SECOND: X- Momentum Equation
        # //============================================================
        field.u_s3[:] = 0.0
        compute_u(field.u_s2, field.v_s2, field.w_s2, field.p_s2, field.u_M1, field.u_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dz, field.dt,
                  params.alpha_uvw, field.d_ratio_x_2, field.u_s3,
                  field.aw_u2, field.ae_u2, field.as_u2, field.an_u2, field.ab_u2, field.at_u2, field.ap_u2)
        # //===========================
        # // BOUNDARY CONDITIONS FOR U (u_s3)
        # //===========================
        # no slip ghost boundaries
        field.u_s3[1, :, :]  = - field.u_s3[2, :, :]
        field.u_s3[-1, :, :] = - field.u_s3[-2, :, :]
        field.u_s3[:, 0, :]  = - field.u_s3[:, 1, :]
        field.u_s3[:, -1, :] = - field.u_s3[:, -2, :]
        field.u_s3[:, :, 0]  = - field.u_s3[:, :, 1]
        field.u_s3[:, :, -1] = - field.u_s3[:, :, -2]

        # //============================================================
        # // SECOND: Y- Momentum Equation
        # //============================================================
        field.v_s3[:] = 0.0        
        compute_v(field.u_s2, field.v_s2, field.w_s2, field.p_s2, field.v_M1, field.v_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dz, field.dt,
                  params.alpha_uvw, field.d_ratio_y_2, field.v_s3,
                  field.aw_v2, field.ae_v2, field.as_v2, field.an_v2, field.ab_v2, field.at_v2, field.ap_v2)

        # //==========================
        # // BOUNDARY CONDITIONS FOR V (v_s3)
        # //==========================
        # no slip ghost boundaries
        field.v_s3[0, :, :]  = - field.v_s3[1, :, :]
        field.v_s3[-1, :, :] = - field.v_s3[-2, :, :]
        field.v_s3[:, 1, :]  = - field.v_s3[:, 2, :]
        field.v_s3[:, -1, :] = - field.v_s3[:, -2, :]
        field.v_s3[:, :, 0]  = - field.v_s3[:, :, 1]
        field.v_s3[:, :, -1] = - field.v_s3[:, :, -2]

        # //============================================================
        # // SECOND: Z- Momentum Equation
        # //============================================================
        compute_w(field.u_s2, field.v_s2, field.w_s2, field.p_s2, field.w_M1, field.w_M2, field.rho,
                  field.rho_M1, field.rho_M2, field.mu, field.dx, field.dy, field.dz, field.dt,
                  params.alpha_uvw, field.d_ratio_z_2, field.w_s3,
                  field.aw_w2, field.ae_w2, field.as_w2, field.an_w2, field.ab_w2, field.at_w2, field.ap_w2)
        # //============================================================
        # // BOUNDARY CONDITIONS FOR W
        # //============================================================
        # no slip ghost boundaries
        field.w_s3[0, :, :]  = - field.w_s3[1, :, :]
        field.w_s3[-1, :, :] = - field.w_s3[-2, :, :]
        field.w_s3[:, 0, :]  = - field.w_s3[:, 1, :]
        field.w_s3[:, -1, :] = - field.w_s3[:, -2, :]
        field.w_s3[:, :, 1]  = - field.w_s3[:, :, 2]
        field.w_s3[:, :, -1] = - field.w_s3[:, :, -2]

        # //============================================================
        # // SECOND: Pressure Correction Equation
        # //============================================================
        
        field.p_s3[:] = 0.0
        compute_p_1(field.u_s3, field.v_s3, field.w_s3, field.p_s3, field.b_2, field.rho,
                        field.rho_M1, field.rho_M2, field.dx, field.dy, field.dz, field.dt,
                        field.d_ratio_x_2, field.d_ratio_y_2, field.d_ratio_z_2)

        # //===========================
        # // BOUNDARY CONDITIONS FOR P (p_s3)
        # //===========================
        # zero-gradient ghost boundaries
        field.p_s3[0, :, :]  = field.p_s3[1, :, :]
        field.p_s3[-1, :, :] = field.p_s3[-2, :, :]
        field.p_s3[:, 0, :]  = field.p_s3[:, 1, :]
        field.p_s3[:, -1, :] = field.p_s3[:, -2, :]
        field.p_s3[:, :, 0]  = field.p_s3[:, :, 1]
        field.p_s3[:, :, -1] = field.p_s3[:, :, -2]

        # //============================================================
        # // X-Velocity Final Correction using P_s3  (JIT kernel)
        # //============================================================
        corr_u_s2(field.u_s3, field.p_s3, field.d_ratio_x_2, field.u_final)
        # no slip ghost boundaries
        field.u_final[1, :, :]  = - field.u_final[2, :, :]
        field.u_final[-1, :, :] = - field.u_final[-2, :, :]
        field.u_final[:, 0, :]  = - field.u_final[:, 1, :]
        field.u_final[:, -1, :] = - field.u_final[:, -2, :]
        field.u_final[:, :, 0]  = - field.u_final[:, :, 1]
        field.u_final[:, :, -1] = - field.u_final[:, :, -2]

        # //============================================================
        # // Y-Velocity Final Correction using P_s3  (JIT kernel)
        # //============================================================

        corr_v_s2(field.v_s3, field.p_s3, field.d_ratio_y_2, field.v_final)
        # no slip ghost boundaries
        field.v_final[0, :, :]  = - field.v_final[1, :, :]
        field.v_final[-1, :, :] = - field.v_final[-2, :, :]
        field.v_final[:, 1, :]  = - field.v_final[:, 2, :]
        field.v_final[:, -1, :] = - field.v_final[:, -2, :]
        field.v_final[:, :, 0]  = - field.v_final[:, :, 1]
        field.v_final[:, :, -1] = - field.v_final[:, :, -2]

        # //============================================================
        # // Z-Velocity Final Correction using P_s3  (JIT kernel)
        # //============================================================

        corr_w_s2(field.w_s3, field.p_s3, field.d_ratio_z_2, field.w_final)
        # no slip ghost boundaries
        field.w_final[0, :, :]  = - field.w_final[1, :, :]
        field.w_final[-1, :, :] = - field.w_final[-2, :, :]
        field.w_final[:, 0, :]  = - field.w_final[:, 1, :]
        field.w_final[:, -1, :] = - field.w_final[:, -2, :]
        field.w_final[:, :, 1]  = - field.w_final[:, :, 2]
        field.w_final[:, :, -1] = - field.w_final[:, :, -2]

        # //============================================================
        # // ERROR (post second PCE)
        # //============================================================
        
        denom = (field.xmax-2)*(field.ymax-2)*(field.zmax-2)
        error_2 = reduce_abs_sum_interior(field.b_2) / denom

        if np.isnan(error_2):
            nans = True
            print(f"[ERROR] NaN encountered in solver at step {step}, aborting.")
            break

        # === Stall detection (rolling average over last `stall_window` iters) ===
        err_hist.append(error_2)
        if len(err_hist) >= stall_window:
            avg_last = sum(err_hist[-stall_window:]) / stall_window
            if error_2 >= stall_rtol * max(avg_last, 1e-300):
                stalled = True
                break
        if ((params.max_solve_ittr > 1000) and (step % 100 == 0)):
            print(f"residue step {step}, of Time step {time_step}/{time_steps}, Residual Error: {error_2}")
        # //============================================================
        field.p_final[:] = field.p_s2[:] + (params.alpha_p2 * field.p_s3[:])
        # //============================================================
        # //============================================================
        field.u[:] = field.u_final[:]
        field.v[:] = field.v_final[:]
        field.p[:] = field.p_final[:]
        # //============================================================
        step += 1
    umax = np.max(np.abs(field.u_final))
    vmax = np.max(np.abs(field.v_final))
    wmax = np.max(np.abs(field.w_final))
    print(f"Time step {time_step}/{time_steps}, Final Error: {error_2}. Current time: {current_time:06} out of End time: {params.end_time}. CFL condition is {compute_cfl(field.u_final, field.v_final, field.w_final, field.dt, field.dx, field.dy, field.dz):.4f} and umax is {umax:.4f} and vmax is {vmax:.4f} and wmax is {wmax:.4f}")
    return nans, stalled
   

#########################################################################
#########################################################################

def initilize_fields(field, params):
    """
    Used for initializing the fields for the transient NS equations.
    """
    
    # //=================================================================
    # // INITIALIZATION OF INNER CELLS
    # //=================================================================
    field.u[1:field.xmax-1, 1:field.ymax-1, 1:field.zmax-1] = 0.0
    field.v[1:field.xmax-1, 1:field.ymax-1, 1:field.zmax-1] = 0.0
    field.w[1:field.xmax-1, 1:field.ymax-1, 1:field.zmax-1] = 0.0
    field.p[1:field.xmax-1, 1:field.ymax-1, 1:field.zmax-1] = 0.0

    # //=================================================================
    # // INITIALIZATION OF VOLUME FRACTION, RHO AND MU
    # //=================================================================
    field.mu[:] = field.vof[:] * params.mu_primary + (1 - field.vof[:]) * params.mu_secondary
    field.rho[:] = field.vof[:] * params.rho_primary + (1 - field.vof[:]) * params.rho_secondary
    # //==================================================================

#########################################################################
#########################################################################

def compute_cfl(u, v, w, dt, dx, dy, dz):
    umax = np.max(np.abs(u))
    vmax = np.max(np.abs(v))
    wmax = np.max(np.abs(w))

    cfl = max(umax * dt / dx, vmax * dt / dy, wmax * dt / dz) 
    return cfl
