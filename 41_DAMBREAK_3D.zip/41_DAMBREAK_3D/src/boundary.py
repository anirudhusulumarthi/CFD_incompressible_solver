from functools import partial
from src.init import InitType, BCType

field_map = {
    'u': 'u', 'u_s1': 'u', 'u_s2': 'u', 'u_s3': 'u',  'u_final': 'u',
    'v': 'v', 'v_s1': 'v', 'v_s2': 'v', 'v_s3': 'v',  'v_final': 'v',
    'p': 'p', 'p_s1': 'p', 'p_s2': 'p', 'p_s3': 'p',  'p_final': 'p',
}

def get_wall_indices(field_array, wall, field_name):
    nx, ny = field_array.shape
    if field_name == 'u':
        if wall == 'left':
            return [(1, j) for j in range(1, ny - 1)]
        elif wall == 'right':
            return [(nx - 1, j) for j in range(1, ny - 1)]
        elif wall == 'bottom':
            return [(i, 0) for i in range(2, nx - 1)]
        elif wall == 'top':
            return [(i, ny - 1) for i in range(2, nx - 1)]
    elif field_name == 'v':
        if wall == 'left':
            return [(0, j) for j in range(2, ny - 1)]
        elif wall == 'right':
            return [(nx - 1, j) for j in range(2, ny - 1)]
        elif wall == 'bottom':
            return [(i, 1) for i in range(0, nx)]
        elif wall == 'top':
            return [(i, ny - 1) for i in range(0, nx)]
    elif field_name == 'p':
        if wall == 'left':
            return [(0, j) for j in range(1, ny - 1)]
        elif wall == 'right':
            return [(nx - 1, j) for j in range(1, ny - 1)]
        elif wall == 'bottom':
            return [(i, 0) for i in range(1, nx - 1)]
        elif wall == 'top':
            return [(i, ny - 1) for i in range(1, nx - 1)]
    raise ValueError(f"Invalid wall '{wall}' or field '{field_name}'")

def compute_ref_indices(indices, wall, field_name):
    if field_name in {'u', 'v', 'p'}:
        if wall == 'right':
            return [(i - 1, j) for i, j in indices]
        elif wall == 'left':
            return [(i + 1, j) for i, j in indices]
        elif wall == 'top':
            return [(i, j - 1) for i, j in indices]
        elif wall == 'bottom':
            return [(i, j + 1) for i, j in indices]
    raise ValueError(f"Invalid wall '{wall}' or field '{field_name}'")

def apply_initialization(field_array, wall, field_name, params):
    init_type, init_value = params.boundary[wall][field_name]["init"]
    if init_type != InitType.VALUE:
        print(f"[INIT] {wall.upper()} WALL - {field_name.upper()}: Skipped (none)")
        return
    for i, j in get_wall_indices(field_array, wall, field_name):
        field_array[i, j] = init_value
    print(f"[INIT] {wall.upper()} WALL - {field_name.upper()}: Set to {init_value}")

def _apply_value_bc_bottom(field, indices, val):
    for i, j in indices:
        field[i, j] = 2 * val - field[i, j + 1]

def _apply_value_bc_top(field, indices, val):
    for i, j in indices:
        field[i, j] = 2 * val - field[i, j - 1]

def _apply_value_bc_left(field, indices, val):
    for i, j in indices:
        field[i, j] = 2 * val - field[i + 1, j]

def _apply_value_bc_right(field, indices, val):
    for i, j in indices:
        field[i, j] = 2 * val - field[i - 1, j]


def _apply_zero_bc(field, indices):
    for i, j in indices:
        field[i, j] = 0.0

def _apply_copy_bc(field, indices, refs):
    for (i, j), (ri, rj) in zip(indices, refs):
        field[i, j] = field[ri, rj]

def _apply_neg_copy_bc(field, indices, refs):
    for (i, j), (ri, rj) in zip(indices, refs):
        field[i, j] = -field[ri, rj]

def get_corner_mappings(field_name, shape):
    nx, ny = shape
    if field_name == 'u':
        return {
            "top_left":     {"top": ((1, ny - 1), (1, ny - 2)), "left": ((1, ny - 1), (2, ny - 1))},
            "top_right":    {"top": ((nx - 1, ny - 1), (nx - 1, ny - 2)), "right": ((nx - 1, ny - 1), (nx - 2, ny - 1))},
            "bottom_left":  {"bottom": ((1, 0), (1, 1)), "left": ((1, 0), (2, 0))},
            "bottom_right": {"bottom": ((nx - 1, 0), (nx - 1, 1)), "right": ((nx - 1, 0), (nx - 2, 0))},
        }
    elif field_name == 'v':
        return {
            "top_left":     {"top": ((0, ny - 1), (0, ny - 2)), "left": ((0, ny - 1), (1, ny - 1))},
            "top_right":    {"top": ((nx - 1, ny - 1), (nx - 1, ny - 2)), "right": ((nx - 1, ny - 1), (nx - 2, ny - 1))},
            "bottom_left":  {"bottom": ((0, 1), (0, 2)), "left": ((0, 1), (1, 1))},
            "bottom_right": {"bottom": ((nx - 1, 1), (nx - 1, 2)), "right": ((nx - 1, 1), (nx - 2, 1))},
        }
    elif field_name == 'p':
        return {
            "top_left":     {"top": ((0, ny - 1), (0, ny - 2)), "left": ((0, ny - 1), (1, ny - 1))},
            "top_right":    {"top": ((nx - 1, ny - 1), (nx - 1, ny - 2)), "right": ((nx - 1, ny - 1), (nx - 2, ny - 1))},
            "bottom_left":  {"bottom": ((0, 0), (0, 1)), "left": ((0, 0), (1, 0))},
            "bottom_right": {"bottom": ((nx - 1, 0), (nx - 1, 1)), "right": ((nx - 1, 0), (nx - 2, 0))},
        }
    raise ValueError(f"Invalid field: {field_name}")

def setup_corner_bc_function(fieldset, params):
    corner_dispatch = {}
    corner_sides = {
        "top_left": params.top_left,
        "top_right": params.top_right,
        "bottom_left": params.bottom_left,
        "bottom_right": params.bottom_right,
    }

    for corner in corner_sides:
        for field_name, base_field in field_map.items():
            if base_field not in {'u', 'v', 'p'}:
                continue

            field_array = getattr(fieldset, field_name)
            shape = field_array.shape
            mapping = get_corner_mappings(base_field, shape)

            side = corner_sides[corner]
            if side not in mapping[corner]:
                raise ValueError(f"Invalid corner side '{side}' for {corner}")

            target_idx, ref_idx = mapping[corner][side]
            bc_type, val = params.boundary[side][base_field]["bc"]
            key = (corner, field_name, side)

            if bc_type == BCType.VALUE:
                # Pick wall-specific value BC function
                if side == 'bottom':
                    bc_fn = _apply_value_bc_bottom
                elif side == 'top':
                    bc_fn = _apply_value_bc_top
                elif side == 'left':
                    bc_fn = _apply_value_bc_left
                elif side == 'right':
                    bc_fn = _apply_value_bc_right
                else:
                    raise ValueError(f"Unsupported side: {side}")
                corner_dispatch[key] = partial(bc_fn, field_array, [target_idx], val)

            elif bc_type == BCType.NO_PENETRATION:
                corner_dispatch[key] = partial(_apply_zero_bc, field_array, [target_idx])

            elif bc_type == BCType.ZERO_GRAD:
                corner_dispatch[key] = partial(_apply_copy_bc, field_array, [target_idx], [ref_idx])

            elif bc_type == BCType.NO_SLIP:
                corner_dispatch[key] = partial(_apply_neg_copy_bc, field_array, [target_idx], [ref_idx])

            else:
                raise ValueError(f"Unsupported BC type {bc_type} for {side} on {corner}")

    return corner_dispatch


def setup_bc_functions(fieldset, params):
    bc_dispatch = {}
    
    for wall in ['top', 'bottom', 'left', 'right']:
        for field_name, base_field in field_map.items():
            if base_field not in {'u', 'v', 'p'}:
                continue

            field_array = getattr(fieldset, field_name)
            indices = get_wall_indices(field_array, wall, base_field)
            bc_type, val = params.boundary[wall][base_field]["bc"]

            if bc_type == BCType.VALUE:

                if wall == 'bottom':
                    bc_fn = _apply_value_bc_bottom
                elif wall == 'top':
                    bc_fn = _apply_value_bc_top
                elif wall == 'left':
                    bc_fn = _apply_value_bc_left
                elif wall == 'right':
                    bc_fn = _apply_value_bc_right
                else:
                    raise ValueError(f"Unsupported wall: {wall}")
                bc_dispatch[(wall, field_name)] = partial(bc_fn, field_array, indices, val)

            elif bc_type == BCType.NO_PENETRATION:
                bc_dispatch[(wall, field_name)] = partial(_apply_zero_bc, field_array, indices)

            elif bc_type == BCType.ZERO_GRAD:
                refs = compute_ref_indices(indices, wall, base_field)
                bc_dispatch[(wall, field_name)] = partial(_apply_copy_bc, field_array, indices, refs)

            elif bc_type == BCType.NO_SLIP:
                refs = compute_ref_indices(indices, wall, base_field)
                bc_dispatch[(wall, field_name)] = partial(_apply_neg_copy_bc, field_array, indices, refs)

            else:
                raise ValueError(f"No valid BC for {wall} - {field_name}")
    
    bc_dispatch.update(setup_corner_bc_function(fieldset, params))
    return bc_dispatch
