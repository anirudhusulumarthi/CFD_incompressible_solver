import tkinter as tk
from tkinter import messagebox
import configparser
import os

DEFAULT_OUTPUT_PATH = "input/parameter_file.par"
walls_left = ["top", "right"]
walls_right = ["bottom", "left"]
fields = ["u", "v", "p"]

default_init = {"u": ("none", "0.0"), "v": ("none", "0.0"), "p": ("none", "0.0")}
default_bc = {"u": ("no_penetration", "0.0"), "v": ("no_slip", "0.0"), "p": ("zero_grad", "0.0")}


def launch_parameter_gui(output_path=DEFAULT_OUTPUT_PATH):
    window = tk.Tk()
    window.title("Parameter File Generator")

    entries = {}

    # === Problem & Solver Settings ===
    tk.Label(window, text="=== Problem Settings ===", font=("Arial", 12, "bold")).grid(row=0, column=0, columnspan=2)
    tk.Label(window, text="=== Solver Settings ===", font=("Arial", 12, "bold")).grid(row=0, column=3, columnspan=2)

    problem_labels = ["Problem Name", "xlength", "ylength", "xmax", "ymax"]
    solver_labels = ["Re", "alpha_uv", "alpha_p1", "alpha_p2", "error_thresh"]
    problem_defaults = ["LDC", "1.0", "1.0", "241", "241"]
    solver_defaults = ["100", "0.001", "0.001", "0.001", "1e-6"]

    problem_vars = []
    solver_vars = []

    for i, label in enumerate(problem_labels):
        var = tk.StringVar(value=problem_defaults[i])
        tk.Label(window, text=label).grid(row=i + 1, column=0, sticky="w")
        tk.Entry(window, textvariable=var, width=15).grid(row=i + 1, column=1)
        problem_vars.append(var)

    for i, label in enumerate(solver_labels):
        var = tk.StringVar(value=solver_defaults[i])
        tk.Label(window, text=label).grid(row=i + 1, column=3, sticky="w")
        tk.Entry(window, textvariable=var, width=15).grid(row=i + 1, column=4)
        solver_vars.append(var)

    row_offset = len(problem_labels) + 2

    # === Fluid Properties ===
    tk.Label(window, text="=== Fluid Properties ===", font=("Arial", 12, "bold")).grid(row=row_offset, column=0, columnspan=4)

    fluid1_labels = ["rho (fluid 1)", "mu (fluid 1)"]
    fluid2_labels = ["rho (fluid 2)", "mu (fluid 2)"]
    fluid1_defaults = ["1.0", "0.001"]
    fluid2_defaults = ["0.0", "0.0"]

    fluid1_vars = []
    fluid2_vars = []

    for i, label in enumerate(fluid1_labels):
        var1 = tk.StringVar(value=fluid1_defaults[i])
        var2 = tk.StringVar(value=fluid2_defaults[i])
        tk.Label(window, text=label).grid(row=row_offset + i + 1, column=0, sticky="w")
        tk.Entry(window, textvariable=var1, width=15).grid(row=row_offset + i + 1, column=1)
        tk.Label(window, text=fluid2_labels[i]).grid(row=row_offset + i + 1, column=3, sticky="w")
        tk.Entry(window, textvariable=var2, width=15).grid(row=row_offset + i + 1, column=4)
        fluid1_vars.append(var1)
        fluid2_vars.append(var2)

    bc_start_row = row_offset + len(fluid1_labels) + 3
    tk.Label(window, text="=== Boundary Conditions ===", font=("Arial", 12, "bold")).grid(row=bc_start_row, column=0, columnspan=8)

    bc_row_left = bc_start_row + 1
    bc_row_right = bc_start_row + 1

    def make_bc_block(start_col, start_row, selected_walls):
        row = start_row
        tk.Label(window, text="Wall").grid(row=row, column=start_col)
        tk.Label(window, text="Field").grid(row=row, column=start_col + 1)
        tk.Label(window, text="Init (type, value)").grid(row=row, column=start_col + 2)
        tk.Label(window, text="BC (type, value)").grid(row=row, column=start_col + 3)
        row += 1

        for wall in selected_walls:
            for field in fields:
                init_var = tk.StringVar(value=f"{default_init[field][0]}, {default_init[field][1]}")
                bc_var = tk.StringVar(value=f"{default_bc[field][0]}, {default_bc[field][1]}")
                tk.Label(window, text=wall.upper()).grid(row=row, column=start_col)
                tk.Label(window, text=field).grid(row=row, column=start_col + 1)
                tk.Entry(window, textvariable=init_var, width=18).grid(row=row, column=start_col + 2)
                tk.Entry(window, textvariable=bc_var, width=18).grid(row=row, column=start_col + 3)
                entries[(wall, field)] = {"init": init_var, "bc": bc_var}
                row += 1
        return row

    bc_row_left = make_bc_block(0, bc_row_left, walls_left)
    bc_row_right = make_bc_block(5, bc_row_right, walls_right)

    max_row = max(bc_row_left, bc_row_right)
    tk.Button(window, text="Save Parameter File", command=lambda: save_config(problem_vars, solver_vars, fluid1_vars, fluid2_vars, entries, window), bg="lightgreen").grid(row=max_row + 1, column=0, columnspan=8, pady=10)

    window.mainloop()


def save_config(problem_vars, solver_vars, fluid1_vars, fluid2_vars, entries, window):
    config = configparser.ConfigParser()

    problem_name = problem_vars[0].get().strip()
    if not problem_name:
        messagebox.showerror("Error", "Problem name cannot be empty.")
        return

    config['problem'] = dict(zip(["name", "xlength", "ylength", "xmax", "ymax"], [v.get() for v in problem_vars]))
    config['solver'] = dict(zip(["Re", "alpha_uv", "alpha_p1", "alpha_p2", "error_thresh"], [v.get() for v in solver_vars]))
    config['fluid.1'] = dict(zip(["rho", "mu"], [v.get() for v in fluid1_vars]))
    config['fluid.2'] = dict(zip(["rho", "mu"], [v.get() for v in fluid2_vars]))

    for (wall, field), vars_dict in entries.items():
        section = f"boundary.{wall}.{field}"
        config[section] = {
            "init": vars_dict["init"].get(),
            "bc": vars_dict["bc"].get()
        }

    output_path = os.path.join("input", f"{problem_name}.par")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as configfile:
        config.write(configfile)

    messagebox.showinfo("Success", f"Parameter file saved to:\n{output_path}")
    window.destroy()


