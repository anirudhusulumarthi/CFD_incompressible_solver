import configparser
import sys
import ast
import os
import glob
from typing import Dict, Tuple
from enum import Enum

class InitType(Enum):
    VALUE = "value"
    NONE = "none"

class BCType(Enum):
    VALUE = "value"
    NO_SLIP = "no_slip"
    ZERO_GRAD = "zero_grad"
    NO_PENETRATION = "no_penetration"
    NONE = "none"

def resolve_parameter_file():
    if len(sys.argv) == 2:
        param_file = sys.argv[1]
    else:
        # Automatically find latest .par file in input/
        par_files = glob.glob("input/*.par")
        if not par_files:
            print("[ERROR] No .par file found in input/.")
            sys.exit(1)
        param_file = max(par_files, key=os.path.getctime)
        print(f"[INFO] Using latest .par file: {param_file}")

    if not os.path.isfile(param_file):
        print(f"[ERROR] Parameter file not found: {param_file}")
        sys.exit(1)

    return param_file


class Parameters:
    def __init__(self):
        self.problem_name: str = "not_exist"
        self.xlength: float = 0.0
        self.ylength: float = 0.0
        self.zlength: float = 0.0
        
        self.xmax: int = 0
        self.ymax: int = 0
        self.zmax: int = 0

        self.Re: int = 0
        self.alpha_uv: float = 0.0
        self.alpha_p1: float = 0.0
        self.alpha_p2: float = 0.0
        self.error_thresh: float = 0.0
        self.rho_primary: float = 0.0
        self.mu_primary: float = 0.0
        self.rho_secondary: float = 0.0
        self.mu_secondary: float = 0.0
        self.max_solve_ittr: float = 0.0
        self.max_p_ittr_prloop: int = 0
        self.start_time: float = 0.0
        self.end_time: float = 0.0
        self.dt: float = 0.0
        self.cfl: float = 1.0

        
        
def extract_parameters():
    param_file = resolve_parameter_file()
    print(f"[INFO] Ready to use parameter file: {param_file}")

    config = configparser.ConfigParser()
    config.read(param_file)

    params = Parameters()

    # Problem geometry and solver values
    problem = config["problem"]
    solver = config["solver"]
    fluid1 = config["fluid.1"]
    fluid2 = config["fluid.2"]
    time = config["time"]
    

    params.problem_name = problem.get("name", "not_exist")
    params.xlength = float(problem.get("xlength", 0.0))
    params.ylength = float(problem.get("ylength", 0.0))
    params.zlength = float(problem.get("zlength", 0.0))
    params.xmax = int(problem.get("xmax", 0))
    params.ymax = int(problem.get("ymax", 0))
    params.zmax = int(problem.get("zmax", 0))

    params.Re = int(solver.get("Re", 0))
    params.alpha_uvw = float(solver.get("alpha_uvw", 0.0))
    params.alpha_p1 = float(solver.get("alpha_p1", 0.0))
    params.alpha_p2 = float(solver.get("alpha_p2", 0.0))
    params.error_thresh = float(solver.get("error_thresh", 0.0))
    params.max_solve_ittr = float(solver.get("maximum_solver_itterations", 0.0))
    params.max_p_ittr_prloop = int(solver.get("maximum_pressure_loop_itterations", 0))

    params.start_time = float(time.get("start_time", 0.0))
    params.end_time = float(time.get("end_time", 0.0))
    params.dt = float(time.get("dt", 0.0))
    params.cfl = float(time.get("cfl", 1.0))

    params.rho_primary = float(fluid1.get("rho", 0.0))
    params.mu_primary = float(fluid1.get("mu", 0.0))
    params.rho_secondary = float(fluid2.get("rho", 0.0))
    params.mu_secondary = float(fluid2.get("mu", 0.0))

    

    return params
