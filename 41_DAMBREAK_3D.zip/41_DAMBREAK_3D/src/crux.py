# ==============================
# File: crux.py
# ==============================

import math
from numba import njit, prange
from numba import set_num_threads, get_num_threads
set_num_threads(12)  # can be overridden externally before import if needed

########################################################################################################################################################################
# X MOMENTUM SOLVER
########################################################################################################################################################################

from numba import njit, prange

@njit(parallel=True, fastmath=True, cache=True)
def compute_u(
    u, v, w, p,
    uM1, uM2,
    rho, rhoM1, rhoM2,
    mu,
    dx, dy, dz, dt,
    alpha_uv,
    d_ratio_x_1,
    u_s1,
    aw, ae, as_, an, ab, at_, ap
):
    """
    3D extension of your 2D x-momentum step.

    Notation follows your 2D code:
      - D = eta * (A / d)
      - F = rho * A * velocity_normal_to_face
    Where face areas are:
      - x-faces:  A_x = dy * dz
      - y-faces:  A_y = dx * dz
      - z-faces:  A_z = dx * dy

    TVD/source hook:
      Replace the Sx, Sy, Sz lines with your limiter/source routine if needed,
      e.g. `Sx, Sy, Sz = compute_sources_3d(...)`.
    """
    nx, ny, nz = u.shape

    Ax = dy * dz
    Ay = dx * dz
    Az = dx * dy

    # Main sweep (skip outer guard cells and leave room for i-2/i+1 access like your 2D code)
    for k in prange(1, nz - 1):
        for j in range(1, ny - 1):
            for i in range(2, nx - 1):
                # === Viscous face viscosities (simple arithmetic means like your 2D code) ===
                eta_w =  mu[i - 1, j, k]
                eta_e =  mu[i,     j, k]

                eta_s = 0.25 * ( mu[i - 1, j,     k] + mu[i - 1, j - 1, k] #notsure
                               + mu[i,     j - 1, k] + mu[i,     j,     k] )
                eta_n = 0.25 * ( mu[i - 1, j,     k] + mu[i - 1, j + 1, k] #notsure
                               + mu[i,     j + 1, k] + mu[i,     j,     k] )

                eta_b = 0.25 * ( mu[i - 1, j, k    ] + mu[i - 1, j, k - 1] #notsure
                               + mu[i,     j, k - 1] + mu[i,     j, k    ] )
                eta_t = 0.25 * ( mu[i - 1, j, k    ] + mu[i - 1, j, k + 1] #notsure
                               + mu[i,     j, k + 1] + mu[i,     j, k    ] )

                # === Convective fluxes (rho * A * face-normal velocity) ===
                # x-faces use u and area Ax
                Fw = 0.5 * ( ((rho[i,     j, k] + rho[i - 1, j, k]) * 0.5 * u[i,     j, k]) +
                             ((rho[i - 1, j, k] + rho[i - 2, j, k]) * 0.5 * u[i - 1, j, k]) ) * Ax

                Fe = 0.5 * ( ((rho[i,     j, k] + rho[i - 1, j, k]) * 0.5 * u[i,     j, k]) +
                             ((rho[i,     j, k] + rho[i + 1, j, k]) * 0.5 * u[i + 1, j, k]) ) * Ax

                # y-faces use v and area Ay; collocated interpolation copied from your 2D style
                Fs = 0.5 * ( ((rho[i - 1, j,     k] + rho[i - 1, j - 1, k]) * 0.5 * v[i - 1, j,     k]) +
                             ((rho[i,     j,     k] + rho[i,     j - 1, k]) * 0.5 * v[i,     j,     k]) ) * Ay

                Fn = 0.5 * ( ((rho[i - 1, j,     k] + rho[i - 1, j + 1, k]) * 0.5 * v[i - 1, j + 1, k]) +
                             ((rho[i,     j,     k] + rho[i,     j + 1, k]) * 0.5 * v[i,     j + 1, k]) ) * Ay

                # z-faces use w and area Az
                Fb = 0.5 * ( ((rho[i - 1, j, k    ] + rho[i - 1, j, k - 1]) * 0.5 * w[i - 1, j, k    ]) +
                             ((rho[i,     j, k    ] + rho[i,     j, k - 1]) * 0.5 * w[i,     j, k    ]) ) * Az

                Ft = 0.5 * ( ((rho[i - 1, j, k    ] + rho[i - 1, j, k + 1]) * 0.5 * w[i - 1, j, k + 1]) +
                             ((rho[i,     j, k    ] + rho[i,     j, k + 1]) * 0.5 * w[i,     j, k + 1]) ) * Az

                # === Diffusive conductances D = eta * (A / d) ===
                Dw = eta_w * (Ax / dx)
                De = eta_e * (Ax / dx)
                Ds = eta_s * (Ay / dy)
                Dn = eta_n * (Ay / dy)
                Db = eta_b * (Az / dz)
                Dt = eta_t * (Az / dz)

                # === Coefficients (upwind via max as in your code) ===
                aw[i, j, k] = Dw + max(Fw, 0.0)
                ae[i, j, k] = De + max(-Fe, 0.0)
                as_[i, j, k] = Ds + max(Fs, 0.0)
                an[i, j, k] = Dn + max(-Fn, 0.0)
                ab[i, j, k] = Db + max(Fb, 0.0)
                at_[i, j, k] = Dt + max(-Ft, 0.0)

                aw_ijk = aw[i, j, k]; ae_ijk = ae[i, j, k]
                as_ijk = as_[i, j, k]; an_ijk = an[i, j, k]
                ab_ijk = ab[i, j, k];  at_ijk = at_[i, j, k]

                ap[i, j, k] = (aw_ijk + ae_ijk + as_ijk + an_ijk + ab_ijk + at_ijk
                               + (Fe - Fw) + (Fn - Fs) + (Ft - Fb))
                # //=============================================================
                Sx = 0.0
                Sy = 0.0
                Sz = 0.0

                # === Temporal terms ===
                vol = dx * dy * dz
                rho_pc  = 0.5 * (rho[i, j, k] + rho[i - 1, j, k])
                rho_pM1 = 0.5 * (rhoM1[i, j, k] + rhoM1[i - 1, j, k])
                rho_pM2 = 0.5 * (rhoM2[i, j, k] + rhoM2[i - 1, j, k])

                St_a =  2.0 * (rho_pM1 * uM1[i, j, k] * vol) / dt
                St_b = -0.5 * (rho_pM2 * uM2[i, j, k] * vol) / dt
                a_ip =  1.5 * (rho_pc   * vol) / dt

                ap[i, j, k] += a_ip

                # pressure gradient multiplier; follows your pattern (area/ap)
                d_ratio_x_1[i, j, k] = Ax / ap[i, j, k]

                # === RHS / neighbor contribution ===
                neighbor = (aw_ijk * u[i - 1, j, k] + ae_ijk * u[i + 1, j, k] +
                            as_ijk * u[i, j - 1, k] + an_ijk * u[i, j + 1, k] +
                            ab_ijk * u[i, j, k - 1] + at_ijk * u[i, j, k + 1] +
                            (St_a + St_b) + Sx + Sy + Sz) / ap[i, j, k]

                pressure = (p[i - 1, j, k] - p[i, j, k]) * d_ratio_x_1[i, j, k]

                u_s1[i, j, k] = neighbor + pressure
                u_s1[i, j, k] = alpha_uv * u_s1[i, j, k] + (1.0 - alpha_uv) * u[i, j, k]


    for i in range(1, nx):
        for k in range(0, nz):
            aw[i, 0,     k] = aw[i, 1,     k]
            aw[i, ny - 1,k] = aw[i, ny - 2,k]
            ae[i, 0,     k] = ae[i, 1,     k]
            ae[i, ny - 1,k] = ae[i, ny - 2,k]
            as_[i, 0,     k] = as_[i, 1,     k]
            as_[i, ny - 1,k] = as_[i, ny - 2,k]
            an[i, 0,     k] = an[i, 1,     k]
            an[i, ny - 1,k] = an[i, ny - 2,k]
            ab[i, 0,     k] = ab[i, 1,     k]
            ab[i, ny - 1,k] = ab[i, ny - 2,k]
            at_[i, 0,     k] = at_[i, 1,     k]
            at_[i, ny - 1,k] = at_[i, ny - 2,k]
            ap[i, 0,     k] = ap[i, 1,     k]
            ap[i, ny - 1,k] = ap[i, ny - 2,k]

    # Copy along i,k at all j (x & z boundaries)
    for j in range(1, ny - 1):
        for k in range(0, nz):
            aw[1,     j, k] = aw[2,     j, k]
            aw[nx - 1,j, k] = aw[nx - 2,j, k]
            ae[1,     j, k] = ae[2,     j, k]
            ae[nx - 1,j, k] = ae[nx - 2,j, k]
            as_[1,     j, k] = as_[2,     j, k]
            as_[nx - 1,j, k] = as_[nx - 2,j, k]
            an[1,     j, k] = an[2,     j, k]
            an[nx - 1,j, k] = an[nx - 2,j, k]
            ab[1,     j, k] = ab[2,     j, k]
            ab[nx - 1,j, k] = ab[nx - 2,j, k]
            at_[1,     j, k] = at_[2,     j, k]
            at_[nx - 1,j, k] = at_[nx - 2,j, k]
            ap[1,     j, k] = ap[2,     j, k]
            ap[nx - 1,j, k] = ap[nx - 2,j, k]

    # Copy along i,j at all k (x & y boundaries)
    for j in range(0, ny):
        for i in range(1, nx):
            aw[i, j, 0    ] = aw[i, j, 1    ]
            aw[i, j, nz-1 ] = aw[i, j, nz-2 ]
            ae[i, j, 0    ] = ae[i, j, 1    ]
            ae[i, j, nz-1 ] = ae[i, j, nz-2 ]
            as_[i, j, 0    ] = as_[i, j, 1    ]
            as_[i, j, nz-1 ] = as_[i, j, nz-2 ]
            an[i, j, 0    ] = an[i, j, 1    ]
            an[i, j, nz-1 ] = an[i, j, nz-2 ]
            ab[i, j, 0    ] = ab[i, j, 1    ]
            ab[i, j, nz-1 ] = ab[i, j, nz-2 ]
            at_[i, j, 0    ] = at_[i, j, 1    ]
            at_[i, j, nz-1 ] = at_[i, j, nz-2 ]
            ap[i, j, 0    ] = ap[i, j, 1    ]
            ap[i, j, nz-1 ] = ap[i, j, nz-2 ]


########################################################################################################################################################################
# Y MOMENTUM SOLVER
########################################################################################################################################################################

from numba import njit, prange

@njit(parallel=True, fastmath=True, cache=True)
def compute_v(
    u, v, w, p,
    vM1, vM2,
    rho, rhoM1, rhoM2,
    mu,
    dx, dy, dz, dt,
    alpha_uv,
    d_ratio_y_1,
    v_s1,
    aw, ae, as_, an, ab, at_, ap
):
    """
    3D y-momentum (v) predictor, patterned on your 2D compute_v().
    Notation:
      D = eta * (A / d)
      F = rho * A * (velocity normal to face)

    Face areas:
      - x-faces: Ax = dy * dz
      - y-faces: Ay = dx * dz
      - z-faces: Az = dx * dy

    Gravity follows your 2D style: gravity_term = rho_avg * (Ay/ap) * dy * g
    (since (Ay/ap)*dy == cell volume / ap).
    """
    nx, ny, nz = v.shape

    Ax = dy * dz
    Ay = dx * dz
    Az = dx * dy

    # Main interior sweep (j starts at 2 to allow j-2 access like your 2D code)
    for k in prange(1, nz - 1):
        for j in range(2, ny - 1):
            for i in range(1, nx - 1):
                # === Face viscosities (match your 2D averaging patterns) ===
                # west/east (average around (i-1/ i) & rows j/j-1)
                eta_w = 0.25 * (mu[i,     j, k] + mu[i - 1, j, k] +
                                mu[i - 1, j - 1, k] + mu[i,     j - 1, k])
                eta_e = 0.25 * (mu[i,     j, k] + mu[i + 1, j, k] +
                                mu[i,     j - 1, k] + mu[i + 1, j - 1, k])

                # south/north (use lower/upper cell like your 2D)
                eta_s = mu[i, j - 1, k]
                eta_n = mu[i, j,     k]

                # bottom/top (average around k-1/k & rows j/j-1)
                eta_b = 0.25 * (mu[i, j,     k    ] + mu[i, j,     k - 1] +
                                mu[i, j - 1, k - 1] + mu[i, j - 1, k    ])
                eta_t = 0.25 * (mu[i, j,     k    ] + mu[i, j,     k + 1] +
                                mu[i, j - 1, k + 1] + mu[i, j - 1, k    ])

                # === Convective fluxes (rho * A * face-normal vel) ===
                # x-faces use u, with the same two-row (j and j-1) blending as in your 2D code
                Fw = 0.5 * ( (0.5 * (rho[i,     j, k] + rho[i - 1, j, k]) * u[i,     j, k]) +
                             (0.5 * (rho[i, j - 1, k] + rho[i - 1, j - 1, k]) * u[i, j - 1, k]) ) * Ax

                Fe = 0.5 * ( (0.5 * (rho[i,     j, k] + rho[i + 1, j, k]) * u[i + 1, j, k]) +
                             (0.5 * (rho[i, j - 1, k] + rho[i + 1, j - 1, k]) * u[i + 1, j - 1, k]) ) * Ax

                # y-faces use v
                Fs = 0.5 * ( (0.5 * (rho[i, j,     k] + rho[i, j - 1, k]) * v[i, j,     k]) +
                             (0.5 * (rho[i, j - 1, k] + rho[i, j - 2, k]) * v[i, j - 1, k]) ) * Ay

                Fn = 0.5 * ( (0.5 * (rho[i, j,     k] + rho[i, j - 1, k]) * v[i, j,     k]) +
                             (0.5 * (rho[i, j,     k] + rho[i, j + 1, k]) * v[i, j + 1, k]) ) * Ay

                # z-faces use w, blended across rows j and j-1 (analogue of x-faces above)
                Fb = 0.5 * ( (0.5 * (rho[i, j,     k] + rho[i, j,     k - 1]) * w[i, j,     k]) +
                             (0.5 * (rho[i, j - 1, k] + rho[i, j - 1, k - 1]) * w[i, j - 1, k]) ) * Az

                Ft = 0.5 * ( (0.5 * (rho[i, j,     k] + rho[i, j,     k + 1]) * w[i, j,     k + 1]) +
                             (0.5 * (rho[i, j - 1, k] + rho[i, j - 1, k + 1]) * w[i, j - 1, k + 1]) ) * Az

                # === Diffusion conductances D = eta * (A/d) ===
                Dw = eta_w * (Ax / dx)
                De = eta_e * (Ax / dx)
                Ds = eta_s * (Ay / dy)
                Dn = eta_n * (Ay / dy)
                Db = eta_b * (Az / dz)
                Dt = eta_t * (Az / dz)

                # === Coefficients (first-order upwind via max(±F,0)) ===
                aw[i, j, k] = Dw + max(Fw, 0.0)
                ae[i, j, k] = De + max(-Fe, 0.0)
                as_[i, j, k] = Ds + max(Fs, 0.0)
                an[i, j, k] = Dn + max(-Fn, 0.0)
                ab[i, j, k] = Db + max(Fb, 0.0)
                at_[i, j, k] = Dt + max(-Ft, 0.0)

                aw_ijk = aw[i, j, k]; ae_ijk = ae[i, j, k]
                as_ijk = as_[i, j, k]; an_ijk = an[i, j, k]
                ab_ijk = ab[i, j, k];  at_ijk = at_[i, j, k]

                ap[i, j, k] = (aw_ijk + ae_ijk + as_ijk + an_ijk + ab_ijk + at_ijk
                               + (Fe - Fw) + (Fn - Fs) + (Ft - Fb))

                # === TVD/source hook (mirror your API; set to 0.0 if not used) ===
                # Sx, Sy, Sz = compute_sources_3d(v, nx, ny, nz, i, j, k, Fw, Fe, Fs, Fn, Fb, Ft)
                Sx = 0.0
                Sy = 0.0
                Sz = 0.0

                # === Temporal terms (same Adams–Bashforth pattern) ===
                vol    = dx * dy * dz
                rho_pc = 0.5 * (rho[i, j, k] + rho[i, j - 1, k])
                rho_pM1 = 0.5 * (rhoM1[i, j, k] + rhoM1[i, j - 1, k])
                rho_pM2 = 0.5 * (rhoM2[i, j, k] + rhoM2[i, j - 1, k])

                St_a =  2.0 * (rho_pM1 * vM1[i, j, k] * vol) / dt
                St_b = -0.5 * (rho_pM2 * vM2[i, j, k] * vol) / dt
                a_ip =  1.5 * (rho_pc  * vol) / dt
                ap[i, j, k] += a_ip

                # Pressure multiplier: (Ay / ap) as in your 2D d_ratio_y_1 = dx/ap (here with thickness dz)
                d_ratio_y_1[i, j, k] = Ay / ap[i, j, k]

                # Gravity like your 2D: rho_avg * (Vol/ap) * g => use (Ay/ap)*dy == vol/ap
                rho_avg = 0.5 * (rho[i, j, k] + rho[i, j - 1, k])
                gravity = rho_avg * d_ratio_y_1[i, j, k] * dy * (-9.81)

                # === RHS / neighbor contribution ===
                neighbor = (aw_ijk * v[i - 1, j, k] + ae_ijk * v[i + 1, j, k] +
                            as_ijk * v[i, j - 1, k] + an_ijk * v[i, j + 1, k] +
                            ab_ijk * v[i, j, k - 1] + at_ijk * v[i, j, k + 1] +
                            (St_a + St_b) + Sx + Sy + Sz) / ap[i, j, k]

                pressure = d_ratio_y_1[i, j, k] * (p[i, j - 1, k] - p[i, j, k])

                v_s1[i, j, k] = neighbor + pressure + gravity
                v_s1[i, j, k] = alpha_uv * v_s1[i, j, k] + (1.0 - alpha_uv) * v[i, j, k]

    # === Boundary coefficient copying (3D extension of your 2D post-pass) ===
    # Copy along y at all (i,k)
    for i in range(0, nx):
        for k in range(0, nz):
            aw[i, 1,     k] = aw[i, 2,     k]
            aw[i, ny - 1,k] = aw[i, ny - 2,k]
            ae[i, 1,     k] = ae[i, 2,     k]
            ae[i, ny - 1,k] = ae[i, ny - 2,k]
            as_[i, 1,     k] = as_[i, 2,     k]
            as_[i, ny - 1,k] = as_[i, ny - 2,k]
            an[i, 1,     k] = an[i, 2,     k]
            an[i, ny - 1,k] = an[i, ny - 2,k]
            ab[i, 1,     k] = ab[i, 2,     k]
            ab[i, ny - 1,k] = ab[i, ny - 2,k]
            at_[i, 1,     k] = at_[i, 2,     k]
            at_[i, ny - 1,k] = at_[i, ny - 2,k]
            ap[i, 1,     k] = ap[i, 2,     k]
            ap[i, ny - 1,k] = ap[i, ny - 2,k]

    # Copy along x at all (j,k)
    for j in range(1, ny - 1):
        for k in range(0, nz):
            aw[1,     j, k] = aw[2,     j, k]
            aw[nx - 1,j, k] = aw[nx - 2,j, k]
            ae[1,     j, k] = ae[2,     j, k]
            ae[nx - 1,j, k] = ae[nx - 2,j, k]
            as_[1,     j, k] = as_[2,     j, k]
            as_[nx - 1,j, k] = as_[nx - 2,j, k]
            an[1,     j, k] = an[2,     j, k]
            an[nx - 1,j, k] = an[nx - 2,j, k]
            ab[1,     j, k] = ab[2,     j, k]
            ab[nx - 1,j, k] = ab[nx - 2,j, k]
            at_[1,     j, k] = at_[2,     j, k]
            at_[nx - 1,j, k] = at_[nx - 2,j, k]
            ap[1,     j, k] = ap[2,     j, k]
            ap[nx - 1,j, k] = ap[nx - 2,j, k]

    # Copy along z at all (i,j)
    for j in range(0, ny):
        for i in range(0, nx):
            aw[i, j, 0    ] = aw[i, j, 1    ]
            aw[i, j, nz-1 ] = aw[i, j, nz-2 ]
            ae[i, j, 0    ] = ae[i, j, 1    ]
            ae[i, j, nz-1 ] = ae[i, j, nz-2 ]
            as_[i, j, 0    ] = as_[i, j, 1    ]
            as_[i, j, nz-1 ] = as_[i, j, nz-2 ]
            an[i, j, 0    ] = an[i, j, 1    ]
            an[i, j, nz-1 ] = an[i, j, nz-2 ]
            ab[i, j, 0    ] = ab[i, j, 1    ]
            ab[i, j, nz-1 ] = ab[i, j, nz-2 ]
            at_[i, j, 0    ] = at_[i, j, 1    ]
            at_[i, j, nz-1 ] = at_[i, j, nz-2 ]
            ap[i, j, 0    ] = ap[i, j, 1    ]
            ap[i, j, nz-1 ] = ap[i, j, nz-2 ]


########################################################################################################################################################################
# Z MOMENTUM SOLVER
########################################################################################################################################################################


@njit(parallel=True, fastmath=True, cache=True)
def compute_w(
    u, v, w, p,
    wM1, wM2,
    rho, rhoM1, rhoM2,
    mu,
    dx, dy, dz, dt,
    alpha_uv,
    d_ratio_z_1,
    w_s1,
    aw, ae, as_, an, ab, at_, ap
):
    """
    3D z-momentum (w) predictor, patterned on your 2D/3D style.

    D = eta * (A / d)
    F = rho * A * (velocity normal to face)

    Face areas:
      Ax (x-faces) = dy * dz
      Ay (y-faces) = dx * dz
      Az (z-faces) = dx * dy
    """
    nx, ny, nz = w.shape

    Ax = dy * dz
    Ay = dx * dz
    Az = dx * dy

    # If z is vertical in your setup, set g_z = -9.81
    g_z = 0.0

    # Interior sweep (k starts at 2 due to k-2 access in Fb, like your 2D v-case used j-2)
    for k in prange(2, nz - 1):
        for j in range(1, ny - 1):
            for i in range(1, nx - 1):
                # --- Viscosities on faces (averaging matches your patterns) ---
                # west/east (average across k/k-1 slab around i-1/ i)
                eta_w = 0.25 * (mu[i - 1, j, k] + mu[i - 1, j, k - 1] +
                                mu[i,     j, k - 1] + mu[i,     j, k])
                eta_e = 0.25 * (mu[i + 1, j, k] + mu[i + 1, j, k - 1] +
                                mu[i,     j, k - 1] + mu[i,     j, k])

                # south/north (average across k/k-1 slab around j-1/ j)
                eta_s = 0.25 * (mu[i, j - 1, k] + mu[i, j - 1, k - 1] +
                                mu[i, j,     k - 1] + mu[i, j,     k])
                eta_n = 0.25 * (mu[i, j + 1, k] + mu[i, j + 1, k - 1] +
                                mu[i, j,     k - 1] + mu[i, j,     k])

                # bottom/top (direct)
                eta_b = mu[i, j, k - 1]
                eta_t = mu[i, j, k]

                # --- Convective fluxes (rho * A * face-normal vel) ---
                # x-faces use u, blended across k and k-1 (analogue of v blending across j/j-1)
                Fw = 0.5 * ( (0.5 * (rho[i,     j, k] + rho[i - 1, j, k]) * u[i,     j, k]) +
                             (0.5 * (rho[i,     j, k - 1] + rho[i - 1, j, k - 1]) * u[i, j, k - 1]) ) * Ax

                Fe = 0.5 * ( (0.5 * (rho[i,     j, k] + rho[i + 1, j, k]) * u[i + 1, j, k]) +
                             (0.5 * (rho[i,     j, k - 1] + rho[i + 1, j, k - 1]) * u[i + 1, j, k - 1]) ) * Ax

                # y-faces use v, blended across k and k-1
                Fs = 0.5 * ( (0.5 * (rho[i, j,     k] + rho[i, j - 1, k]) * v[i, j,     k]) +
                             (0.5 * (rho[i, j,     k - 1] + rho[i, j - 1, k - 1]) * v[i, j, k - 1]) ) * Ay

                Fn = 0.5 * ( (0.5 * (rho[i, j,     k] + rho[i, j + 1, k]) * v[i, j + 1, k]) +
                             (0.5 * (rho[i, j,     k - 1] + rho[i, j + 1, k - 1]) * v[i, j + 1, k - 1]) ) * Ay

                # z-faces use w (like 2D v uses itself across j-1/j)
                Fb = 0.5 * ( (0.5 * (rho[i, j, k] + rho[i, j, k - 1]) * w[i, j, k]) +
                             (0.5 * (rho[i, j, k - 1] + rho[i, j, k - 2]) * w[i, j, k - 1]) ) * Az

                Ft = 0.5 * ( (0.5 * (rho[i, j, k] + rho[i, j, k - 1]) * w[i, j, k]) +
                             (0.5 * (rho[i, j, k] + rho[i, j, k + 1]) * w[i, j, k + 1]) ) * Az

                # --- Diffusion conductances ---
                Dw = eta_w * (Ax / dx)
                De = eta_e * (Ax / dx)
                Ds = eta_s * (Ay / dy)
                Dn = eta_n * (Ay / dy)
                Db = eta_b * (Az / dz)
                Dt = eta_t * (Az / dz)

                # --- Coefficients (upwind via max) ---
                aw[i, j, k] = Dw + max(Fw, 0.0)
                ae[i, j, k] = De + max(-Fe, 0.0)
                as_[i, j, k] = Ds + max(Fs, 0.0)
                an[i, j, k] = Dn + max(-Fn, 0.0)
                ab[i, j, k] = Db + max(Fb, 0.0)
                at_[i, j, k] = Dt + max(-Ft, 0.0)

                aw_ijk = aw[i, j, k]; ae_ijk = ae[i, j, k]
                as_ijk = as_[i, j, k]; an_ijk = an[i, j, k]
                ab_ijk = ab[i, j, k];  at_ijk = at_[i, j, k]

                ap[i, j, k] = (aw_ijk + ae_ijk + as_ijk + an_ijk + ab_ijk + at_ijk
                               + (Fe - Fw) + (Fn - Fs) + (Ft - Fb))

                # --- TVD/source hook (set to 0.0 if unused) ---
                # Sx, Sy, Sz = compute_sources_3d(w, nx, ny, nz, i, j, k, Fw, Fe, Fs, Fn, Fb, Ft)
                Sx = 0.0
                Sy = 0.0
                Sz = 0.0

                # --- Temporal terms (Adams–Bashforth 2) ---
                vol     = dx * dy * dz
                rho_pc  = 0.5 * (rho[i, j, k] + rho[i, j, k - 1])
                rho_pM1 = 0.5 * (rhoM1[i, j, k] + rhoM1[i, j, k - 1])
                rho_pM2 = 0.5 * (rhoM2[i, j, k] + rhoM2[i, j, k - 1])

                St_a =  2.0 * (rho_pM1 * wM1[i, j, k] * vol) / dt
                St_b = -0.5 * (rho_pM2 * wM2[i, j, k] * vol) / dt
                a_ip =  1.5 * (rho_pc  * vol) / dt
                ap[i, j, k] += a_ip

                # Pressure multiplier (Az/ap); then use (p[k-1] - p[k])
                d_ratio_z_1[i, j, k] = Az / ap[i, j, k]

                # Gravity along z (vol/ap * rho * g_z) = rho_avg * (Az/ap) * dz * g_z
                rho_avg = 0.5 * (rho[i, j, k] + rho[i, j, k - 1])
                gravity = rho_avg * d_ratio_z_1[i, j, k] * dz * g_z

                # --- RHS / neighbor contribution ---
                neighbor = (aw_ijk * w[i - 1, j, k] + ae_ijk * w[i + 1, j, k] +
                            as_ijk * w[i, j - 1, k] + an_ijk * w[i, j + 1, k] +
                            ab_ijk * w[i, j, k - 1] + at_ijk * w[i, j, k + 1] +
                            (St_a + St_b) + Sx + Sy + Sz) / ap[i, j, k]

                pressure = d_ratio_z_1[i, j, k] * (p[i, j, k - 1] - p[i, j, k])

                w_s1[i, j, k] = neighbor + pressure + gravity
                w_s1[i, j, k] = alpha_uv * w_s1[i, j, k] + (1.0 - alpha_uv) * w[i, j, k]

    # --- Boundary coefficient mirroring (3D extension of your post-pass) ---
    # Along x at all (j,k)
    for j in range(1, ny - 1):
        for k in range(0, nz):
            aw[1,     j, k] = aw[2,     j, k]
            aw[nx - 1,j, k] = aw[nx - 2,j, k]
            ae[1,     j, k] = ae[2,     j, k]
            ae[nx - 1,j, k] = ae[nx - 2,j, k]
            as_[1,     j, k] = as_[2,     j, k]
            as_[nx - 1,j, k] = as_[nx - 2,j, k]
            an[1,     j, k] = an[2,     j, k]
            an[nx - 1,j, k] = an[nx - 2,j, k]
            ab[1,     j, k] = ab[2,     j, k]
            ab[nx - 1,j, k] = ab[nx - 2,j, k]
            at_[1,     j, k] = at_[2,     j, k]
            at_[nx - 1,j, k] = at_[nx - 2,j, k]
            ap[1,     j, k] = ap[2,     j, k]
            ap[nx - 1,j, k] = ap[nx - 2,j, k]

    # Along y at all (i,k)
    for i in range(0, nx):
        for k in range(0, nz):
            aw[i, 1,     k] = aw[i, 2,     k]
            aw[i, ny - 1,k] = aw[i, ny - 2,k]
            ae[i, 1,     k] = ae[i, 2,     k]
            ae[i, ny - 1,k] = ae[i, ny - 2,k]
            as_[i, 1,     k] = as_[i, 2,     k]
            as_[i, ny - 1,k] = as_[i, ny - 2,k]
            an[i, 1,     k] = an[i, 2,     k]
            an[i, ny - 1,k] = an[i, ny - 2,k]
            ab[i, 1,     k] = ab[i, 2,     k]
            ab[i, ny - 1,k] = ab[i, ny - 2,k]
            at_[i, 1,     k] = at_[i, 2,     k]
            at_[i, ny - 1,k] = at_[i, ny - 2,k]
            ap[i, 1,     k] = ap[i, 2,     k]
            ap[i, ny - 1,k] = ap[i, ny - 2,k]

    # Along z at all (i,j)
    for j in range(0, ny):
        for i in range(0, nx):
            aw[i, j, 0    ] = aw[i, j, 1    ]
            aw[i, j, nz-1 ] = aw[i, j, nz-2 ]
            ae[i, j, 0    ] = ae[i, j, 1    ]
            ae[i, j, nz-1 ] = ae[i, j, nz-2 ]
            as_[i, j, 0    ] = as_[i, j, 1    ]
            as_[i, j, nz-1 ] = as_[i, j, nz-2 ]
            an[i, j, 0    ] = an[i, j, 1    ]
            an[i, j, nz-1 ] = an[i, j, nz-2 ]
            ab[i, j, 0    ] = ab[i, j, 1    ]
            ab[i, j, nz-1 ] = ab[i, j, nz-2 ]
            at_[i, j, 0    ] = at_[i, j, 1    ]
            at_[i, j, nz-1 ] = at_[i, j, nz-2 ]
            ap[i, j, 0    ] = ap[i, j, 1    ]
            ap[i, j, nz-1 ] = ap[i, j, nz-2 ]



########################################################################################################################################################################
# PRESSURE MATRIX BUILDING (first)
########################################################################################################################################################################



@njit(parallel=True, fastmath=True, cache=True)
def compute_p_1(
    u_s1, v_s1, w_s1,   # staggered predicted velocities
    p_s1, b,            # pressure and RHS (both at cell centers)
    rho, rhoM1, rhoM2,  # densities (current, t-dt, t-2dt) at cell centers
    dx, dy, dz, dt,     # spacings and timestep
    drx, dry, drz       # face coefficients: A_face / a_p(momentum) at pressure faces
):
    """
    3D extension of your PPE assembly on a staggered (MAC) grid.

    Coefficients follow your 2D pattern:
      aw = rho_w * drx[i, j, k]     * dx
      ae = rho_e * drx[i+1, j, k]   * dx
      as = rho_s * dry[i, j, k]     * dy
      an = rho_n * dry[i, j+1, k]   * dy
      ab = rho_b * drz[i, j, k]     * dz
      at = rho_t * drz[i, j, k+1]   * dz

    RHS adds all three divergence parts with proper face areas:
      x: (rho_w*u_W - rho_e*u_E) * (dy*dz)
      y: (rho_s*v_S - rho_n*v_N) * (dx*dz)
      z: (rho_b*w_B - rho_t*w_T) * (dx*dy)

    Temporal term mirrors your 2D form using 3D volume.
    """
    nx, ny, nz = p_s1.shape
    vol = dx * dy * dz
    Ax = dy * dz
    Ay = dx * dz
    Az = dx * dy

    for k in prange(1, nz - 1):
        for j in range(1, ny - 1):
            for i in range(1, nx - 1):
                # Densities at pressure-cell faces (centered averages)
                rho_w = 0.5 * (rho[i, j, k] + rho[i - 1, j, k])
                rho_e = 0.5 * (rho[i, j, k] + rho[i + 1, j, k])
                rho_s = 0.5 * (rho[i, j, k] + rho[i, j - 1, k])
                rho_n = 0.5 * (rho[i, j, k] + rho[i, j + 1, k])
                rho_b = 0.5 * (rho[i, j, k] + rho[i, j, k - 1])
                rho_t = 0.5 * (rho[i, j, k] + rho[i, j, k + 1])

                # PPE neighbor coefficients (pattern matches your 2D code)
                aw = rho_w * drx[i,     j,     k] * dx
                ae = rho_e * drx[i + 1, j,     k] * dx
                as_ = rho_s * dry[i,     j,     k] * dy
                an  = rho_n * dry[i,     j + 1, k] * dy
                ab  = rho_b * drz[i,     j,     k] * dz
                at_ = rho_t * drz[i,     j,     k + 1] * dz

                ap = aw + ae + as_ + an + ab + at_

                # Temporal term (your AB-like density term, now with 3D volume)
                temporal_numerator = (3.0 * rho[i, j, k]) - 4.0 * rhoM1[i, j, k] + rhoM2[i, j, k]
                Temporal_rho = (temporal_numerator * vol) / (2.0 * rho[i, j, k] * dt)

                # Divergence of mass flux (uses face areas)
                bx = (rho_w * u_s1[i,     j,     k] - rho_e * u_s1[i + 1, j,     k]) * Ax
                by = (rho_s * v_s1[i,     j,     k] - rho_n * v_s1[i,     j + 1, k]) * Ay
                bz = (rho_b * w_s1[i,     j,     k] - rho_t * w_s1[i,     j,     k + 1]) * Az
                b[i, j, k] = bx + by + bz

                # Neighbor pressure contribution
                neighbor = (aw * p_s1[i - 1, j, k] + ae * p_s1[i + 1, j, k] +
                            as_ * p_s1[i, j - 1, k] + an * p_s1[i, j + 1, k] +
                            ab * p_s1[i, j, k - 1] + at_ * p_s1[i, j, k + 1])

                # Pressure update
                p_s1[i, j, k] = (b[i, j, k] + neighbor + Temporal_rho) / ap


#######################################################################################################################################################################
# NEW: CORRECTION KERNELS (formula-preserving)
########################################################################################################################################################################


@njit(parallel=True, fastmath=True, cache=True)
def corr_u_s2(u_s1, p_s1, d_ratio_x_1, u_s2):
    nx, ny, nz = u_s1.shape
    for k in prange(1, nz - 1):
        for j in prange(1, ny - 1):
            for i in range(2, nx - 1):
                u_s2[i, j, k] = u_s1[i, j, k] + (d_ratio_x_1[i, j, k] * (p_s1[i - 1, j, k] - p_s1[i, j, k]))


@njit(parallel=True, fastmath=True, cache=True)
def corr_v_s2(v_s1, p_s1, d_ratio_y_1, v_s2):
    nx, ny, nz = v_s1.shape
    for k in prange(1, nz - 1):
        for j in prange(2, ny - 1):
            for i in range(1, nx - 1):
                v_s2[i, j, k] = v_s1[i, j, k] + (d_ratio_y_1[i, j, k] * (p_s1[i, j - 1, k] - p_s1[i, j, k]))

@njit(parallel=True, fastmath=True, cache=True)
def corr_w_s2(w_s1, p_s1, d_ratio_z_1, w_s2):
    nx, ny, nz = w_s1.shape
    for k in prange(2, nz - 1):
        for j in prange(1, ny - 1):
            for i in range(1, nx - 1):
                w_s2[i, j, k] = w_s1[i, j, k] + (d_ratio_z_1[i, j, k] * (p_s1[i, j, k - 1] - p_s1[i, j, k]))


########################################################################################################################################################################
# REDUCTION & UTILITIES
########################################################################################################################################################################



@njit(parallel=True, fastmath=True, cache=True)
def reduce_abs_sum_interior(arr):
    nx, ny, nz = arr.shape
    acc = 0.0
    for k in prange(1, nz - 1):
        plane_sum = 0.0
        for j in range(1, ny - 1):
            row_sum = 0.0
            for i in range(1, nx - 1):
                row_sum += abs(arr[i, j, k])
            plane_sum += row_sum
        acc += plane_sum
    return acc






from numba import njit, prange

@njit(parallel=True, fastmath=True, cache=True)
def update_central_fields_njit(
    u_cen, v_cen, w_cen, p_cen, vof_cen,
    u_final, v_final, w_final,
    p_final, vof
):
    """
    Convert 3D staggered/MAC fields to collocated (cell-centered) fields.

    For a cell center (i,j,k):
      u_cen = average of the four x-face values that surround the cell center
      v_cen = average of the four y-face values that surround the cell center
      w_cen = average of the four z-face values that surround the cell center
      p_cen = average of the 8 nodal/corner pressures
      vof_cen = average of the 8 nodal/corner VOF values

    Indexing matches your 2D style, extended to k:
      - u uses i+1 (x-face between i and i+1), averaged across j and k
      - v uses j+1 (y-face between j and j+1), averaged across i and k
      - w uses k+1 (z-face between k and k+1), averaged across i and j
    """
    cnx, cny, cnz = u_cen.shape

    for k in prange(cnz):
        for j in range(cny):
            for i in range(cnx):
                # u at cell center: average over the four surrounding x-face samples
                u_cen[i, j, k] = 0.25 * (
                    u_final[i + 1, j,     k    ] +
                    u_final[i + 1, j + 1, k    ] +
                    u_final[i + 1, j,     k + 1] +
                    u_final[i + 1, j + 1, k + 1]
                )

                # v at cell center: average over the four surrounding y-face samples
                v_cen[i, j, k] = 0.25 * (
                    v_final[i,     j + 1, k    ] +
                    v_final[i + 1, j + 1, k    ] +
                    v_final[i,     j + 1, k + 1] +
                    v_final[i + 1, j + 1, k + 1]
                )

                # w at cell center: average over the four surrounding z-face samples
                w_cen[i, j, k] = 0.25 * (
                    w_final[i,     j,     k + 1] +
                    w_final[i + 1, j,     k + 1] +
                    w_final[i,     j + 1, k + 1] +
                    w_final[i + 1, j + 1, k + 1]
                )

                # pressure at cell center: average of the 8 surrounding nodes/corners
                p_cen[i, j, k] = 0.125 * (
                    p_final[i,     j,     k    ] + p_final[i + 1, j,     k    ] +
                    p_final[i,     j + 1, k    ] + p_final[i + 1, j + 1, k    ] +
                    p_final[i,     j,     k + 1] + p_final[i + 1, j,     k + 1] +
                    p_final[i,     j + 1, k + 1] + p_final[i + 1, j + 1, k + 1]
                )

                # VOF at cell center: average of the 8 surrounding nodes/corners
                vof_cen[i, j, k] = 0.125 * (
                    vof[i,     j,     k    ] + vof[i + 1, j,     k    ] +
                    vof[i,     j + 1, k    ] + vof[i + 1, j + 1, k    ] +
                    vof[i,     j,     k + 1] + vof[i + 1, j,     k + 1] +
                    vof[i,     j + 1, k + 1] + vof[i + 1, j + 1, k + 1]
                )







@njit(parallel=False, fastmath=True, cache=True)
def clear_fields_njit(u_s1, v_s1, w_s1, p_s1, u_s2, v_s2, w_s2, p_s2, u_s3, v_s3, w_s3, p_s3):
    u_s1[:] = 0.0
    v_s1[:] = 0.0
    w_s1[:] = 0.0
    p_s1[:] = 0.0
    u_s2[:] = 0.0
    v_s2[:] = 0.0
    w_s2[:] = 0.0
    p_s2[:] = 0.0
    u_s3[:] = 0.0
    v_s3[:] = 0.0
    w_s3[:] = 0.0
    p_s3[:] = 0.0


@njit(inline='always')
def update_dt(u, v, cfl, dx, dy):
    umax = np.max(np.abs(u))
    vmax = np.max(np.abs(v))
    
    denom = min(dx/umax, dy/vmax)
    return cfl * denom
########################################################################################################################################################################
# VOF Updates 
########################################################################################################################################################################
from numba import njit, prange
import numpy as np

@njit(inline='always')
def mc_limiter(r):
    if r <= 0.0:
        return 0.0
    a = 2.0 * r
    b = 0.5 * (1.0 + r)
    # minmod of {2r, 0.5(1+r), 2}
    return 2.0 if (2.0 < a and 2.0 < b) else (a if a < b else b)

@njit(inline='always')
def face_alpha_3d(alpha, i, j, k, F, dt, V, axis, nx, ny, nz, eps=1e-14):
    """
    MUSCL value of alpha at a face normal to `axis` ('x','y','z'),
    using a donor-cell fallback if the 2nd-upwind index would be OOB.
    Indices (i,j,k) refer to the UPWIND cell index on that axis:
      - west:  (i-1, j,   k) with flux Fw = u[i, j, k] * Ay  -> call with (i-1, j, k, axis='x')
      - east:  (i,   j,   k) with flux Fe = u[i+1,...]       -> call with (i,   j, k, axis='x')
      - south: (i,   j-1, k) with Fs = v[i, j, k] * Ax       -> axis='y'
      - north: (i,   j,   k) with Fn = v[i, j+1, k] * Ax     -> axis='y'
      - bottom:(i,   j,   k-1) with Fb = w[i, j, k] * Az     -> axis='z'
      - top:   (i,   j,   k) with Ft = w[i, j, k+1] * Az     -> axis='z'
    """
    if F == 0.0:
        return alpha[i, j, k]

    if axis == 0:  # x
        if F > 0.0:
            if i - 1 < 0:
                return alpha[i, j, k]                  # donor
            up2 = alpha[i - 1, j, k]; up = alpha[i, j, k]; dn = alpha[i + 1, j, k]
        else:
            if i + 2 >= nx:
                return alpha[i + 1, j, k]              # donor
            up2 = alpha[i + 2, j, k]; up = alpha[i + 1, j, k]; dn = alpha[i, j, k]
    elif axis == 1:  # y
        if F > 0.0:
            if j - 1 < 0:
                return alpha[i, j, k]
            up2 = alpha[i, j - 1, k]; up = alpha[i, j, k]; dn = alpha[i, j + 1, k]
        else:
            if j + 2 >= ny:
                return alpha[i, j + 1, k]
            up2 = alpha[i, j + 2, k]; up = alpha[i, j + 1, k]; dn = alpha[i, j, k]
    else:  # axis == 2, z
        if F > 0.0:
            if k - 1 < 0:
                return alpha[i, j, k]
            up2 = alpha[i, j, k - 1]; up = alpha[i, j, k]; dn = alpha[i, j, k + 1]
        else:
            if k + 2 >= nz:
                return alpha[i, j, k + 1]
            up2 = alpha[i, j, k + 2]; up = alpha[i, j, k + 1]; dn = alpha[i, j, k]

    du = up - up2
    dd = dn - up
    r = du / (dd + np.copysign(eps, dd))
    phi = mc_limiter(r)

    Cface = abs(F) * dt / V
    if Cface > 1.0:
        Cface = 1.0
    return up + 0.5 * phi * (1.0 - Cface) * dd

@njit(parallel=True, cache=True)
def compute_vof(vof, u, v, w, vofM1, vofM2, dx, dy, dz, dt, use_tvd=True):
    """
    3D VOF advection on a MAC grid with MUSCL–MC TVD (optional) and
    constant-preserving BDF2 time integration.

    Shapes (assumed):
      vof, vofM1, vofM2: (nx, ny, nz)  at cell centers
      u:                 (nx+1, ny, nz)  x-faces
      v:                 (nx, ny+1, nz)  y-faces
      w:                 (nx, ny, nz+1)  z-faces
    """
    nx, ny, nz = vof.shape
    V  = dx * dy * dz
    Ax = dy * dz
    Ay = dx * dz
    Az = dx * dy

    # freeze α^n with one ghost layer (copy-out padding)
    a = vofM1.copy()
    # x faces
    a[0,   :,  :] = a[1,   :,  :]
    a[nx-1, :,  :] = a[nx-2, :,  :]
    # y faces
    a[:, 0,   :] = a[:, 1,   :]
    a[:, ny-1, :] = a[:, ny-2, :]
    # z faces
    a[:, :, 0   ] = a[:, :, 1   ]
    a[:, :, nz-1] = a[:, :, nz-2]

    for k in prange(1, nz - 1):
        for j in range(1, ny - 1):
            for i in range(1, nx - 1):
                # Mass fluxes through cell faces (positive outward)
                Fw = u[i,   j, k] * Ay
                Fe = u[i+1, j, k] * Ay
                Fs = v[i,   j, k] * Ax
                Fn = v[i,   j+1, k] * Ax
                Fb = w[i,   j, k] * Az
                Ft = w[i,   j, k+1] * Az

                if use_tvd:
                    # Face scalar values using MUSCL along the upwind line
                    aw  = face_alpha_3d(a, i-1, j,   k,   Fw, dt, V, 0, nx, ny, nz)  # west (x)
                    ae  = face_alpha_3d(a, i,   j,   k,   Fe, dt, V, 0, nx, ny, nz)  # east (x)
                    as_ = face_alpha_3d(a, i,   j-1, k,   Fs, dt, V, 1, nx, ny, nz)  # south (y)
                    an  = face_alpha_3d(a, i,   j,   k,   Fn, dt, V, 1, nx, ny, nz)  # north (y)
                    ab  = face_alpha_3d(a, i,   j,   k-1, Fb, dt, V, 2, nx, ny, nz)  # bottom (z)
                    at_ = face_alpha_3d(a, i,   j,   k,   Ft, dt, V, 2, nx, ny, nz)  # top (z)
                else:
                    # Donor-cell (first-order upwind)
                    aw  = a[i-1, j,   k] if Fw > 0.0 else a[i,   j,   k]
                    ae  = a[i,   j,   k] if Fe > 0.0 else a[i+1, j,   k]
                    as_ = a[i,   j-1, k] if Fs > 0.0 else a[i,   j,   k]
                    an  = a[i,   j,   k] if Fn > 0.0 else a[i,   j+1, k]
                    ab  = a[i,   j,   k-1] if Fb > 0.0 else a[i,   j,   k]
                    at_ = a[i,   j,   k]   if Ft > 0.0 else a[i,   j,   k+1]

                # Convective contribution and divergence
                netC = (Fe * ae - Fw * aw) + (Fn * an - Fs * as_) + (Ft * at_ - Fb * ab)
                Div  = (Fe - Fw) + (Fn - Fs) + (Ft - Fb)

                # BDF2, constant-preserving (same as your 2D form)
                a_n   = vofM1[i, j, k]
                a_nm1 = vofM2[i, j, k]
                a_np1 = ((4.0 * a_n - a_nm1) - (2.0 * dt / V) * (netC - a_n * Div)) / 3.0

                # Clamp to [0,1]
                if   a_np1 < 0.0: a_np1 = 0.0
                elif a_np1 > 1.0: a_np1 = 1.0
                vof[i, j, k] = a_np1

    # refresh ghost layer for vof (copy-out)
    vof[0,   :,  :] = vof[1,   :,  :]
    vof[nx-1, :,  :] = vof[nx-2, :,  :]
    vof[:, 0,   :] = vof[:, 1,   :]
    vof[:, ny-1, :] = vof[:, ny-2, :]
    vof[:, :, 0   ] = vof[:, :, 1   ]
    vof[:, :, nz-1] = vof[:, :, nz-2]

##################################################################
########################################################################################################################################################################
@njit(parallel=True, fastmath=True, cache=True)
def update_scalars(vof, rho, mu, rho_primary, mu_primary, rho_secondary, mu_secondary):

    nx, ny, nz = vof.shape

    for k in prange(1, nz - 1):
        for j in range(1, ny - 1):
            for i in range(1, nx - 1):
                rho[i, j, k] = vof[i, j, k] * rho_primary + (1 - vof[i, j, k]) * rho_secondary
                mu[i, j, k] = vof[i, j, k] * mu_primary + (1 - vof[i, j, k]) * mu_secondary

