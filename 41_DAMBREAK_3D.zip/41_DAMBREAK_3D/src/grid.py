import numpy as np
  
class FieldSet:
    """
    -Used for solving the transient NS equations for a 2D grid.
    -Uses Backward Staggered Grid approach for velocity and pressure fields.
    -Uses numpy arrays to represent the fields.
    #######################################################################################################################
    -Config: cols x rows
    -cols = x-direction (horizontal)
    -rows = y-direction (vertical)
    -The field definitions are based on the backward grid which is well documented in the thesis.
    -params.xmax is one less than the number of cells in the x-direction as they do not include the ghost cells.
    -params.ymax is one less than the number of cells in the y-direction as they do not include the ghost cells.
    #######################################################################################################################
    -dx and dy are the grid spacings in the x and y directions respectively.
    -dx and dy are calculated based on the total length of the domain and the number of nodes in the respective direction.
    -dx and dy are only computed on the inner cells, not the ghost cells.
    
    """
    def __init__(self, params):


        self.ymax = params.ymax + 1
        self.xmax = params.xmax + 1
        self.zmax = params.zmax + 1

        self.dx = params.xlength / (params.xmax-1)
        self.dy = params.ylength / (params.ymax-1)
        self.dz = params.zlength / (params.zmax-1)
        self.dt = params.dt

        def face_shapes(self):
            return {
                "u": (self.xmax, self.ymax, self.zmax),   # (east/west)
                "v": (self.xmax, self.ymax, self.zmax),   # (top/bottom)
                "w": (self.xmax, self.ymax, self.zmax),   # (front/back)
                "p": (self.xmax, self.ymax, self.zmax)    # cell centers
            }

        
        self.shapes = face_shapes(self)

        self.u = np.zeros(self.shapes["u"], dtype=np.float64)
        self.u_stag = np.zeros_like(self.u)
        self.u_s1 = np.zeros_like(self.u)
        self.u_s2 = np.zeros_like(self.u)
        self.u_s3 = np.zeros_like(self.u)
        self.u_M1 = np.zeros_like(self.u)
        self.u_M2 = np.zeros_like(self.u)
        self.u_final = np.zeros_like(self.u)

        self.v = np.zeros(self.shapes["v"], dtype=np.float64)
        self.v_stag = np.zeros_like(self.v)
        self.v_s1 = np.zeros_like(self.v)
        self.v_s2 = np.zeros_like(self.v)
        self.v_s3 = np.zeros_like(self.v)
        self.v_M1 = np.zeros_like(self.v)
        self.v_M2 = np.zeros_like(self.v)
        self.v_final = np.zeros_like(self.v)

        self.w = np.zeros(self.shapes["w"], dtype=np.float64)
        self.w_stag = np.zeros_like(self.w)
        self.w_s1 = np.zeros_like(self.w)
        self.w_s2 = np.zeros_like(self.w)
        self.w_s3 = np.zeros_like(self.w)
        self.w_M1 = np.zeros_like(self.w)
        self.w_M2 = np.zeros_like(self.w)
        self.w_final = np.zeros_like(self.w)

        self.p = np.zeros(self.shapes["p"], dtype=np.float64)
        self.p_s1 = np.zeros_like(self.p)
        self.p_s2 = np.zeros_like(self.p)
        self.p_s3 = np.zeros_like(self.p)
        self.p_M1 = np.zeros_like(self.p)
        self.p_M2 = np.zeros_like(self.p)
        self.p_final = np.zeros_like(self.p)

        # Central values 
        self.u_cen = np.zeros((params.xmax, params.ymax, params.zmax), dtype=np.float64)  
        self.v_cen = np.zeros_like(self.u_cen)
        self.w_cen = np.zeros_like(self.u_cen)
        self.p_cen = np.zeros_like(self.u_cen)
        self.vof_cen = np.zeros_like(self.u_cen)
        #################################################################
        self.u_col = np.zeros_like(self.u_cen)
        self.v_col = np.zeros_like(self.u_cen)
        self.w_col = np.zeros_like(self.u_cen)
        self.vof_col = np.zeros_like(self.u_cen)

        # Scalars and VOF
        self.rho =  np.zeros_like(self.p)
        self.rho_M1 =  np.zeros_like(self.p)
        self.rho_M2 =  np.zeros_like(self.p)
        self.rho_M1_load = np.zeros_like(self.rho)
        ######################################
        self.mu = np.zeros_like(self.rho)
        ######################################
        self.vof = np.zeros_like(self.rho)
        self.vof_stag = np.zeros_like(self.vof)
        self.vof_M1 = np.zeros_like(self.rho)
        self.vof_M2 = np.zeros_like(self.rho)
        self.vof_final = np.zeros_like(self.rho)
        self.vof_M1_load = np.zeros_like(self.rho)
        ######################################
        # D ratios
        self.d_ratio_x_1 = np.zeros_like(self.u)
        self.d_ratio_x_2 = np.zeros_like(self.u)
        self.source_x = 0
        ########################################
        self.d_ratio_y_1 = np.zeros_like(self.v)
        self.d_ratio_y_2 = np.zeros_like(self.v)
        self.source_y = 0
        ######################################
        self.d_ratio_z_1 = np.zeros_like(self.w)
        self.d_ratio_z_2 = np.zeros_like(self.w)
        self.source_z = 0
        ######################################

        # Mass Conservation residues
        self.b = np.zeros_like(self.p)
        self.b_2 = np.ones_like(self.p)
        self.b_3 = np.ones_like(self.p)

        self.aw_u1 = np.zeros_like(self.u)
        self.ae_u1 = np.zeros_like(self.u)
        self.as_u1 = np.zeros_like(self.u)
        self.an_u1 = np.zeros_like(self.u)
        self.ab_u1 = np.zeros_like(self.u)
        self.at_u1 = np.zeros_like(self.u)
        self.ap_u1 = np.zeros_like(self.u)

        
        self.aw_v1 = np.zeros_like(self.v)
        self.ae_v1 = np.zeros_like(self.v)
        self.as_v1 = np.zeros_like(self.v)
        self.an_v1 = np.zeros_like(self.v)
        self.ab_v1 = np.zeros_like(self.v)
        self.at_v1 = np.zeros_like(self.v)
        self.ap_v1 = np.zeros_like(self.v)

        self.aw_w1 = np.zeros_like(self.w)
        self.ae_w1 = np.zeros_like(self.w)
        self.as_w1 = np.zeros_like(self.w)
        self.an_w1 = np.zeros_like(self.w)
        self.ab_w1 = np.zeros_like(self.w)
        self.at_w1 = np.zeros_like(self.w)
        self.ap_w1 = np.zeros_like(self.w)

        
        self.aw_u2 = np.zeros_like(self.u)
        self.ae_u2 = np.zeros_like(self.u)
        self.as_u2 = np.zeros_like(self.u)
        self.an_u2 = np.zeros_like(self.u)
        self.ab_u2 = np.zeros_like(self.u)
        self.at_u2 = np.zeros_like(self.u)
        self.ap_u2 = np.zeros_like(self.u)
       
        self.aw_v2 = np.zeros_like(self.v)
        self.ae_v2 = np.zeros_like(self.v)
        self.as_v2 = np.zeros_like(self.v)
        self.an_v2 = np.zeros_like(self.v)
        self.ab_v2 = np.zeros_like(self.v)
        self.at_v2 = np.zeros_like(self.v)
        self.ap_v2 = np.zeros_like(self.v)

        self.aw_w2 = np.zeros_like(self.w)
        self.ae_w2 = np.zeros_like(self.w)
        self.as_w2 = np.zeros_like(self.w)
        self.an_w2 = np.zeros_like(self.w)
        self.ab_w2 = np.zeros_like(self.w)
        self.at_w2 = np.zeros_like(self.w)
        self.ap_w2 = np.zeros_like(self.w)


