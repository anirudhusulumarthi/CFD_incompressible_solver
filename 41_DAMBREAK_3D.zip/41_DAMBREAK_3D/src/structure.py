import numpy as np
from functools import partial

def object_points(params):
    """
    Returns set of (i, j) indices on collocated grid that lie on or inside a square object
    """
    # treat string flags robustly
    obj_flag = getattr(params, 'object', False)
    if isinstance(obj_flag, str):
        obj_flag = obj_flag.strip().lower() in ("true","1","yes","y","on")

    if not obj_flag:
        return set()

    assert params.object_name.lower() == 'square', "Only 'square' object type is supported"

    x_c, y_c = params.object_location
    # Grid spacing
    dx = params.xlength / (params.xmax - 1)
    dy = params.ylength / (params.ymax - 1)

    # Validate that center is on collocated point
    x_c, y_c = params.object_location
    if not (x_c / dx).is_integer() or not (y_c / dy).is_integer():
        raise ValueError(
            f"Object center ({x_c}, {y_c}) is not aligned with collocated grid. "
            f"dx={dx}, dy={dy} required for alignment."
        )

    # Validate that side length is divisible by dx and dy
    if (params.side_length / dx) % 1 != 0 or (params.side_length / dy) % 1 != 0:
        raise ValueError(
            f"Side length {params.side_length} must be divisible by both dx={dx} and dy={dy}."
        )

    # Center in physical coordinates
    x_c, y_c = params.object_location
    side = params.side_length

    # Calculate bounds in physical space
    half = side / 2
    x_min, x_max = x_c - half, x_c + half
    y_min, y_max = y_c - half, y_c + half

    # Compute collocated grid dimensions (same as p_cen.shape)
    nx, ny = params.xmax, params.ymax

    # Loop through grid and collect (i, j) that are inside the square
    inside = set()
    for i in range(nx):
        x_i = i * dx
        if not (x_min <= x_i <= x_max):
            continue
        for j in range(ny):
            y_j = j * dy
            if y_min <= y_j <= y_max:
                inside.add((i, j))

    return inside


field_map = {
    'u': 'u', 'u_s1': 'u', 'u_s2': 'u', 'u_s3': 'u',  'u_final': 'u',
    'v': 'v', 'v_s1': 'v', 'v_s2': 'v', 'v_s3': 'v',  'v_final': 'v',
    'p': 'p', 'p_s1': 'p', 'p_s2': 'p', 'p_s3': 'p',  'p_final': 'p',
}

def _apply_zero_bc(field, indices):
    for i, j in indices:
        field[i, j] = 0.0

# --- tiny helpers (added) ---
def _obj_enabled(params):
    val = getattr(params, 'object', False)
    if isinstance(val, str):
        return val.strip().lower() in ("true","1","yes","y","on")
    return bool(val)

def _apply_zero_bc_if_object(field, indices, params):
    if not _obj_enabled(params):
        return  # no-op when flag is off
    _apply_zero_bc(field, indices)
# --- end tiny helpers ---

def setup_fsi_zeroing_functions(fieldset, object_points, params):
    fsi_dispatch = {}
    staggered_indices = {"u": set(), "v": set(), "p": set()}

    # Do NOT iterate flags (bool/str). Only iterate a proper iterable of (i,j).
    if isinstance(object_points, (bool, np.bool_)) or isinstance(object_points, str):
        iter_points = []  # nothing to build
    else:
        iter_points = object_points

    for item in iter_points:
        # accept only 2-tuples/lists
        if not (isinstance(item, (tuple, list)) and len(item) == 2):
            continue
        i, j = item
        staggered_indices["u"].update([(i+1, j), (i+1, j+1)])
        staggered_indices["v"].update([(i, j+1), (i+1, j+1)])
        staggered_indices["p"].update([(i, j), (i, j+1), (i+1, j), (i+1, j+1)])

    # Always return functions; they no-op when params.object is False
    for field_name, base in field_map.items():
        if base not in {"u", "v", "p"}:
            continue
        field_array = getattr(fieldset, field_name)
        indices = list(staggered_indices[base])
        fsi_dispatch[(field_name,)] = partial(_apply_zero_bc_if_object, field_array, indices, params)

    return fsi_dispatch
