import pyvista as pv
import numpy as np



def print_parameters(params):
    print("\n===== CFD Simulation Parameters =====\n")

    print(f"📘 Problem Name:         {params.problem_name}")
    print(f"📏 Domain Size:          xlength = {params.xlength}, ylength = {params.ylength}")
    print(f"🧮 Grid Size:            xmax = {params.xmax}, ymax = {params.ymax}")
    print(f"🔁 Reynolds Number:      Re = {params.Re}")
    print(f"⚙️  Solver Parameters:")
    print(f"    alpha_uv           = {params.alpha_uv}")
    print(f"    alpha_p1 (during)  = {params.alpha_p1}")
    print(f"    alpha_p2 (post)    = {params.alpha_p2}")
    print(f"    error_threshold    = {params.error_thresh}")

    print(f"\n💧 Fluid Properties:")
    print(f"    Fluid 1: rho = {params.rho_primary}, mu = {params.mu_primary}")
    print(f"    Fluid 2: rho = {params.rho_secondary}, mu = {params.mu_secondary}")


    print("\n✅ All parameters successfully loaded and parsed.\n")







##############################################################################################################################################################################################
# VTK Output Function
##############################################################################################################################################################################################

def writeVTK(grid, filename, params):
    try:
        with open(filename, 'w') as vtkFile:
            cnx, cny, cnz = grid.u_cen.shape

            vtkFile.write("# vtk DataFile Version 3.0\n")
            vtkFile.write(f"{params.problem_name} Simulation\n")
            vtkFile.write("ASCII\n")
            vtkFile.write("DATASET STRUCTURED_GRID\n")
            vtkFile.write(f"DIMENSIONS {cnx} {cny} {cnz}\n")
            vtkFile.write(f"POINTS {cnx * cny * cnz} float\n")

            # Explicitly write points
            for k in range(cnz):
                for j in range(cny):
                    for i in range(cnx):
                        x = i * grid.dx
                        y = j * grid.dy
                        z = k * grid.dz
                        vtkFile.write(f"{x:.6f} {y:.6f} {z:.6f}\n")

            vtkFile.write(f"\nPOINT_DATA {cnx * cny * cnz}\n")
            vtkFile.write("SCALARS pressure float\n")
            vtkFile.write("LOOKUP_TABLE default\n")

            for k in range(cnz):
                for j in range(cny):
                    for i in range(cnx):
                        vtkFile.write(f"{grid.p_cen[i, j, k]:.6f}\n")

            vtkFile.write("\nVECTORS velocity float\n")

            for k in range(cnz):
                for j in range(cny):
                    for i in range(cnx):
                        vtkFile.write(f"{grid.u_cen[i, j, k]:.6f} {grid.v_cen[i, j, k]:.6f} {grid.w_cen[i, j, k]:.6f}\n")

            vtkFile.write("SCALARS VOF float\n")
            vtkFile.write("LOOKUP_TABLE default\n")

            for k in range(cnz):
                for j in range(cny):
                    for i in range(cnx):
                        vtkFile.write(f"{grid.vof_cen[i, j, k]:.6f}\n")

    except IOError:
        print(f"Error: Unable to open file {filename}")
